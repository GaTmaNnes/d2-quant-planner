#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
quant_graph_compiler_v2 - remplace par le package `d2`
======================================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
* `__init__` ouvrait `precision_map_v3.json`, absent du depot : le module ne
  demarrait pas.
* `optimize()` etait sans effet. Quand `curr` est deja le plus conservateur,
  `unified_p == curr` et l'affectation ne change rien ; quand `prev` l'est,
  `cost_switch < cost_unified` et l'unification n'a pas lieu. Aucune passe
  d'optimisation n'etait donc reellement appliquee.
* `ranks` ne comptait que 3 cles pour 5 precisions declarees -> `KeyError` des
  qu'on etendait la politique.
* Le graphe `networkx` etait construit puis jamais utilise : l'iteration se
  faisait sur l'ordre d'insertion des noeuds.
* L'alignement testait `% 32` alors que `d2_rtx_gguf_profiler` testait `% 128`
  pour la meme notion.

Correspondance
--------------
* ``QuantGraphCompilerV2`` -> ``d2.plan_layers``
* ``check_alignment`` -> ``d2.formats (les tailles de bloc sont gerees par format)``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'quant_graph_compiler_v2'

_MOVED = {'QuantGraphCompilerV2': 'd2.plan_layers', 'check_alignment': 'd2.formats (les tailles de bloc sont gerees par format)'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
