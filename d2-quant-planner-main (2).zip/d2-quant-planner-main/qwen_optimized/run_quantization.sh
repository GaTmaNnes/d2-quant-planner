#!/bin/bash
# Auto-generated quantization script
# CONSERVATIVE (8GB)
llama-quantize --tensor-type attention=q4_k --tensor-type mlp=q4_k --tensor-type embedding=q5_k C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf qwen_optimized\qwen-conservative-8gb.gguf Q4_K_M

# BALANCED (12GB)
llama-quantize --tensor-type attention=q5_k --tensor-type mlp=q4_k --tensor-type embedding=f16 C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf qwen_optimized\qwen-balanced-12gb.gguf Q4_K_M

# QUALITY (16GB)
llama-quantize --tensor-type attention=q6_k --tensor-type mlp=q5_k --tensor-type embedding=f16 C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf qwen_optimized\qwen-quality-16gb.gguf Q5_K_M

# MAXIMUM (24GB)
llama-quantize --tensor-type attention=f16 --tensor-type mlp=q6_k --tensor-type embedding=f16 C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf qwen_optimized\qwen-maximum-24gb.gguf Q6_K
