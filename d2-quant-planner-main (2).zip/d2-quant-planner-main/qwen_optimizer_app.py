#!/usr/bin/env python3
"""
Qwen3.5-9B Optimizer Desktop Application
==========================================

UI Desktop complète avec:
- Téléchargement automatique de llama.cpp
- Choix du modèle (GGUF/Safetensor)
- Sélection de stratégie d'optimisation
- Progress bar en temps réel
- Logs en direct
- Lancement du modèle
"""

import sys
import json
import subprocess
import threading
import os
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass
import logging

try:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QComboBox, QProgressBar, QTextEdit,
        QGroupBox, QTabWidget, QFileDialog, QMessageBox, QSpinBox,
        QCheckBox, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView
    )
    from PySide6.QtCore import Qt, QThread, Signal, QTimer
    from PySide6.QtGui import QFont, QColor, QPixmap
except ImportError:
    print("Installing PySide6...")
    subprocess.run([sys.executable, "-m", "pip", "install", "PySide6", "-q"])
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QComboBox, QProgressBar, QTextEdit,
        QGroupBox, QTabWidget, QFileDialog, QMessageBox, QSpinBox,
        QCheckBox, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView
    )
    from PySide6.QtCore import Qt, QThread, Signal, QTimer
    from PySide6.QtGui import QFont, QColor, QPixmap

# Configuration
STRATEGIES = [
    {
        'name': 'Conservative',
        'budget': '8GB',
        'attention': 'q4_k',
        'mlp': 'q4_k',
        'embedding': 'q5_k',
        'base_fmt': 'Q4_K_M',
        'desc': 'Maximum compression, minimum RAM'
    },
    {
        'name': 'Balanced',
        'budget': '12GB',
        'attention': 'q5_k',
        'mlp': 'q4_k',
        'embedding': 'f16',
        'base_fmt': 'Q4_K_M',
        'desc': 'Good quality/speed tradeoff (RECOMMENDED)',
        'recommended': True
    },
    {
        'name': 'Quality',
        'budget': '16GB',
        'attention': 'q6_k',
        'mlp': 'q5_k',
        'embedding': 'f16',
        'base_fmt': 'Q5_K_M',
        'desc': 'High fidelity, still good speed'
    },
    {
        'name': 'Maximum',
        'budget': '24GB',
        'attention': 'f16',
        'mlp': 'q6_k',
        'embedding': 'f16',
        'base_fmt': 'Q6_K',
        'desc': 'Best quality, bandwidth limited'
    },
]

logger = logging.getLogger(__name__)

class WorkerThread(QThread):
    """Thread worker pour les opérations longues"""
    progress = Signal(int)
    status = Signal(str)
    log = Signal(str)
    finished = Signal(bool, str)

    def __init__(self, task, *args, **kwargs):
        super().__init__()
        self.task = task
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            if self.task == "download_llama":
                self._download_llama()
            elif self.task == "quantize":
                self._quantize()
            elif self.task == "benchmark":
                self._benchmark()
            elif self.task == "run_model":
                self._run_model()
            self.finished.emit(True, "Success")
        except Exception as e:
            self.finished.emit(False, str(e))

    def _download_llama(self):
        """Télécharger llama.cpp"""
        self.log.emit("⏳ Checking for llama.cpp...\n")

        # Vérifier si déjà installé
        if self._find_llama_quantize():
            self.log.emit("✅ llama-quantize already found!\n")
            return

        self.log.emit("📥 Downloading llama.cpp...\n")

        # Déterminer le système d'exploitation
        import platform
        system = platform.system()

        if system == "Windows":
            url = "https://github.com/ggerganov/llama.cpp/releases/download/b4472/llama-b4472-bin-win-avx2.zip"
            filename = "llama-cpp-windows.zip"
        elif system == "Darwin":
            url = "https://github.com/ggerganov/llama.cpp/releases/download/b4472/llama-b4472-bin-macos-arm64.zip"
            filename = "llama-cpp-macos.zip"
        else:
            url = "https://github.com/ggerganov/llama.cpp/releases/download/b4472/llama-b4472-bin-linux-x64.zip"
            filename = "llama-cpp-linux.zip"

        # Créer dossier
        llama_dir = Path("llama_cpp")
        llama_dir.mkdir(exist_ok=True)

        # Télécharger
        try:
            import urllib.request
            self.log.emit(f"Downloading from: {url}\n")
            urllib.request.urlretrieve(url, filename)
            self.log.emit(f"✅ Downloaded: {filename}\n")

            # Décompresser
            self.log.emit("📦 Extracting...\n")
            import zipfile
            with zipfile.ZipFile(filename, 'r') as zip_ref:
                zip_ref.extractall(llama_dir)
            self.log.emit("✅ Extracted!\n")

            # Nettoyer
            os.remove(filename)
            self.log.emit("✅ llama.cpp ready!\n")

        except Exception as e:
            self.log.emit(f"❌ Download failed: {e}\n")
            raise

    def _find_llama_quantize(self):
        """Chercher llama-quantize"""
        candidates = [
            "llama-quantize",
            "llama-quantize.exe",
            Path("llama_cpp") / "llama-quantize.exe",
            Path("llama_cpp") / "build" / "bin" / "llama-quantize.exe",
        ]

        for candidate in candidates:
            try:
                result = subprocess.run(
                    f"{candidate} --version",
                    shell=True,
                    capture_output=True,
                    timeout=2
                )
                if result.returncode == 0:
                    return str(candidate)
            except:
                continue
        return None

    def _quantize(self):
        """Quantifier le modèle"""
        model_path = self.kwargs.get('model_path')
        strategy = self.kwargs.get('strategy')
        output_path = self.kwargs.get('output_path')

        llama_quantize = self._find_llama_quantize()
        if not llama_quantize:
            raise Exception("llama-quantize not found!")

        cmd = [
            llama_quantize,
            '--tensor-type', f"attention={strategy['attention']}",
            '--tensor-type', f"mlp={strategy['mlp']}",
            '--tensor-type', f"embedding={strategy['embedding']}",
            str(model_path),
            str(output_path),
            strategy['base_fmt'],
        ]

        self.log.emit(f"🚀 Starting quantization...\n")
        self.log.emit(f"Strategy: {strategy['name']}\n")
        self.log.emit(f"Input: {model_path}\n")
        self.log.emit(f"Output: {output_path}\n\n")

        process = subprocess.Popen(
            ' '.join(str(c) for c in cmd),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        for line in process.stdout:
            if line.strip():
                self.log.emit(line)
                # Simuler progress
                self.progress.emit(min(90, self.progress.value() + 5))

        process.wait()

        if process.returncode == 0:
            self.log.emit("\n✅ Quantization complete!\n")
            if Path(output_path).exists():
                size = Path(output_path).stat().st_size / 1e9
                self.log.emit(f"Size: {size:.2f} GB\n")
        else:
            raise Exception("Quantization failed!")

    def _benchmark(self):
        """Benchmarker le modèle"""
        model_path = self.kwargs.get('model_path')
        llama_cli = self._find_llama_cli()

        if not llama_cli:
            self.log.emit("⚠️ llama-cli not found\n")
            return

        self.log.emit("📊 Running benchmark...\n")

        cmd = [
            llama_cli,
            '-m', str(model_path),
            '-n', '128',
            '-p', 'The quick brown fox jumps over',
            '-ngl', '33',
            '--timing',
        ]

        process = subprocess.Popen(
            ' '.join(cmd),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        for line in process.stdout:
            if line.strip():
                self.log.emit(line + "\n")

        process.wait()

    def _find_llama_cli(self):
        """Chercher llama-cli"""
        candidates = [
            "llama-cli",
            "llama-cli.exe",
            Path("llama_cpp") / "llama-cli.exe",
        ]

        for candidate in candidates:
            try:
                result = subprocess.run(
                    f"{candidate} --version",
                    shell=True,
                    capture_output=True,
                    timeout=2
                )
                if result.returncode == 0:
                    return str(candidate)
            except:
                continue
        return None

    def _run_model(self):
        """Lancer le modèle en mode interactif"""
        model_path = self.kwargs.get('model_path')
        llama_cli = self._find_llama_cli()

        if not llama_cli:
            raise Exception("llama-cli not found!")

        self.log.emit("🚀 Launching model...\n")
        self.log.emit("(Close the window to stop)\n\n")

        cmd = [
            llama_cli,
            '-m', str(model_path),
            '-ngl', '33',
            '-c', '8192',
            '-n', '512',
        ]

        subprocess.Popen(' '.join(cmd), shell=True)

class QwenOptimizerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.model_path = None
        self.output_dir = Path("qwen_optimized")
        self.output_dir.mkdir(exist_ok=True)

        self.init_ui()
        self.check_llama()

    def init_ui(self):
        """Initialiser l'UI"""
        self.setWindowTitle("Qwen3.5-9B Optimizer")
        self.setGeometry(100, 100, 1200, 800)

        # Thème
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e1e;
                color: #ffffff;
            }
            QPushButton {
                background-color: #0d47a1;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d3a91;
            }
            QGroupBox {
                color: #ffffff;
                border: 1px solid #444;
                border-radius: 4px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 0 5px;
            }
            QTextEdit {
                background-color: #2d2d2d;
                color: #00ff00;
                font-family: 'Courier New';
                font-size: 10px;
                border: 1px solid #444;
                border-radius: 4px;
            }
            QComboBox, QSpinBox {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444;
                padding: 5px;
                border-radius: 4px;
            }
            QProgressBar {
                border: 1px solid #444;
                border-radius: 4px;
                text-align: center;
                color: #ffffff;
            }
            QProgressBar::chunk {
                background-color: #0d47a1;
            }
        """)

        # Widget central
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)

        # Panneau gauche - Contrôles
        left_panel = QVBoxLayout()

        # Groupe modèle
        model_group = QGroupBox("Model Selection")
        model_layout = QVBoxLayout()

        model_layout.addWidget(QLabel("Select Model:"))
        self.model_combo = QComboBox()
        self.model_combo.addItem("GGUF - Local")
        self.model_combo.addItem("Safetensors - HuggingFace")
        model_layout.addWidget(self.model_combo)

        self.model_path_label = QLabel("No model selected")
        model_layout.addWidget(self.model_path_label)

        btn_browse = QPushButton("Browse Local Model...")
        btn_browse.clicked.connect(self.browse_model)
        model_layout.addWidget(btn_browse)

        model_group.setLayout(model_layout)
        left_panel.addWidget(model_group)

        # Groupe stratégie
        strategy_group = QGroupBox("Quantization Strategy")
        strategy_layout = QVBoxLayout()

        strategy_layout.addWidget(QLabel("Select Strategy:"))
        self.strategy_combo = QComboBox()
        for s in STRATEGIES:
            marker = "⭐ " if s.get('recommended') else ""
            self.strategy_combo.addItem(f"{marker}{s['name']} ({s['budget']})")
        self.strategy_combo.setCurrentIndex(1)  # Balanced par défaut
        strategy_layout.addWidget(self.strategy_combo)

        self.strategy_desc = QLabel("")
        self.strategy_desc.setWordWrap(True)
        strategy_layout.addWidget(self.strategy_desc)
        self.update_strategy_desc()
        self.strategy_combo.currentIndexChanged.connect(self.update_strategy_desc)

        strategy_group.setLayout(strategy_layout)
        left_panel.addWidget(strategy_group)

        # Groupe options
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout()

        self.gpu_slider = QSpinBox()
        self.gpu_slider.setMinimum(0)
        self.gpu_slider.setMaximum(33)
        self.gpu_slider.setValue(33)
        options_layout.addWidget(QLabel("GPU Layers:"))
        options_layout.addWidget(self.gpu_slider)

        self.ctx_slider = QSpinBox()
        self.ctx_slider.setMinimum(512)
        self.ctx_slider.setMaximum(32768)
        self.ctx_slider.setValue(8192)
        self.ctx_slider.setSingleStep(512)
        options_layout.addWidget(QLabel("Context Length:"))
        options_layout.addWidget(self.ctx_slider)

        options_group.setLayout(options_layout)
        left_panel.addWidget(options_group)

        # Boutons d'action
        action_group = QGroupBox("Actions")
        action_layout = QVBoxLayout()

        self.btn_quantize = QPushButton("🚀 Start Quantization")
        self.btn_quantize.clicked.connect(self.start_quantization)
        action_layout.addWidget(self.btn_quantize)

        self.btn_benchmark = QPushButton("📊 Benchmark")
        self.btn_benchmark.clicked.connect(self.start_benchmark)
        action_layout.addWidget(self.btn_benchmark)

        self.btn_run = QPushButton("▶️ Run Model")
        self.btn_run.clicked.connect(self.run_model)
        action_layout.addWidget(self.btn_run)

        action_group.setLayout(action_layout)
        left_panel.addWidget(action_group)

        left_panel.addStretch()

        # Panneau droit - Logs et résultats
        right_panel = QVBoxLayout()

        tabs = QTabWidget()

        # Tab Logs
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        tabs.addTab(self.log_display, "📋 Logs")

        # Tab Résultats
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["File", "Size", "Status", "Action"])
        header = self.results_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        tabs.addTab(self.results_table, "✅ Results")

        right_panel.addWidget(tabs)

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setValue(0)
        right_panel.addWidget(self.progress)

        self.status_label = QLabel("Ready")
        right_panel.addWidget(self.status_label)

        # Layout final
        left_widget = QWidget()
        left_widget.setLayout(left_panel)
        left_widget.setMaximumWidth(350)

        right_widget = QWidget()
        right_widget.setLayout(right_panel)

        layout.addWidget(left_widget)
        layout.addWidget(right_widget, 1)

    def check_llama(self):
        """Vérifier/télécharger llama.cpp"""
        self.log("⏳ Checking llama.cpp installation...\n")

        worker = WorkerThread("download_llama")
        worker.log.connect(self.log)
        worker.finished.connect(self.on_llama_check_finished)
        worker.start()

    def on_llama_check_finished(self, success, msg):
        if success:
            self.log("✅ llama.cpp ready!\n\n")
        else:
            self.log(f"❌ Error: {msg}\n")

    def update_strategy_desc(self):
        """Mettre à jour la description de la stratégie"""
        idx = self.strategy_combo.currentIndex()
        strategy = STRATEGIES[idx]
        self.strategy_desc.setText(
            f"<b>{strategy['name']}</b><br>"
            f"{strategy['desc']}<br><br>"
            f"<b>Budget:</b> {strategy['budget']}<br>"
            f"<b>Attention:</b> {strategy['attention']}<br>"
            f"<b>MLP:</b> {strategy['mlp']}<br>"
            f"<b>Embedding:</b> {strategy['embedding']}"
        )

    def browse_model(self):
        """Parcourir les fichiers"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Model File",
            "",
            "GGUF Files (*.gguf);;Safetensors Files (*.safetensors);;All Files (*)"
        )

        if file_path:
            self.model_path = Path(file_path)
            self.model_path_label.setText(f"Selected: {self.model_path.name}")
            self.log(f"✅ Model loaded: {self.model_path}\n\n")

    def start_quantization(self):
        """Lancer la quantification"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Please select a model first!")
            return

        strategy = STRATEGIES[self.strategy_combo.currentIndex()]
        output_path = self.output_dir / f"qwen-{strategy['name'].lower()}-{strategy['budget'].replace('GB', 'gb')}.gguf"

        self.log(f"🚀 Starting quantization with {strategy['name']} strategy...\n\n")
        self.progress.setValue(0)
        self.btn_quantize.setEnabled(False)

        worker = WorkerThread(
            "quantize",
            model_path=self.model_path,
            strategy=strategy,
            output_path=output_path
        )
        worker.log.connect(self.log)
        worker.progress.connect(self.progress.setValue)
        worker.finished.connect(lambda s, m: self.on_quantize_finished(s, m, output_path))
        worker.start()

    def on_quantize_finished(self, success, msg, output_path):
        self.btn_quantize.setEnabled(True)
        self.progress.setValue(100)

        if success:
            self.log("\n✅ Quantization completed successfully!\n")
            if Path(output_path).exists():
                size = Path(output_path).stat().st_size / 1e9
                self.add_result(output_path.name, f"{size:.2f} GB", "✅ Ready")
                self.model_path = output_path  # Utiliser le modèle optimisé
        else:
            self.log(f"\n❌ Error: {msg}\n")

    def start_benchmark(self):
        """Lancer le benchmark"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Please select a model first!")
            return

        self.log(f"📊 Benchmarking {self.model_path.name}...\n\n")
        self.btn_benchmark.setEnabled(False)

        worker = WorkerThread("benchmark", model_path=self.model_path)
        worker.log.connect(self.log)
        worker.finished.connect(lambda s, m: self.btn_benchmark.setEnabled(True))
        worker.start()

    def run_model(self):
        """Lancer le modèle"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Please select a model first!")
            return

        self.log(f"▶️ Launching {self.model_path.name}...\n\n")

        worker = WorkerThread("run_model", model_path=self.model_path)
        worker.log.connect(self.log)
        worker.finished.connect(lambda s, m: self.log("Model closed.\n"))
        worker.start()

    def add_result(self, filename, size, status):
        """Ajouter une ligne aux résultats"""
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)

        self.results_table.setItem(row, 0, QTableWidgetItem(filename))
        self.results_table.setItem(row, 1, QTableWidgetItem(size))
        self.results_table.setItem(row, 2, QTableWidgetItem(status))

        btn = QPushButton("Launch")
        btn.clicked.connect(lambda: self.launch_from_result(filename))
        self.results_table.setCellWidget(row, 3, btn)

    def launch_from_result(self, filename):
        """Lancer un modèle depuis les résultats"""
        self.model_path = self.output_dir / filename
        self.run_model()

    def log(self, message):
        """Ajouter un message au log"""
        self.log_display.append(message.rstrip())
        self.log_display.verticalScrollBar().setValue(
            self.log_display.verticalScrollBar().maximum()
        )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = QwenOptimizerApp()
    window.show()
    sys.exit(app.exec())
