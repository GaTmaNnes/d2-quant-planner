# D2 — Planificateur de quantification sous contrainte mémoire

**Choisit un format de quantification par couche pour tenir dans un budget VRAM donné, en minimisant l'erreur de quantification réellement mesurée.**

![Python](https://img.shields.io/badge/Python-3.9%2B-3776AB?logo=python&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)
![Tests](https://img.shields.io/badge/tests-204%20passing-brightgreen)

---

## Ce que fait D2

Vous avez 12 Go de VRAM, un modèle de 8 milliards de paramètres et un contexte de 32 K tokens. Un préréglage uniforme (`Q4_K_M`, `Q5_K_M`…) applique le même format partout. D2 répartit les bits différemment : il quantifie chaque tenseur au format le plus compact qui reste acceptable **pour ce tenseur**, sous la contrainte que le total tienne dans le budget.

La décision repose sur trois choses :

1. **L'erreur de quantification mesurée.** Pour chaque couche et chaque format candidat, D2 quantifie puis déquantifie réellement la matrice et mesure `‖W − Q(W)‖ / ‖W‖`. Pas de score heuristique.
2. **L'importance de la couche.** Préfacteurs issus du mélange k-quant de llama.cpp (calibré sur la perplexité) et de la littérature sur les canaux aberrants — `attn_v` et `ffn_down` sont plus sensibles que `attn_q` ou `ffn_up`.
3. **Une imatrix, si vous en avez une.** L'erreur devient alors `‖(W − Q(W))·diag(√s)‖` avec `s = E[x²]` mesuré sur des données réelles — l'objectif exact de GPTQ, d'AWQ et de l'`imatrix` de llama.cpp.

L'allocation est résolue exactement, comme un programme linéaire en nombres entiers (formulation HAWQ-V3).

---

## Installation

```bash
git clone https://github.com/GaTmaNnes/d2-quant-planner.git
cd d2-quant-planner
pip install -r requirements.txt
```

Le noyau ne dépend que de `numpy` et `scipy`. `gguf`, `safetensors` et `huggingface_hub` servent à lire les modèles ; `PySide6` et `gradio` aux interfaces.

```bash
pip install -e .          # installe la commande `d2-plan`
pip install -e ".[all]"   # avec la lecture GGUF/HF et pytest
```

---

## Utilisation

### Ligne de commande

```bash
python d2_rtx_gguf_profiler.py model-f16.gguf --gpu-target rtx4090 --budget 16 --ctx 8192
```

Sans modèle sous la main :

```bash
python d2_rtx_gguf_profiler.py --demo --gpu-target rtx5070 --budget 8
```

Avec une matrice d'importance (recommandé — c'est ce qui améliore le plus le résultat) :

```bash
llama-imatrix -m model-f16.gguf -f calibration.txt -o model.imatrix
python d2_rtx_gguf_profiler.py model-f16.gguf --imatrix model.imatrix --budget 12
```

Options principales :

| Option | Rôle |
|---|---|
| `--gpu-target` | Cible matérielle (`rtx5090`, `rtx4090`, `a100`, `h100`, `b200`, `cpu`…) |
| `--budget` | VRAM totale en Go, cache KV et marge compris |
| `--ctx` | Longueur de contexte — dimensionne le cache KV, soustrait du budget |
| `--imatrix` | Statistiques d'activation llama.cpp |
| `--max-rel-error` | Plafond d'erreur **par couche**, ex. `0.05` |
| `--formats` | Restreint les formats candidats |
| `--target` | `llamacpp` (défaut), `tensorrt` ou `both` |
| `--spectral` | Ajoute le diagnostic spectral α (coûteux, non décisionnel) |

### Interfaces

```bash
python d2_ui.py       # bureau (PySide6)
python app.py         # web local sur http://127.0.0.1:7860
```

`app.py` n'ouvre **pas** de tunnel public par défaut ; utilisez `--share` si vous le souhaitez explicitement.

### API Python

```python
import d2

layers, info = d2.load_gguf("model-f16.gguf")
caps = d2.get_profile("rtx4090")

plan = d2.plan_layers(
    layers, caps,
    vram_budget_gb=16.0,
    ctx_len=8192,
    max_rel_error=0.05,        # aucune couche au-delà de 5 % d'erreur
    **d2.kv_geometry(info),
)

print(d2.summarize(plan, caps))
d2.export_llama_cpp(plan, "model-f16.gguf", "model-d2.gguf", json_path="plan.json")
```

Si le budget ne peut pas être tenu, `d2.InfeasibleBudget` est levée avec le détail — le planificateur ne rend jamais un plan hors budget.

---

## Appliquer le plan

D2 produit une commande `llama-quantize` :

```bash
llama-quantize \
  --tensor-type "attn_v=q6_K" \
  --tensor-type "ffn_down=q6_K" \
  --tensor-type "token_embd=q5_K" \
  model-f16.gguf model-d2.gguf Q4_K_M
```

> **Attention.** `--tensor-type` s'applique à la **conversion** (`llama-quantize`). Ne pas le confondre avec `--override-tensor` (`-ot`) de `llama-cli`, qui associe un motif de nom à un *type de buffer* (placement CPU/GPU) et ne quantifie rien. Les versions antérieures de ce dépôt produisaient des `--override-tensor NAME=q8_0`, qui n'avaient aucun effet sur la quantification.

Pour TensorRT-LLM, `--target tensorrt` écrit un `quant_config` avec les exclusions par module. La quantification par couche s'y déclare dans le checkpoint (`quantize.py` / `modelopt`), **pas** en option de `trtllm-build` : `--per_layer_precision` n'existe pas.

---

## Formats supportés

Les tailles sont celles des structures de blocs réelles de ggml, échelles et métadonnées comprises.

| Format | bits/poids | Bloc | ggml | TensorRT-LLM |
|---|---:|---:|---|---|
| F32 | 32.00 | — | `f32` | fp32 |
| F16 / BF16 | 16.00 | — | `f16` / `bf16` | fp16 / bf16 |
| Q8_0 | 8.50 | 32 | `q8_0` | int8 |
| Q6_K | 6.5625 | 256 | `q6_K` | int8¹ |
| Q5_K | 5.50 | 256 | `q5_K` | int8¹ |
| Q4_K | 4.50 | 256 | `q4_K` | int4¹ |
| Q3_K | 3.4375 | 256 | `q3_K` | int4¹ |
| Q2_K | 2.625 | 256 | `q2_K` | int4¹ |
| NVFP4 | 4.50 | 16 | — | nvfp4 |
| MXFP4 | 4.25 | 32 | `mxfp4` | — |
| INT4_AWQ | 4.25 | 128 | `q4_K` | int4_awq |

¹ Format supporté le plus proche en largeur ; la taille finale diffère légèrement du plan GGUF. L'export le signale.

**Un `Q4_K_M` n'occupe pas 4 bits par poids mais 4,5.** Un super-bloc de 256 poids fait 144 octets : 128 de poids, 12 d'échelles, 4 pour `d`/`dmin`. Compter 0,5 octet par poids sous-estime la taille de 11 %, ce qui suffit à faire déborder un budget serré.

---

## Support matériel

| Génération | sm | BF16 | INT8 TC | FP8 | FP4 |
|---|---|---|---|---|---|
| Pascal (GTX 10xx) | 6.1 | — | — | — | — |
| Turing (RTX 20xx) | 7.5 | — | ✓ | — | — |
| Ampere (A100, RTX 30xx) | 8.0 / 8.6 | ✓ | ✓ | — | — |
| Ada (RTX 40xx, L40S) | 8.9 | ✓ | ✓ | ✓ | — |
| Hopper (H100) | 9.0 | ✓ | ✓ | ✓ | — |
| Blackwell (B200, RTX 50xx) | 10.0 / 12.0 | ✓ | ✓ | ✓ | ✓ |

L'INT4 *weight-only* (Marlin, AWQ, k-quants) fonctionne partout où il y a des tensor cores FP16 : le kernel déquantifie vers FP16, il n'a pas besoin d'unités entières dédiées. À ne pas confondre avec les tensor cores INT4 natifs (`mma.s4`), présents de Turing à Ada et retirés à partir de Hopper.

---

## Structure

```
d2/                       # noyau — définition unique de chaque grandeur
├── formats.py            # tailles exactes ggml + quantificateurs aller-retour
├── spectral.py           # exposant α (Hill + KS), rang stable, rang effectif
├── sensitivity.py        # classification, importances, matrice de coût Ω
├── hardware.py           # capacités GPU, profils, roofline
├── planner.py            # ILP sous contrainte mémoire, budget KV
├── loaders.py            # GGUF (déquantification llama.cpp), safetensors, HF
├── exporters.py          # llama.cpp, TensorRT-LLM, correspondance HF↔GGUF
├── report.py             # restitution ; mesuré et estimé jamais confondus
├── console.py            # sortie UTF-8 sûre sous Windows
└── cli.py                # implémentation du CLI

tests/                    # 204 tests, pytest tests/ -q
├── test_formats.py       # tailles ggml, monotonie de l'erreur
├── test_spectral.py      # estimateur validé sur spectres synthétiques
├── test_sensitivity.py   # classification, imatrix
├── test_planner.py       # optimalité vérifiée par énumération, faisabilité
├── test_hardware.py      # capacités par compute capability
├── test_exporters.py     # noms de tenseurs, options réelles des outils
└── test_literature.py    # invariants issus des articles cités

d2_rtx_gguf_profiler.py   # CLI principal (délègue à d2/cli.py)
alpha_spectral_scanner.py # rapport α seul
d2_dynamic_v13.py         # politique de cache KV (K/V, tokens sink)
d2_profiler.py            # latences roofline, mesures GPU optionnelles
spectral_theory.py        # module de référence spectral
app.py  d2_ui.py          # interfaces web et bureau
d2_production.py          # façade de compatibilité avec l'API v1
example/run_example.py    # démonstration sans modèle
THEORY.md                 # fondements et limites
MIGRATION.md              # ce qui a changé depuis le v1, et pourquoi
```

---

## Fondements

| Élément | Référence |
|---|---|
| Allocation de bits par ILP sous contrainte de taille | Yao et al., *HAWQ-V3*, ICML 2021 |
| Erreur pondérée par les activations | Frantar et al., *GPTQ*, ICLR 2023 ; Lin et al., *AWQ*, MLSys 2024 |
| Canaux aberrants, sensibilité des couches | Dettmers et al., *LLM.int8()*, NeurIPS 2022 ; Xiao et al., *SmoothQuant*, ICML 2023 |
| Sensibilité relative K vs V, quantification du cache | Hooper et al., *KVQuant*, NeurIPS 2024 ; Liu et al., *KIVI*, ICML 2024 |
| Tokens « sink » conservés en haute précision | Xiao et al., *StreamingLLM*, ICLR 2024 |
| Exposant spectral α | Martin & Mahoney, JMLR 22(165), 2021 |
| Estimation de l'exposant de queue | Hill, *Ann. Stat.* 3(5), 1975 ; Clauset et al., *SIAM Review* 51(4), 2009 |
| Rang effectif | Roy & Vetterli, EUSIPCO 2007 |
| Modèle roofline | Williams et al., *CACM* 52(4), 2009 |
| Microscaling FP4 | OCP *MX Formats Specification* v1.0, 2023 |

Voir [THEORY.md](THEORY.md) pour les dérivations, et en particulier pour ce que l'exposant α **ne** permet **pas** de conclure.

---

## Ce que D2 ne fait pas

Dit explicitement, parce que les versions antérieures de ce README l'affirmaient :

- **Il ne mesure pas la perplexité.** Aucun chiffre de qualité aval n'est produit ici. Pour cela, quantifiez puis lancez `llama-perplexity`.
- **Il ne mesure pas le débit.** Les tokens/s affichés sont des **bornes** issues de la bande passante constructeur, marquées `~`. Un vrai chiffre demande une exécution du modèle.
- **Il ne quantifie pas le modèle.** Il produit un plan et la commande à exécuter ; c'est `llama-quantize` qui fait le travail.
- **Il ne fait pas commuter la précision des poids à l'exécution.** Aucun runtime ne l'expose, et requantifier à chaud coûterait bien plus que ce qu'on économise. Seule la précision du **cache KV** est réglable dynamiquement (`d2_dynamic_v13.py`).

---

## Migration depuis les versions antérieures

Les modules `d2_compiler`, `d2_compiler_v2`, `quant_graph_compiler_v2`, `d2_qdf_bayesian*`, `v18` et `d2_compile_pipeline` étaient six implémentations concurrentes du même calcul, avec des conventions contradictoires — dont deux règles opposées pour α. Ils sont remplacés par des façades qui indiquent la fonction correspondante du noyau. Voir [MIGRATION.md](MIGRATION.md).

`d2_production.solve_quantization_plan` reste utilisable ; `w_risk` / `lam` y sont dépréciés et réinterprétés en plafond d'erreur par couche.

---

## Tests

```bash
pip install pytest
pytest tests/ -q
```

---

## Licence

MIT — voir [LICENSE](LICENSE).
