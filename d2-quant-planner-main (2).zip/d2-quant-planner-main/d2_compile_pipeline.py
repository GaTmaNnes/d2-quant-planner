#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_compile_pipeline — remplacé par `d2_rtx_gguf_profiler.py`
=============================================================

Ce fichier était la quatrième implémentation du même pipeline, avec des
constantes contradictoires par rapport aux trois autres.

Pourquoi il a été retiré
------------------------
* **`_ilp_scipy` n'était pas un ILP.** Il appelait `linprog` avec
  `bounds=(0, 1)` continus, c'est-à-dire la relaxation linéaire, puis
  arrondissait par `x[vi] > 0.5`. La contrainte VRAM pouvait être violée après
  arrondi, et si trois variables d'une même couche valaient 0.33, aucune
  n'était retenue. Le README annonçait « Optimisation ILP sous contrainte
  VRAM (scipy.optimize) ».
* **Le glouton augmentait la mémoire en cas de dépassement.** Phase 2 partait
  du plan le plus agressif puis « remontait vers FP16 », ce qui accroît
  `total`. La boucle ne pouvait pas atteindre `total <= budget_gb`.
* **`infer_kv_params` doublait le nombre de couches.** Il comptait les
  tenseurs de classe `attn` — soit `q_proj` *et* `o_proj` par bloc — au lieu
  des blocs transformer. Le budget de cache KV était surestimé d'un facteur 2.
* **Alphas de démo non reproductibles.** `alpha_w_synthetic` utilisait
  `hash(cls)` dans la graine ; le hachage des chaînes est randomisé par
  processus, donc le plan « synthétique calibré » changeait à chaque exécution.
* **`SINK_THRESHOLD = 128`** ici contre `DEFAULT_SINK = 4` dans
  `d2_dynamic_v13`, pour la même notion.
* **Le bug « FIX-1 » de l'hystérésis subsistait** : `D2DynamicRouter.route`
  calculait `sig` à partir du switch *désiré*, pas du switch *effectif*, alors
  que `d2_dynamic_v13` documentait ce correctif comme appliqué.
* **`export_llamacpp` tronquait à 8 tenseurs** (`tensor_args[:8]`) : la
  commande affichée ne couvrait qu'une fraction du modèle.
* `alpha_w_from_bytes` calculait un coefficient de variation sur les 8192
  premiers octets bruts interprétés en `uint8` — sans rapport avec le spectre
  des poids.
* `bottleneck_analysis` comparait une latence mémoire à
  `2*rows*cols / 200e12`, soit un batch de 1 : toutes les couches étaient
  déclarées « MEM » par construction.

Correspondance
--------------
* pipeline complet -> ``python d2_rtx_gguf_profiler.py``
* ``--target tensorrt`` -> ``python d2_rtx_gguf_profiler.py --target tensorrt``
* ``kv_cache_gb`` -> ``d2.planner.kv_cache_bytes``
* ``D2DynamicRouter`` -> ``d2_dynamic_v13.kv_plan``
* ``bottleneck_analysis`` -> ``d2.hardware.roofline_regime`` / ``d2_profiler.py``
* ``ilp_optimize`` -> ``d2.plan_layers``
* ``export_llamacpp`` -> ``d2.export_llama_cpp``
* ``export_tensorrt`` -> ``d2.export_tensorrt_llm``

Équivalents en ligne de commande
--------------------------------
::

    # ancien : python d2_compile_pipeline.py --demo --budget 8.0
    python d2_rtx_gguf_profiler.py --demo --budget 8.0

    # ancien : python d2_compile_pipeline.py --demo --budget 8.0 --target tensorrt
    python d2_rtx_gguf_profiler.py --demo --budget 8.0 --target tensorrt

    # ancien : python d2_compile_pipeline.py model.gguf --budget 8.0 --target llamacpp
    python d2_rtx_gguf_profiler.py model.gguf --budget 8.0 --target llamacpp

Ce fichier peut être supprimé sans conséquence : rien dans le dépôt ne
l'importe.
"""

from __future__ import annotations

import sys

_MOVED = {
    "ilp_optimize": "d2.plan_layers",
    "kv_cache_gb": "d2.planner.kv_cache_bytes",
    "bottleneck_analysis": "d2.hardware.roofline_regime",
    "D2DynamicRouter": "d2_dynamic_v13.kv_plan",
    "export_llamacpp": "d2.export_llama_cpp",
    "export_tensorrt": "d2.export_tensorrt_llm",
    "make_demo_layers": "d2.synthetic_model",
    "classify": "d2.classify",
    "run_pipeline": "d2_rtx_gguf_profiler.main",
}

_MESSAGE = (
    "d2_compile_pipeline a ete remplace par d2_rtx_gguf_profiler.py.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "\nEquivalent :\n"
    "  python d2_rtx_gguf_profiler.py --demo --budget 8.0 [--target tensorrt]\n"
    "\nVoir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    target = _MOVED.get(name)
    if target:
        raise AttributeError(name + " a ete remplace par " + target + ".\n" + _MESSAGE)
    raise AttributeError(
        "module 'd2_compile_pipeline' n'a pas d'attribut " + repr(name)
        + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
