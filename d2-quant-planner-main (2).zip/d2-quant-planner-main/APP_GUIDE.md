# Qwen3.5-9B Optimizer - Desktop Application Guide

## 🚀 Quick Start

### Windows
```powershell
# Double-click this file:
launch_app.ps1

# Or run from PowerShell:
.\launch_app.ps1
```

### Linux/Mac
```bash
python3 qwen_optimizer_app.py
```

---

## 📋 What the App Does

The Qwen3.5-9B Optimizer is a **complete desktop application** that:

1. ✅ **Auto-downloads llama.cpp** - No manual installation needed
2. ✅ **Selects model** - GGUF or Safetensors from HuggingFace
3. ✅ **Chooses strategy** - 4 optimization profiles (Conservative/Balanced/Quality/Maximum)
4. ✅ **Quantizes automatically** - With real-time progress
5. ✅ **Shows logs** - Live output of all operations
6. ✅ **Benchmarks** - Test performance on your hardware
7. ✅ **Runs model** - Interactive chat with the model

---

## 🎯 UI Walkthrough

### Left Panel - Controls

#### Model Selection
- **GGUF - Local**: Use a `.gguf` file on your computer
- **Safetensors - HuggingFace**: Download from HuggingFace Hub
- **Browse Button**: Select your model file

#### Quantization Strategy
- **⭐ Balanced (12GB)** - Recommended for most users
  - Good balance of quality and speed
  - 7.0 tokens/sec estimated
  - 2.8 GB model size

- **Conservative (8GB)** - Minimal RAM usage
  - Maximum compression
  - 6.0 tokens/sec estimated
  - 2.2 GB model size

- **Quality (16GB)** - High fidelity
  - Better quality than Balanced
  - 6.5 tokens/sec estimated
  - 3.3 GB model size

- **Maximum (24GB)** - Best quality
  - Minimal quantization loss
  - 6.0 tokens/sec estimated (BW limited)
  - 3.8 GB model size

#### Options
- **GPU Layers**: How many layers to run on GPU (0-33)
  - 33 = Fully on GPU (fastest)
  - 0 = CPU only (slowest)
  - Default: 33

- **Context Length**: Maximum tokens in prompt/response
  - Min: 512 tokens
  - Max: 32768 tokens
  - Default: 8192 tokens

#### Actions
- **🚀 Start Quantization** - Begin quantizing the model
- **📊 Benchmark** - Measure performance on selected model
- **▶️ Run Model** - Launch interactive chat

### Right Panel - Logs & Results

#### 📋 Logs Tab
- Real-time output of all operations
- Shows download progress
- Quantization process details
- Error messages

#### ✅ Results Tab
- List of generated GGUF files
- File sizes
- Status indicators
- Quick launch buttons

#### Progress Bar
- Overall operation progress
- Updates in real-time

#### Status Label
- Current operation status
- Ready/Processing/Complete

---

## 📖 Step-by-Step Usage

### 1. Start the Application
```powershell
.\launch_app.ps1
```

### 2. Wait for llama.cpp Download
The app will:
- Check if llama.cpp is installed
- If not, download automatically (~100 MB)
- Extract and prepare binaries

### 3. Select Your Model
- Click **"Browse Local Model..."**
- Choose your `.gguf` or `.safetensors` file
- The app shows the selected model name

### 4. Choose Quantization Strategy
- Click the dropdown in "Quantization Strategy"
- Read the description of each option
- Default is **Balanced (⭐ Recommended)**

### 5. Configure Options (Optional)
- **GPU Layers**: Keep at 33 (all on GPU)
- **Context Length**: Keep at 8192 (good default)

### 6. Start Quantization
- Click **"🚀 Start Quantization"**
- Watch the logs for progress
- This takes 5-15 minutes depending on strategy

### 7. View Results
- Click the **"✅ Results"** tab
- See generated GGUF files and sizes
- Click **"Launch"** to run a model immediately

### 8. Benchmark or Run
- **📊 Benchmark**: Tests performance (quick)
- **▶️ Run Model**: Opens interactive chat

---

## 🎮 Using the Model

### Interactive Chat
When you click "▶️ Run Model", a terminal opens with:

```
 __ __ _ __       _ _
/  \  \/ / \ /\  | | \ /\
\  /\  /|  X  \ | |  X  \
 \/ /_/ |_/ \_||_| /_/ \_\

main: loaded model

> Your prompt here
```

Type your prompt and press Enter. The model responds.

Commands:
- Type prompts normally
- Press **Ctrl+C** to stop response
- Type `quit` or `exit` to close

### Examples
```
> What is machine learning?
> Explain quantum computing
> Write a Python function to sum numbers
> Translate this to French: Hello world
```

---

## 📊 Understanding the Strategies

### Conservative (8GB)
**Best for:** Edge devices, limited RAM
```
Attention: Q4_K (4.5 bits/weight)
MLP:       Q4_K (4.5 bits/weight)
Embedding: Q5_K (5.5 bits/weight)
```

### Balanced (12GB) ⭐
**Best for:** General purpose, most users
```
Attention: Q5_K (5.5 bits/weight)   ← Sensitive, keep higher quality
MLP:       Q4_K (4.5 bits/weight)   ← Robust, can compress more
Embedding: F16  (16 bits/weight)    ← Critical, keep high quality
```

### Quality (16GB)
**Best for:** When quality matters more than speed
```
Attention: Q6_K (6.56 bits/weight)
MLP:       Q5_K (5.5 bits/weight)
Embedding: F16  (16 bits/weight)
```

### Maximum (24GB)
**Best for:** Reference quality, research
```
Attention: F16  (16 bits/weight)    ← No quantization
MLP:       Q6_K (6.56 bits/weight)
Embedding: F16  (16 bits/weight)    ← No quantization
```

---

## ⚙️ Advanced Settings

### Modify GPU Layers
If you have a weaker GPU:
- **Decrease GPU Layers** (e.g., 16 instead of 33)
- This uses CPU for some layers
- Trades speed for lower VRAM usage

Example:
```
RTX 4090:    33 layers on GPU (all)
RTX 4070:    20 layers on GPU (some on CPU)
RTX 3060:    10 layers on GPU (most on CPU)
```

### Change Context Length
If you need longer prompts:
- **Increase Context Length** (e.g., 16384)
- Uses more VRAM for KV cache
- Better for documents/multi-turn chat

Memory usage approximately:
- 8K context:   ~2 GB KV cache
- 16K context:  ~4 GB KV cache
- 32K context:  ~8 GB KV cache

---

## 🔧 Troubleshooting

### "llama-quantize not found"
**Solution:** The app auto-downloads it, wait 1-2 minutes

### "Model file not found"
**Solution:** Click "Browse Local Model..." and select your file

### "Quantization failed"
**Possible causes:**
- Insufficient disk space
- File permissions issue
- Corrupted model file
- Run as administrator if needed

### "Out of memory"
**Solution:**
- Use smaller strategy (Conservative instead of Maximum)
- Close other programs
- Increase swap/page file size

### Model runs very slowly
**Solution:**
- Check GPU Layers setting (should be 33)
- Reduce context length
- Close other GPU programs
- Use smaller strategy

---

## 📈 Performance Tips

### Maximize Speed
1. Set GPU Layers to 33
2. Use Balanced or Conservative strategy
3. Set Context to 4096 or 8192
4. Close other applications
5. Disable GPU power saving

### Maximize Quality
1. Use Quality or Maximum strategy
2. Keep Context at 8192+
3. Don't compromise on GPU layers
4. Use models specifically trained for your task

### Balance (Recommended)
1. Use Balanced strategy
2. Set GPU Layers to 33
3. Context: 8192
4. Benchmark first to understand performance

---

## 📚 File Locations

After quantization, files are saved in:
```
qwen_optimized/
├── qwen-conservative-8gb.gguf
├── qwen-balanced-12gb.gguf
├── qwen-quality-16gb.gguf
├── qwen-maximum-24gb.gguf
├── quantize_commands.json
└── (logs and reports)
```

You can:
- Copy these files to other machines
- Share with colleagues
- Use with any llama.cpp-compatible tool

---

## 🔗 Resources

- **llama.cpp**: https://github.com/ggerganov/llama.cpp
- **Qwen Model**: https://huggingface.co/Qwen/Qwen3.5-9B
- **GGUF Format**: https://github.com/ggerganov/gguf

---

## 💡 Tips & Tricks

### Batch Processing
Quantize multiple models at once:
1. Generate first model
2. While it's processing, start the app again (different window)
3. Select different model, strategy, click Quantize

### Comparing Models
1. Quantize same model with different strategies
2. Use Benchmark on each
3. Compare speeds and sizes

### Sharing Quantized Models
The optimized GGUFs can be shared:
- Copy the `.gguf` file
- No license issues (it's your own quantization)
- Works on any system with llama.cpp

---

## 🆘 Getting Help

If you encounter issues:

1. **Check Logs** - The app shows detailed logs of everything
2. **Verify llama.cpp** - Make sure it downloaded successfully
3. **Test Model** - Verify your model file is valid
4. **Check Disk Space** - Need ~20 GB free for operations
5. **Run as Admin** - Sometimes helps with permissions

---

**Happy quantizing! 🚀**

For more info: https://github.com/ggerganov/llama.cpp
