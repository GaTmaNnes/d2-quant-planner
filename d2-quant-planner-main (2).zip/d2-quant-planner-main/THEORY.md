# Fondements

Ce document explique sur quoi repose D2, et — tout aussi important — ce qu'il ne peut pas justifier. La version précédente de ce fichier affirmait des correspondances qui n'existent pas dans la littérature ; les passages concernés sont signalés.

---

## 1. Le problème

Soit un modèle de `n` tenseurs de poids `W₁ … Wₙ` et un ensemble de formats `Q = {q₁ … q_P}`. On cherche l'assignation `f : {1…n} → Q` qui minimise la dégradation du modèle sous une contrainte de taille :

```
min   Σᵢ Ω(i, f(i))
s.c.  Σᵢ octets(Wᵢ, f(i)) ≤ B
```

C'est un **sac à dos à choix multiple**, NP-difficile en général mais résolu exactement en quelques secondes pour les tailles en jeu (quelques centaines de tenseurs, une dizaine de formats) par un solveur MIP. D2 utilise `scipy.optimize.milp`, qui s'appuie sur HiGHS.

La formulation est celle de **HAWQ-V3** (Yao et al., ICML 2021), à ceci près que HAWQ estime `Ω` par la trace du Hessien, ce qui demande une rétropropagation sur des données de calibration. D2 vise le cas où l'on ne dispose que des poids.

---

## 2. Le coût qualité Ω

### 2.1 Justification

Pour une couche linéaire `Y = W·X`, remplacer `W` par `Ŵ = Q(W)` produit une perturbation `ΔY = (W − Ŵ)·X`. En espérance sur les activations :

```
E‖ΔY‖²  =  E‖ΔW·x‖²  =  tr(ΔW · Σₓ · ΔWᵀ)
```

où `Σₓ = E[x·xᵀ]` est la covariance des activations d'entrée. Deux régimes :

- **Sans statistiques d'activation.** En supposant `Σₓ = σ²·I` (activations isotropes), on obtient `E‖ΔY‖² = σ²·‖ΔW‖²_F`. La norme de Frobenius de l'erreur de quantification est alors la bonne grandeur.
- **Avec une imatrix.** En ne gardant que la diagonale `Σₓ ≈ diag(s)` avec `s = E[x²]` par canal :

```
E‖ΔY‖²  ≈  ‖ΔW · diag(√s)‖²_F
```

C'est **exactement** l'objectif minimisé par GPTQ (Frantar et al., ICLR 2023), par AWQ (Lin et al., MLSys 2024) et par l'`imatrix` de llama.cpp. D2 ne fait donc rien d'original ici : il applique le critère standard au choix du *format*, là où GPTQ et AWQ l'appliquent au choix des *valeurs quantifiées*.

### 2.2 Additivité entre couches

Sommer les `Ω(i, ·)` suppose que les contributions des couches sont indépendantes, c'est-à-dire que le Hessien du modèle est bloc-diagonal par couche. C'est l'hypothèse commune à HAWQ, GPTQ et SqueezeLLM. Elle est fausse en toute rigueur — les erreurs se propagent et peuvent se composer — mais elle rend le problème traitable et donne empiriquement de bons résultats. **C'est une approximation, pas un théorème.**

### 2.3 Forme retenue

```
Ω(i, q) = cᵢ · ( ‖Wᵢ − Q_q(Wᵢ)‖_F(s) / ‖Wᵢ‖_F(s) )²
```

L'erreur est **relative** pour que des couches d'échelles différentes soient comparables, et **au carré** pour rester homogène à `E‖ΔY‖²`. Le préfacteur `cᵢ` est décrit au §4.

L'erreur `‖Wᵢ − Q_q(Wᵢ)‖` est **mesurée** : `d2.formats.roundtrip` quantifie puis déquantifie réellement la matrice. C'est le changement de fond par rapport aux versions antérieures, qui posaient un `risk ∈ {0.00, 0.35, 1.00}` par format, sans source.

---

## 3. Les formats

### 3.1 Les échelles comptent

Un `Q4_K` ne fait pas 4 bits par poids. La structure ggml d'un super-bloc de 256 poids est :

```
d      : f16       →   2 octets
dmin   : f16       →   2
scales : 12 octets →  12       (8 échelles + 8 minima, 6 bits chacun)
qs     : 128       → 128       (256 poids × 4 bits)
                     ─────
                     144 octets  =  4,5 bits/poids
```

Ignorer les métadonnées sous-estime la taille de 11 %. Toutes les valeurs de `d2/formats.py` viennent de `ggml-common.h` et sont vérifiées dans `tests/test_formats.py`.

| Format | Bloc | Octets/bloc | bits/poids |
|---|---:|---:|---:|
| Q8_0 | 32 | 34 | 8,50 |
| Q6_K | 256 | 210 | 6,5625 |
| Q5_K | 256 | 176 | 5,50 |
| Q4_K | 256 | 144 | 4,50 |
| Q3_K | 256 | 110 | 3,4375 |
| Q2_K | 256 | 84 | 2,625 |
| NVFP4 | 16 | 9 | 4,50 |
| MXFP4 | 32 | 17 | 4,25 |

### 3.2 Microscaling FP4

NVFP4 (Blackwell) et MXFP4 (spécification OCP MX v1.0) encodent chaque poids en **E2M1** — 1 bit de signe, 2 d'exposant, 1 de mantisse — soit la grille `{0, ±0,5, ±1, ±1,5, ±2, ±3, ±4, ±6}`. Ils diffèrent par l'échelle partagée : E4M3 par bloc de 16 pour NVFP4, E8M0 (puissance de deux exacte) par bloc de 32 pour MXFP4.

À taille égale (4,5 bits/poids), NVFP4 fait moins d'erreur que Q4_0 sur des poids à queue lourde : la grille E2M1 est non uniforme et alloue plus de résolution près de zéro, là où se concentre la masse. Vérifié dans `tests/test_formats.py::test_nvfp4_beats_q4_0_at_similar_size`.

### 3.3 Limite assumée

llama.cpp choisit les échelles de ses K-quants par une recherche itérative pondérée (`make_qkx2_quants`, `make_qx_quants`), pas par un simple min/max. D2 reproduit la **structure** exacte des blocs — taille de sous-bloc, bits d'échelle, bits de poids — avec un choix d'échelle direct. L'erreur simulée est donc une **borne supérieure**, pessimiste d'environ 5 à 15 % sur Q4_K. C'est conservateur dans le bon sens : le planificateur ne sous-estime jamais le risque.

---

## 4. Importance des couches

En l'absence d'imatrix, `cᵢ` encode des a priori issus de deux sources convergentes.

**Le mélange k-quant de llama.cpp** (`llama_tensor_get_type`) est calibré empiriquement sur la perplexité. Il remonte systématiquement `attn_v` et `ffn_down` d'un cran par rapport au type nominal, traite `token_embd` et `output.weight` à part, et laisse les normes en F32.

**La littérature sur les canaux aberrants** aboutit aux mêmes couches. LLM.int8() (Dettmers et al., NeurIPS 2022) montre qu'au-delà de 6,7 milliards de paramètres, des canaux aberrants systématiques apparaissent et concentrent l'essentiel de l'erreur de quantification. AWQ (Lin et al., MLSys 2024) mesure que ~1 % des canaux, identifiés par la magnitude des *activations*, portent la majorité de la dégradation.

| Classe | `cᵢ` | Motif |
|---|---:|---|
| norm, bias, meta | ∞ | jamais quantifiées (contrainte dure) |
| head (`output.weight`) | 6,0 | projection des logits, erreur non amortie |
| ssm_conv | 5,0 | récurrence : l'erreur s'accumule dans le temps |
| embed | 4,0 | table d'embedding |
| attn_v, ffn_down | 2,5 | remontés par llama.cpp, saillants chez AWQ |
| attn_o | 1,6 | |
| attn_qkv | 1,4 | fusionné |
| attn_k | 1,3 | sensible via `QKᵀ` (KVQuant) |
| attn_q, ffn_gate, ffn_up | 1,0 | référence |

Les blocs de bord (deux premiers et deux derniers) reçoivent un facteur 1,5, conformément aux mélanges k-quant et à la localisation des canaux aberrants.

**Ces valeurs sont des a priori.** Avec `--imatrix`, la pondération vient de statistiques mesurées et le rôle de `cᵢ` devient marginal.

---

## 5. Le modèle roofline

Une couche linéaire lit `m·n·bpe` octets pour effectuer `2·m·n·B` opérations, où `B` est le batch. L'intensité arithmétique vaut donc `2B/bpe` FLOP par octet.

Sur une RTX 4090 (1008 Go/s, 165 TFLOPS FP16), le point d'inflexion du roofline est à `165e12 / 1008e9 ≈ 164` FLOP/octet. À `B = 1` et `bpe = 2`, l'intensité vaut 1 : on est **deux ordres de grandeur** dans le régime mémoire.

Deux conséquences :

1. **En décodage, la latence est proportionnelle aux octets lus.** Réduire la taille est le levier de vitesse, et la contrainte mémoire du planificateur capture donc déjà le gain de débit. C'est pourquoi il n'y a pas de terme de vitesse séparé dans l'objectif : en ajouter un reviendrait à compter deux fois la même grandeur.
2. **Le prefill est un problème différent.** À `B ≥ 512` on bascule côté compute, et le format compte moins que le kernel. D2 planifie pour le décodage ; les bornes affichées le disent.

Le facteur d'efficacité (0,80 par défaut) rend compte de l'écart entre bande passante crête et débit atteint sur des GEMV. C'est un ordre de grandeur mesuré usuellement sur llama.cpp, pas une constante universelle.

---

## 6. Cache KV

```
octets = 2 (K et V) × n_blocs × ctx × n_têtes_kv × dim_tête × bpe
```

`n_blocs` est le nombre de **blocs transformer**. Compter les tenseurs d'attention double le résultat, puisqu'il y a `q_proj` et `o_proj` par bloc.

À 128 K tokens sur un modèle de 8 milliards de paramètres avec GQA 8 têtes KV, le cache KV en F16 dépasse la taille des poids en Q4_K. Ignorer le cache rend donc tout plan long-contexte faux. Vérifié dans `tests/test_literature.py::test_kv_cache_dominates_at_long_context`.

**K et V ne se compressent pas également.** KVQuant (Hooper et al., NeurIPS 2024) et KIVI (Liu et al., ICML 2024) établissent que K supporte moins bien la quantification que V — K bénéficie d'une quantification par canal, V par token. `d2_dynamic_v13.kv_plan` dégrade donc V avant K.

**Tokens « sink ».** StreamingLLM (Xiao et al., ICLR 2024) montre que les tout premiers tokens captent une masse d'attention disproportionnée et que les conserver en haute précision suffit à préserver la génération longue. La littérature valide **1 à 4 tokens**. Les versions antérieures de ce dépôt en protégeaient 128, soit un surcoût de deux ordres de grandeur sans justification.

---

## 7. L'exposant spectral α — et ses limites

### 7.1 Définition

Martin & Mahoney (JMLR 2021) ajustent une loi de puissance sur la densité spectrale empirique des valeurs propres de `X = WᵀW` :

```
ρ(λ) ∝ λ^(−α)   pour λ ∈ [λ_min, λ_max]
```

Interprétation, pour la **qualité d'entraînement** :

| α | Lecture |
|---|---|
| < 2 | queue très lourde, couche fortement corrélée, possiblement sur-entraînée |
| 2 – 4 | bien entraînée (auto-régularisation à queue lourde) |
| 4 – 6 | moyennement entraînée |
| > 6 | proche d'une matrice aléatoire, sous-entraînée |

### 7.2 α n'est pas `2 × pente`

Une erreur des versions antérieures, corrigée ici. Ajuster `log σᵢ = −β log i + c` mesure la décroissance en fonction du **rang**, pas la densité spectrale. Si `λᵢ = C·i^(−γ)` avec `γ = 2β`, le nombre de valeurs propres au-dessus de `λ` vaut `N(λ) = (C/λ)^(1/γ)`, donc la queue de la CDF est en `λ^(−1/γ)` et la densité en `λ^(−(1+1/γ))` :

```
α = 1 + 1/(2β)
```

Pour `β = 0,5`, la formule correcte donne α = 2,0 ; `2β` donnait 1,0. La conversion et l'estimateur de Hill sont vérifiés l'un contre l'autre sur des spectres synthétiques dans `tests/test_spectral.py`.

### 7.3 Estimation

Estimateur de Hill (1975) sur la queue :

```
α̂ = 1 + k / Σᵢ₌₁ᵏ ln(λ₍ᵢ₎ / x_min)
```

avec balayage de `x_min` minimisant la distance de Kolmogorov–Smirnov entre la queue empirique et la loi ajustée (Clauset, Shalizi & Newman, SIAM Review 2009). Une régression log-log sur tout le spectre mélange le « bulk » de Marchenko–Pastur — du bruit — et la queue, ce qui biaise fortement α.

**Il n'y a pas de p-valeur.** L'obtenir correctement demande le bootstrap semi-paramétrique de Clauset et al. (§4.1). Une distance KS faible indique un bon ajustement relatif ; elle ne teste aucune hypothèse. Les versions antérieures appelaient `ks_2samp` entre les valeurs singulières et une suite **déterministe** `i^(−β)` renormalisée, et en tiraient un booléen `is_power_law` : un test à deux échantillons suppose deux tirages aléatoires, la p-valeur obtenue n'avait aucune interprétation.

### 7.4 Ce que α ne permet pas de conclure

**α mesure la qualité d'entraînement, pas la robustesse à la quantification.** Aucun travail publié n'établit de correspondance entre α et une largeur de bits soutenable.

Les versions antérieures de ce dépôt appliquaient α comme critère principal, dans **deux directions opposées** selon le fichier : α élevé signifiait « quantifier agressivement » dans le scanner RTX et « protéger en FP16 » dans le module de théorie. Les deux ne peuvent pas être vraies, et aucun chemin de code ne réconciliait les deux règles.

α est donc exporté comme **diagnostic** — utile pour repérer une couche mal entraînée ou dégénérée — et n'entre pas dans la décision. `spectral_theory.QuantizationPolicy.recommend_dtype` lève désormais `NotImplementedError` avec cette explication.

### 7.5 Ce qui reste utile du spectre

- **Rang stable** `‖W‖²_F / ‖W‖²₂` et **rang effectif** `exp(H)` (Roy & Vetterli, EUSIPCO 2007) mesurent la concentration spectrale. Ils prédisent la compressibilité **par approximation de rang faible**, ce qui n'est pas la même chose que la quantification : tronquer des valeurs singulières et réduire la précision de chaque coefficient sont deux opérations différentes.
- Un rang effectif très bas signale une couche possiblement redondante — information intéressante, mais qui relève de l'élagage ou de la factorisation, pas du choix de format.

---

## 8. Ce qui n'est pas démontré ici

- **Aucune validation aval.** Rien dans ce dépôt ne mesure la perplexité ou la qualité de génération. Affirmer qu'un plan D2 bat un préréglage uniforme de même taille demanderait de quantifier les deux et de lancer `llama-perplexity` sur un jeu d'évaluation. Tant que ce n'est pas fait, aucun gain n'est revendiqué. Les versions antérieures publiaient des tableaux de « résultats mesurés » (−47 % VRAM, +47 % TPS) qu'aucun script du dépôt ne permettait de reproduire.
- **L'additivité inter-couches est une approximation** (§2.2).
- **Les erreurs des K-quants sont majorées** (§3.3).
- **Les préfacteurs `cᵢ` sont des a priori** tant qu'aucune imatrix n'est fournie (§4).

---

## Bibliographie

- Clauset, Shalizi & Newman. *Power-law distributions in empirical data.* SIAM Review 51(4), 2009.
- Dettmers, Lewis, Belkada & Zettlemoyer. *LLM.int8(): 8-bit Matrix Multiplication for Transformers at Scale.* NeurIPS 2022.
- Dong, Yao, Arfeen, Gholami, Mahoney & Keutzer. *HAWQ-V2: Hessian Aware trace-Weighted Quantization.* NeurIPS 2020.
- Frantar, Ashkboos, Hoefler & Alistarh. *GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers.* ICLR 2023.
- Hill. *A simple general approach to inference about the tail of a distribution.* Annals of Statistics 3(5), 1975.
- Hooper, Kim, Mohammadzadeh, Mahoney, Shao, Keutzer & Gholami. *KVQuant: Towards 10 Million Context Length LLM Inference with KV Cache Quantization.* NeurIPS 2024.
- Kim, Hooper, Gholami, Dong, Li, Shen, Mahoney & Keutzer. *SqueezeLLM: Dense-and-Sparse Quantization.* ICML 2024.
- Lin, Tang, Tang, Yang, Chen, Wang, Xiao, Dang, Gan & Han. *AWQ: Activation-aware Weight Quantization for On-Device LLM Compression and Acceleration.* MLSys 2024.
- Liu, Yuan, Jin, Zhong, Xu, Braverman, Chen & Hu. *KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache.* ICML 2024.
- Martin & Mahoney. *Implicit Self-Regularization in Deep Neural Networks.* JMLR 22(165), 2021.
- Martin, Peng & Mahoney. *Predicting trends in the quality of state-of-the-art neural networks without access to training or testing data.* Nature Communications 12:4122, 2021.
- Open Compute Project. *OCP Microscaling Formats (MX) Specification v1.0.* 2023.
- Roy & Vetterli. *The effective rank: a measure of effective dimensionality.* EUSIPCO 2007.
- Williams, Waterman & Patterson. *Roofline: an insightful visual performance model for multicore architectures.* CACM 52(4), 2009.
- Xiao, Lin, Seznec, Wu, Demouth & Han. *SmoothQuant: Accurate and Efficient Post-Training Quantization for Large Language Models.* ICML 2023.
- Xiao, Tian, Chen, Han & Lewis. *Efficient Streaming Language Models with Attention Sinks.* ICLR 2024.
- Yao, Dong, Zheng, Gholami, Yu, Tan, Wang, Huang, Wang, Mahoney & Keutzer. *HAWQ-V3: Dyadic Neural Network Quantization.* ICML 2021.
