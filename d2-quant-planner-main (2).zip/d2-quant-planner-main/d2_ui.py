#!/usr/bin/env python3
"""
D2 — Interface graphique PySide6
=================================

Corrections par rapport au v1 :

* cache HuggingFace codé en dur sur `/tmp/hf_cache` (inutilisable sous Windows) ;
* le thread de résolution n'était jamais nettoyé et les objets `QThread` /
  worker s'accumulaient à chaque clic ;
* `QPalette.Window` était accédé via l'instance, ce qui casse sur les versions
  récentes de PySide6 où les énumérations sont scopées ;
* aucune remontée d'erreur exploitable en cas de budget intenable.

Dépendances : `pip install PySide6` (plus `huggingface_hub`/`safetensors` ou
`gguf` selon la source).

Lancement :
    python d2_ui.py
"""

from __future__ import annotations

import os
import sys
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtGui import QColor, QFont, QPalette
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox, QProgressBar,
    QPushButton, QSlider, QSplitter, QStatusBar, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
)

import d2

DTYPE_COLORS: Dict[str, QColor] = {
    "F16": QColor(70, 130, 180), "BF16": QColor(95, 158, 160),
    "Q8_0": QColor(60, 179, 113), "INT8": QColor(46, 139, 87),
    "Q6_K": QColor(154, 205, 50), "Q5_K": QColor(218, 165, 32),
    "Q4_K": QColor(255, 140, 0), "INT4_AWQ": QColor(255, 127, 80),
    "NVFP4": QColor(220, 20, 60), "Q3_K": QColor(178, 34, 34),
    "Q2_K": QColor(139, 0, 0),
}


class SolverWorker(QObject):
    """Charge les poids et résout le plan hors du thread d'interface."""

    progress = Signal(str)
    finished = Signal(object, object)   # (Plan, GPUCaps)
    failed = Signal(str)

    def __init__(self, source: str, gpu: str, budget_gb: float, ctx_len: int,
                 max_rel_error: Optional[float]):
        super().__init__()
        self.source = source
        self.gpu = gpu
        self.budget_gb = budget_gb
        self.ctx_len = ctx_len
        self.max_rel_error = max_rel_error

    def run(self) -> None:
        try:
            self.progress.emit(f"Chargement de {self.source} ...")
            layers, info = self._load()
            if not layers:
                self.failed.emit("Aucune couche exploitable dans ce modèle.")
                return

            caps = d2.get_profile(self.gpu)
            measure = any(l.weights is not None for l in layers)
            self.progress.emit(
                f"Planification de {len(layers)} couches "
                f"({'erreur mesurée' if measure else 'erreur estimée'}) ..."
            )
            plan = d2.plan_layers(
                layers, caps,
                vram_budget_gb=self.budget_gb,
                ctx_len=self.ctx_len,
                measure=measure,
                max_rel_error=self.max_rel_error if measure else None,
                **d2.kv_geometry(info or {}),
            )
            self.finished.emit(plan, caps)
        except d2.InfeasibleBudget as exc:
            self.failed.emit(f"Budget intenable.\n\n{exc}")
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__} : {exc}")

    def _load(self):
        src = self.source.strip()
        if src.lower().endswith(".gguf"):
            return d2.load_gguf(src, with_spectral=False)
        if os.path.isfile(src):
            return d2.load_safetensors(src)
        # Cache par défaut de huggingface_hub (respecte HF_HOME), pas /tmp.
        return d2.load_huggingface(src)


class D2Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("D2 — Planificateur de quantification")
        self.resize(1200, 780)
        self._plan: Optional[d2.Plan] = None
        self._caps = None
        self._thread: Optional[QThread] = None
        self._worker: Optional[SolverWorker] = None
        self._build_ui()

    # ── Construction ─────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        box = QGroupBox("Paramètres")
        grid = QGridLayout(box)

        grid.addWidget(QLabel("Modèle :"), 0, 0)
        self.model_edit = QLineEdit("gpt2")
        self.model_edit.setPlaceholderText(
            "gpt2 | org/modele | C:/chemin/model.safetensors | C:/chemin/model.gguf"
        )
        grid.addWidget(self.model_edit, 0, 1, 1, 3)

        grid.addWidget(QLabel("Cible GPU :"), 1, 0)
        self.gpu_combo = QComboBox()
        self.gpu_combo.addItems(sorted(d2.GPU_PROFILES))
        self.gpu_combo.setCurrentText("rtx4090")
        self.gpu_combo.currentTextChanged.connect(self._on_gpu_changed)
        grid.addWidget(self.gpu_combo, 1, 1)
        self.gpu_info = QLabel()
        self.gpu_info.setStyleSheet("color: gray;")
        grid.addWidget(self.gpu_info, 1, 2, 1, 2)

        grid.addWidget(QLabel("Budget VRAM :"), 2, 0)
        self.vram_slider = QSlider(Qt.Orientation.Horizontal)
        self.vram_slider.setRange(1, 384)       # ×0.5 Go → [0.5, 192] Go
        self.vram_slider.setValue(16)
        self.vram_label = QLabel("8.0 Go")
        self.vram_slider.valueChanged.connect(
            lambda v: self.vram_label.setText(f"{v / 2:.1f} Go"))
        grid.addWidget(self.vram_slider, 2, 1, 1, 2)
        grid.addWidget(self.vram_label, 2, 3)

        grid.addWidget(QLabel("Contexte :"), 3, 0)
        self.ctx_slider = QSlider(Qt.Orientation.Horizontal)
        self.ctx_slider.setRange(1, 256)        # ×512 tokens
        self.ctx_slider.setValue(8)
        self.ctx_label = QLabel("4096 tokens")
        self.ctx_slider.valueChanged.connect(
            lambda v: self.ctx_label.setText(f"{v * 512} tokens"))
        grid.addWidget(self.ctx_slider, 3, 1, 1, 2)
        grid.addWidget(self.ctx_label, 3, 3)

        grid.addWidget(QLabel("Plafond erreur :"), 4, 0)
        self.err_slider = QSlider(Qt.Orientation.Horizontal)
        self.err_slider.setRange(0, 60)         # ×0.5 % → [0, 30 %]
        self.err_slider.setValue(0)
        self.err_label = QLabel("désactivé")
        self.err_slider.valueChanged.connect(
            lambda v: self.err_label.setText(
                "désactivé" if v == 0 else f"{v / 2:.1f} % par couche"))
        grid.addWidget(self.err_slider, 4, 1, 1, 2)
        grid.addWidget(self.err_label, 4, 3)

        hint = QLabel(
            "Le plan minimise l'erreur de quantification mesurée sous la "
            "contrainte mémoire. Le cache KV est soustrait du budget."
        )
        hint.setStyleSheet("color: gray; font-size: 11px;")
        grid.addWidget(hint, 5, 0, 1, 4)

        btns = QHBoxLayout()
        self.solve_btn = QPushButton("Calculer le plan")
        self.solve_btn.setFixedHeight(34)
        self.solve_btn.setStyleSheet(
            "font-weight: bold; background: #2196F3; color: white;")
        self.solve_btn.clicked.connect(self._on_solve)
        btns.addWidget(self.solve_btn)

        self.export_btn = QPushButton("Exporter (JSON + llama-quantize)")
        self.export_btn.setFixedHeight(34)
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self._on_export)
        btns.addWidget(self.export_btn)
        grid.addLayout(btns, 6, 0, 1, 4)

        root.addWidget(box)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        root.addWidget(self.progress)

        split = QSplitter(Qt.Orientation.Horizontal)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Tenseur", "Classe", "Format", "Taille (Go)", "Erreur rel.", "Ω"])
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setFont(QFont("Consolas", 9))
        split.addWidget(self.table)

        self.summary = QTextEdit()
        self.summary.setReadOnly(True)
        self.summary.setFont(QFont("Consolas", 9))
        self.summary.setMinimumWidth(380)
        split.addWidget(self.summary)
        split.setSizes([760, 400])
        root.addWidget(split)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Prêt.")
        self._on_gpu_changed(self.gpu_combo.currentText())

    # ── Événements ───────────────────────────────────────────────────────────
    def _on_gpu_changed(self, name: str) -> None:
        caps = d2.get_profile(name)
        self.gpu_info.setText(
            f"{caps.sm_str} · {caps.vram_gb:.0f} Go · {caps.bw_gbs:.0f} Go/s · "
            f"formats : {', '.join(d2.supported_formats(caps)[:6])}…"
        )

    def _on_solve(self) -> None:
        source = self.model_edit.text().strip()
        if not source:
            self.status.showMessage("Renseignez un modèle.")
            return
        if self._thread is not None:
            return  # une résolution est déjà en cours

        self.solve_btn.setEnabled(False)
        self.export_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.table.setRowCount(0)
        self.summary.clear()

        err = self.err_slider.value()
        self._thread = QThread(self)
        self._worker = SolverWorker(
            source=source,
            gpu=self.gpu_combo.currentText(),
            budget_gb=self.vram_slider.value() / 2.0,
            ctx_len=self.ctx_slider.value() * 512,
            max_rel_error=(err / 200.0) if err else None,
        )
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self.status.showMessage)
        self._worker.finished.connect(self._on_ready)
        self._worker.failed.connect(self._on_failed)
        self._worker.finished.connect(self._thread.quit)
        self._worker.failed.connect(self._thread.quit)
        # Nettoyage explicite : sans cela le v1 accumulait un QThread par clic.
        self._thread.finished.connect(self._cleanup_thread)
        self._thread.start()

    def _cleanup_thread(self) -> None:
        if self._worker is not None:
            self._worker.deleteLater()
            self._worker = None
        if self._thread is not None:
            self._thread.deleteLater()
            self._thread = None
        self.solve_btn.setEnabled(True)
        self.progress.setVisible(False)

    def _on_ready(self, plan, caps) -> None:
        self._plan, self._caps = plan, caps
        self._fill_table(plan)
        self.summary.setPlainText(
            d2.summarize(plan, caps, ctx_len=self.ctx_slider.value() * 512)
        )
        self.export_btn.setEnabled(True)
        self.status.showMessage(
            f"{len(plan.entries)} couches — {plan.total_bytes / 1e9:.3f} Go "
            f"(solveur {plan.solver})"
        )

    def _on_failed(self, message: str) -> None:
        self.status.showMessage("Échec.")
        QMessageBox.warning(self, "D2", message)

    def _fill_table(self, plan) -> None:
        self.table.setRowCount(len(plan.entries))
        for row, e in enumerate(plan.entries):
            err = f"{e.rel_error:.4f}" if e.rel_error == e.rel_error else "~"
            cells = [e.name, e.cls, e.format, f"{e.bytes / 1e9:.5f}", err,
                     f"{e.omega:.2e}"]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                align = (Qt.AlignmentFlag.AlignLeft if col == 0
                         else Qt.AlignmentFlag.AlignCenter)
                item.setTextAlignment(align | Qt.AlignmentFlag.AlignVCenter)
                if col == 2:
                    item.setBackground(DTYPE_COLORS.get(text, QColor(120, 120, 120)))
                    item.setForeground(QColor(255, 255, 255))
                    f = QFont()
                    f.setBold(True)
                    item.setFont(f)
                if e.forced and col == 0:
                    item.setToolTip("Couche contrainte en haute précision")
                self.table.setItem(row, col, item)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch)

    def _on_export(self) -> None:
        if self._plan is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Exporter le plan", "d2_plan.json", "JSON (*.json)")
        if not path:
            return
        try:
            d2.export_json(self._plan, path)
            payload = d2.export_llama_cpp(
                self._plan, json_path=path.replace(".json", "_llamacpp.json"))
            cmd_path = path.replace(".json", "_cmd.txt")
            with open(cmd_path, "w", encoding="utf-8") as f:
                f.write(payload["command"] + "\n")
        except OSError as exc:
            QMessageBox.warning(self, "D2", f"Écriture impossible : {exc}")
            return
        self.status.showMessage(f"Exporté : {path} et {cmd_path}")


def _dark_palette(app: QApplication) -> None:
    """Palette sombre. Les rôles sont accédés via `QPalette.ColorRole`,
    scopé, et non via l'instance comme dans le v1."""
    role = QPalette.ColorRole
    p = QPalette()
    p.setColor(role.Window, QColor(45, 45, 45))
    p.setColor(role.WindowText, QColor(220, 220, 220))
    p.setColor(role.Base, QColor(35, 35, 35))
    p.setColor(role.AlternateBase, QColor(52, 52, 52))
    p.setColor(role.ToolTipBase, QColor(60, 60, 60))
    p.setColor(role.ToolTipText, QColor(220, 220, 220))
    p.setColor(role.Text, QColor(220, 220, 220))
    p.setColor(role.Button, QColor(60, 60, 60))
    p.setColor(role.ButtonText, QColor(220, 220, 220))
    p.setColor(role.BrightText, QColor(255, 80, 80))
    p.setColor(role.Highlight, QColor(42, 130, 218))
    p.setColor(role.HighlightedText, QColor(0, 0, 0))
    app.setPalette(p)


def main() -> int:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    _dark_palette(app)
    win = D2Window()
    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
