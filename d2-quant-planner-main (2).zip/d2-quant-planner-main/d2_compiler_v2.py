#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_compiler_v2 - remplace par le package `d2`
=============================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
Le « compiler v2 » annoncait sept correctifs ; plusieurs ne fonctionnaient pas :

* **[F5] decode vs prefill** : `_latency(shape, precision, batch=1)` avait bien
  un parametre `batch`, mais `gain()` ne le transmettait jamais. A batch 1 le
  terme memoire domine toujours, donc les deux modes rendaient exactement le
  meme plan.
* **Risque spectral inerte** : `spec_risk` calculait
  `tanh(max(0, alpha_w - 2.0))` alors que `KPEv14` renvoie `-pente`,
  typiquement inferieur a 2. Le terme valait 0 pour toutes les couches, donc
  `sigma_R ~ 0` et la composante spectrale ne pesait rien dans la decision.
* **Glouton a l'envers** : en cas de depassement, `_greedy` « relachait vers
  une precision plus haute », ce qui *augmente* la memoire. La boucle ne
  pouvait pas converger.
* **DP hors budget** : `dp_switching` minimisait cout + transitions sans
  contrainte VRAM, puis testait la faisabilite apres coup.
* **Unites melangees** : budget en GiB (1024**3), affichage du detail en GB
  (1e9) - le detail ne totalisait pas le total affiche.
* Ligne 827 : `r['plan'].count({'precision': p})` comptait des dictionnaires
  dans une liste de dictionnaires, donc toujours 0.
* `KPEv14` definissait `alpha_w = -pente` la ou trois autres modules
  utilisaient `-2*pente`, avec les memes seuils.

Correspondance
--------------
* ``KPEv14`` -> ``d2.spectral.analyze``
* ``from_huggingface`` -> ``d2.load_huggingface``
* ``CostModel`` -> ``d2.sensitivity.sensitivity_matrix + d2.hardware``
* ``MemoryModel`` -> ``d2.planner.MemoryBudget / d2.planner.kv_cache_bytes``
* ``ILPSolver`` -> ``d2.planner.solve``
* ``D2Compiler`` -> ``d2.plan_layers``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'd2_compiler_v2'

_MOVED = {'KPEv14': 'd2.spectral.analyze', 'from_huggingface': 'd2.load_huggingface', 'CostModel': 'd2.sensitivity.sensitivity_matrix + d2.hardware', 'MemoryModel': 'd2.planner.MemoryBudget / d2.planner.kv_cache_bytes', 'ILPSolver': 'd2.planner.solve', 'D2Compiler': 'd2.plan_layers'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
