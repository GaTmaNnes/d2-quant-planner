# Rapport archivé — pipeline Alpha-Graph (Blackwell sm_120)

> **Statut : archivé.** Ce rapport décrit une expérience menée avec la version 1
> du planificateur. Plusieurs de ses conclusions reposent sur des mesures dont
> on sait désormais qu'elles étaient invalides. Les corrections sont signalées
> en ligne. Il est conservé pour la traçabilité, pas comme référence.
>
> Pour l'état actuel : [README.md](README.md), [THEORY.md](THEORY.md),
> [MIGRATION.md](MIGRATION.md).

---

## Objet

Optimisation de Qwen 3.5 pour une RTX 5070, en combinant analyse spectrale
(α_w) et compilation de graphe.

---

## 1. Analyse spectrale — ⚠️ mesures invalides

Le rapport annonçait :

> Les couches d'attention montrent une grande stabilité (α ≈ 1.0). Les couches
> SSM (`ssm_conv1d`) possèdent des pics d'Alpha allant jusqu'à 3.27.

**Ce qui n'allait pas.** Le scanner appliquait un SVD aux octets bruts du
fichier GGUF, c'est-à-dire à des blocs compressés — échelles f16, nibbles
empaquetés, masques — et non aux poids déquantifiés. Le α ≈ 1.0 observé sur la
quasi-totalité des couches n'était pas une mesure de stabilité : c'était le
plancher de `max(−2·pente, 1.0)`.

Le fichier `alpha_w_report.json` produit à l'époque en porte la trace :
**202 de ses 274 tenseurs valent exactement 1,0**, et 82 % finissaient en
`FP16_REQUIRED`.

Par ailleurs, la formule `α = 2 × pente` employée n'est pas l'exposant de
Martin & Mahoney ; la relation correcte est `α = 1 + 1/(2·pente)`
(voir [THEORY.md §7.2](THEORY.md)).

**Refaire la mesure :**

```bash
python alpha_spectral_scanner.py model.gguf --out alpha_w_report.json
```

Cette version déquantifie via `gguf.quants.dequantize`, utilise un estimateur
de Hill avec balayage de `x_min`, et écrit `null` — jamais une constante —
lorsque l'ajustement échoue.

---

## 2. Politique de précision — ⚠️ contradiction interne

Le rapport énonçait :

> α > 1.8 → NVFP4 (compression maximale)
> 1.4 < α < 1.8 → INT8
> α < 1.4 → FP16 (protection logicielle)

et concluait, dans [RAPPORT_FINAL_OPTIMISATION.md](RAPPORT_FINAL_OPTIMISATION.md),
que les couches `ssm_conv1d` — celles dont il relevait les α les plus élevés
(3,27 ; 4,11) — devaient être **verrouillées en FP16**.

Les deux affirmations sont incompatibles : par la politique énoncée, α = 3,27
donne NVFP4, pas FP16. Les deux scripts de build livrés appliquaient d'ailleurs
deux décisions différentes aux mêmes tenseurs — `fp16` dans l'un, `int8` dans
l'autre.

Le fond du problème est que α ne prédit pas la robustesse à la quantification :
c'est un indicateur de qualité d'entraînement. Aucun travail publié ne le relie
à une largeur de bits. Voir [THEORY.md §7.4](THEORY.md).

---

## 3. Compilation de graphe

L'idée de regrouper les couches de même précision pour limiter les
changements de format en cours d'exécution reste valable, mais son intérêt
était surestimé : sur les kernels weight-only (Marlin, k-quants), la
déquantification a lieu dans le kernel et un changement de format entre couches
consécutives ne provoque pas d'aller-retour mémoire supplémentaire.

Le compteur de transitions est conservé (`Plan.n_switches`) comme indicateur,
sans pénalité dans l'objectif tant qu'aucune mesure ne la justifie. La passe
d'optimisation du v1 était de toute façon sans effet (voir
[MIGRATION.md §4](MIGRATION.md)).

---

## 4. Gain annoncé — ⚠️ non vérifié

> Nous estimons une économie de 45 % de bande passante tout en conservant
> 100 % de la logique originale.

Le premier chiffre était une estimation, pas une mesure. Le second n'a pas de
définition opérationnelle : « conserver 100 % de la logique » ne correspond à
aucune métrique évaluable. Aucune perplexité n'a été mesurée.

Une économie de bande passante se calcule directement à partir des tailles de
format, et D2 l'affiche désormais comme une **borne** explicitement étiquetée.
La vérifier demande `llama-perplexity` sur le modèle quantifié.

---

## 5. Fichiers cités

Les fichiers suivants étaient mentionnés mais absents du dépôt :
`precision_map.json`, `hybrid_graph_compiler.py`,
`final_sm120_precision_plan.json`. Le `.gitignore` de l'époque ignorait
`*.json` en bloc, ce qui explique probablement leur absence.

---

## Refaire l'exercice

```bash
# 1. Statistiques d'activation (améliore nettement le plan)
llama-imatrix -m qwen-f16.gguf -f calibration.txt -o qwen.imatrix

# 2. Plan pour RTX 5070 (12 Go, sm_120, NVFP4 disponible)
python d2_rtx_gguf_profiler.py qwen-f16.gguf \
    --gpu-target rtx5070 --budget 12 --ctx 32768 \
    --imatrix qwen.imatrix --spectral

# 3. Politique de cache KV
python d2_dynamic_v13.py --gpu rtx5070 --ctx 32768
```
