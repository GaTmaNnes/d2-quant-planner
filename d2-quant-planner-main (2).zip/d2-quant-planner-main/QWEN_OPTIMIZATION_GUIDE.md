# Qwen3.5-9B Quantization Optimization Guide

**Generated**: 2026-08-05  
**Model**: Qwen3.5-9B-Claude-4.6-OS (9 billion parameters)  
**Current Format**: Q4_K_S with imatrix

---

## 📊 Executive Summary

Your Qwen3.5-9B model has been profiled and optimized for different RAM/performance targets:

| Strategy | RAM | Model Size | Est. TPS | Precision | Use Case |
|----------|-----|------------|----------|-----------|----------|
| **Conservative** | 8 GB | 2.2 GB | 6.0 | Q4_K everywhere | Edge devices, minimal VRAM |
| **Balanced** ⭐ | 12 GB | 2.8 GB | 7.0 | Mixed Q4/Q5/F16 | **Recommended general use** |
| **Quality** | 16 GB | 3.3 GB | 6.5 | Mixed Q5/Q6/F16 | High fidelity needed |
| **Maximum** | 24 GB | 3.8 GB | 6.0 | Mostly F16 | Best quality (BW limited) |

---

## 🏗️ Architecture Breakdown

```
Qwen3.5-9B Architecture:
├── 32 Transformer layers
├── 250 total tensors
├── 4.90 GB total (Q4_K_S)
│
├── Attention layers (80 tensors, 940 MB)
│   ├── Q_proj, K_proj, V_proj, O_proj
│   └── Sensitive to quantization → use Q5_K minimum
│
├── MLP layers (32 tensors, 902 MB)
│   ├── Gate_proj, Up_proj, Down_proj
│   └── Robust to compression → Q4_K safe
│
└── Other (138 tensors, 3.2 GB)
    ├── Embeddings (keep F16)
    ├── Normalization layers (keep F16)
    ├── LM head (keep F16)
    └── Token embeddings (F16 or Q5_K)
```

---

## 🎯 Recommended Strategy: BALANCED (12GB)

### When to use:
- General purpose inference
- Most consumer GPUs (RTX 4090, RTX 5070, etc.)
- Good balance of quality and speed

### Quantization format:
```
Attention layers  → Q5_K (sensitive layers)
MLP layers        → Q4_K (robust layers)
Embeddings        → F16 (critical for quality)
Norms             → F16 (critical for quality)
LM Head           → F16 (output quality)
```

### Estimated performance:
- **Model size**: 2.8 GB (vs 4.9 GB original)
- **Throughput**: 7.0 tokens/sec (estimated)
- **Precision loss**: <5% relative error
- **Inference speedup**: 15-20% vs F16 (due to better cache locality)

---

## 📋 Step-by-Step Quantization

### Prerequisites:
```bash
# Install llama.cpp with quantization support
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp
cmake -B build
cmake --build build --config Release
# Or use pre-built: https://github.com/ggerganov/llama.cpp/releases
```

### Strategy 1: Conservative (8GB)
```bash
llama-quantize \
  --tensor-type attention=q4_k \
  --tensor-type mlp=q4_k \
  --tensor-type embedding=q5_k \
  model-original.gguf \
  qwen-conservative-8gb.gguf \
  Q4_K_M

# Output: ~2.2 GB
# Time: ~10 minutes
```

### Strategy 2: Balanced (12GB) ⭐ RECOMMENDED
```bash
llama-quantize \
  --tensor-type attention=q5_k \
  --tensor-type mlp=q4_k \
  --tensor-type embedding=f16 \
  model-original.gguf \
  qwen-balanced-12gb.gguf \
  Q4_K_M

# Output: ~2.8 GB
# Time: ~12 minutes
# Best quality/speed tradeoff
```

### Strategy 3: Quality (16GB)
```bash
llama-quantize \
  --tensor-type attention=q6_k \
  --tensor-type mlp=q5_k \
  --tensor-type embedding=f16 \
  model-original.gguf \
  qwen-quality-16gb.gguf \
  Q5_K_M

# Output: ~3.3 GB
# Time: ~15 minutes
# Best quality, still reasonable speed
```

### Strategy 4: Maximum (24GB)
```bash
llama-quantize \
  --tensor-type attention=f16 \
  --tensor-type mlp=q6_k \
  --tensor-type embedding=f16 \
  model-original.gguf \
  qwen-maximum-24gb.gguf \
  Q6_K

# Output: ~3.8 GB
# Time: ~20 minutes
# Minimal quantization loss, some bandwidth overhead
```

---

## 🔍 Understanding the Trade-offs

### Quantization Formats Explained:

| Format | Bits/Weight | Accuracy | Speed | Use Case |
|--------|------------|----------|-------|----------|
| F32 | 32 | Baseline | Slowest | Reference only |
| F16 | 16 | Lossless | Baseline | Critical layers |
| BF16 | 16 | Good | Fast | Modern GPUs only |
| Q8_0 | 8.5 | Excellent | Good | Critical + performance |
| Q6_K | 6.56 | Very good | Good | High quality |
| Q5_K | 5.5 | Good | Good | Balanced (default) |
| Q4_K | 4.5 | Fair | Excellent | General MLP |
| Q3_K | 3.44 | Poor | Very fast | Extreme compression |

### Per-layer sensitivity:

**High sensitivity (keep F16 or Q8):**
- Attention Q/K/V projections (critical for context)
- Normalization layers (stability critical)
- LM head (final output quality)
- Token embeddings (semantic representation)

**Medium sensitivity (Q5_K safe):**
- Attention output projections
- MLP output projections

**Low sensitivity (Q4_K safe):**
- MLP inner projections (gate, up, down)
- Attention computation internals

---

## 📈 Performance Tuning

### Environment Variables (for optimal speed):

**Linux/macOS:**
```bash
export CUDA_GRAPHS=1  # Enable CUDA graphs (faster execution)
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0  # Use specific GPU
```

**Windows:**
```powershell
$env:CUDA_GRAPHS = "1"
$env:CUDA_DEVICE_ORDER = "PCI_BUS_ID"
$env:CUDA_VISIBLE_DEVICES = "0"
```

### Runtime settings (in your inference code):

```python
import subprocess

# Use GPU with optimized settings
cmd = [
    "llama-cli",
    "-m", "qwen-balanced-12gb.gguf",
    "-n", "512",           # Max tokens
    "-t", "8",             # 8 threads
    "-ngl", "33",          # GPU layers (all 33 for full GPU)
    "--mlock",             # Lock model in RAM
    "-c", "8192",          # Context length
    "-e"                   # Export embeddings
]

result = subprocess.run(cmd, capture_output=True, text=True)
```

---

## 🧪 Validation & Testing

### 1. Verify quantization worked:
```bash
# Check file sizes
ls -lh qwen-*.gguf

# Expected:
# qwen-conservative-8gb.gguf → 2.2 GB
# qwen-balanced-12gb.gguf    → 2.8 GB
# qwen-quality-16gb.gguf     → 3.3 GB
# qwen-maximum-24gb.gguf     → 3.8 GB
```

### 2. Test inference:
```bash
# Quick sanity check
llama-cli -m qwen-balanced-12gb.gguf \
  -p "What is machine learning?" \
  -n 128 \
  -ngl 33

# Should complete in <10 seconds on RTX 4090
```

### 3. Measure perplexity (quality):
```bash
# Generate calibration data (if you have it)
llama-perplexity -m qwen-balanced-12gb.gguf \
  -f calibration.txt

# Lower is better (compare across strategies)
```

### 4. Benchmark throughput:
```bash
# Time how many tokens/second
time llama-cli -m qwen-balanced-12gb.gguf \
  -p "The sky is blue" \
  -n 1000 \
  --timing \
  -ngl 33
```

---

## 🚀 Advanced Optimization

### Enable KV Cache Quantization (if supported):
```bash
# Quantize KV cache to INT8 (saves 50% cache memory)
llama-cli -m qwen-balanced-12gb.gguf \
  --cache-size 8192 \
  --cache-type q8_0  # KV cache in INT8
```

### Use larger context without memory overhead:
```bash
# With KV quantization, support 2x context
llama-cli -m qwen-balanced-12gb.gguf \
  -c 16384  # 16k context with INT8 KV
  --cache-type q8_0
```

### Enable flash attention (if available):
```bash
# Faster attention computation
LLAMA_CUDA_FORCE_DMMV=0 llama-cli -m qwen-balanced-12gb.gguf ...
```

---

## 📊 Files Generated

```
qwen_optimized/
├── QWEN_ANALYSIS_REPORT.txt         ← Human-readable summary
├── qwen_analysis.json               ← Detailed metrics (JSON)
├── layer_profiles.json              ← Per-layer analysis
├── generate_optimized_gguf.ps1      ← PowerShell generation script
├── generate_optimized_gguf.sh       ← Bash generation script
└── (generated GGUF files after running quantization)
    ├── qwen-conservative-8gb.gguf
    ├── qwen-balanced-12gb.gguf
    ├── qwen-quality-16gb.gguf
    └── qwen-maximum-24gb.gguf
```

---

## ❓ FAQ

**Q: Which strategy should I choose?**  
A: **Balanced (12GB)** for most use cases. It gives you 7.0 tok/s with great quality on typical consumer GPUs.

**Q: Can I use on less than 12GB?**  
A: Yes! Use **Conservative (8GB)** — you'll get 6.0 tok/s, still fast for most tasks.

**Q: Will quantization degrade quality?**  
A: Minimally. Q4_K for MLP and Q5_K for attention have <5% error. For chat/generation, it's imperceptible.

**Q: How much faster is it?**  
A: 15-20% faster inference due to better cache utilization. Memory BW is the bottleneck, not model precision.

**Q: Can I use multiple GPUs?**  
A: Yes, with `--split-mode row` in llama.cpp, or via distributed inference frameworks.

**Q: Should I re-quantize if I update the base model?**  
A: Yes. Each model has different activation distributions. The imatrix (importance matrix) is model-specific.

---

## 🔗 Resources

- **llama.cpp**: https://github.com/ggerganov/llama.cpp
- **Quantization guide**: https://github.com/ggerganov/llama.cpp/blob/master/examples/quantize.md
- **Model card**: https://huggingface.co/DavidAU/Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF
- **Qwen official**: https://huggingface.co/Qwen/Qwen3.5-9B

---

## 📝 Next Steps

1. **Choose a strategy** (recommended: Balanced)
2. **Run quantization** using the commands above
3. **Test on your hardware** and measure actual TPS
4. **Adjust if needed** based on your RAM/speed constraints
5. **Deploy** your optimized GGUF

---

**Generated by d2-quant-planner**  
For issues or questions: https://github.com/GaTmaNnes/d2-quant-planner
