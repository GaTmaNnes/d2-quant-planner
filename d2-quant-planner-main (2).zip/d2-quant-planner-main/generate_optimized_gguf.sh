#!/bin/bash
# Generate optimized GGUF files for Qwen3.5-9B
# using llama-quantize with recommended settings

MODEL_INPUT="C:/Users/videl/.lmstudio/models/DavidAU/Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF/Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"
OUTPUT_DIR="C:/Users/videl/Documents/d2-quant-planner-main/qwen_optimized"

echo "=================================="
echo "Qwen3.5-9B GGUF Optimization"
echo "=================================="
echo ""

# Strategy 1: Conservative (8GB, maximum compression)
echo "[1/4] CONSERVATIVE (8GB, max compression)..."
llama-quantize \
  --tensor-type "attention=q4_k" \
  --tensor-type "mlp=q4_k" \
  --tensor-type "embedding=q5_k" \
  "$MODEL_INPUT" \
  "$OUTPUT_DIR/qwen-conservative-8gb.gguf" \
  Q4_K_M

echo "✓ Conservative GGUF created"
echo ""

# Strategy 2: Balanced (12GB, recommended)
echo "[2/4] BALANCED (12GB, recommended)..."
llama-quantize \
  --tensor-type "attention=q5_k" \
  --tensor-type "mlp=q4_k" \
  --tensor-type "embedding=f16" \
  "$MODEL_INPUT" \
  "$OUTPUT_DIR/qwen-balanced-12gb.gguf" \
  Q4_K_M

echo "✓ Balanced GGUF created"
echo ""

# Strategy 3: Quality (16GB, quality focus)
echo "[3/4] QUALITY (16GB, quality focus)..."
llama-quantize \
  --tensor-type "attention=q6_k" \
  --tensor-type "mlp=q5_k" \
  --tensor-type "embedding=f16" \
  "$MODEL_INPUT" \
  "$OUTPUT_DIR/qwen-quality-16gb.gguf" \
  Q5_K_M

echo "✓ Quality GGUF created"
echo ""

# Strategy 4: Maximum (24GB, best quality)
echo "[4/4] MAXIMUM (24GB, best quality)..."
llama-quantize \
  --tensor-type "attention=f16" \
  --tensor-type "mlp=q6_k" \
  --tensor-type "embedding=f16" \
  "$MODEL_INPUT" \
  "$OUTPUT_DIR/qwen-maximum-24gb.gguf" \
  Q6_K

echo "✓ Maximum GGUF created"
echo ""

echo "=================================="
echo "All GGUFs generated!"
echo "Output directory: $OUTPUT_DIR"
echo "=================================="
