#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Banc d'essai sur modèles réels
===============================

Renommé en script (`bench_real_models.py` serait plus juste) mais conservé sous
ce nom pour ne pas casser les habitudes. Ce n'est **pas** une suite de tests :
la suite est dans `tests/`, lancée par `pytest`. Le v1 nommait deux scripts de
démonstration `test_*.py`, ce qui les faisait ramasser par pytest alors qu'ils
téléchargent des modèles et n'ont aucune assertion.

Ce script mesure sur de vrais poids :

* l'erreur de quantification réelle par couche et par format ;
* l'exposant spectral alpha (diagnostic) ;
* le plan produit sous plusieurs budgets VRAM ;
* la taille du fichier obtenu, comparée aux préréglages de llama.cpp.

Il ne prétend rien mesurer d'autre. En particulier, il **ne mesure pas la
perplexité** : cela demande un jeu d'évaluation et une exécution du modèle, ce
que ce dépôt ne fait pas. Le v1 affichait des tableaux de « perte de
perplexité » entièrement écrits à la main.

Usage :
    python test_real_models.py                     # gpt2 (500 Mo)
    python test_real_models.py --model TinyLlama/TinyLlama-1.1B-Chat-v1.0
    python test_real_models.py --model model.gguf --budgets 4,6,8
"""

from __future__ import annotations

import argparse
import time

import numpy as np

import d2
from d2 import console, formats as fmts, spectral

LADDER = ["Q8_0", "Q6_K", "Q5_K", "Q4_K", "Q3_K", "Q2_K"]


def error_table(layers, limit: int = 12) -> None:
    """Erreur de quantification mesurée, par couche et par format."""
    print(f"\n  {'Tenseur':<40} {'classe':<10} " +
          " ".join(f"{f:>8}" for f in LADDER))
    print("  " + "-" * (52 + 9 * len(LADDER)))
    shown = 0
    for l in layers:
        if l.weights is None or l.forced:
            continue
        errs = [fmts.relative_error(l.weights, f) for f in LADDER]
        print(f"  {l.name[:40]:<40} {l.cls:<10} " +
              " ".join(f"{e:>8.4f}" for e in errs))
        shown += 1
        if shown >= limit:
            break

    # Moyenne par classe : c'est là que se voit la hiérarchie de sensibilité.
    by_cls = {}
    for l in layers:
        if l.weights is None or l.forced:
            continue
        by_cls.setdefault(l.cls, []).append(
            fmts.relative_error(l.weights, "Q4_K"))
    print(f"\n  Erreur Q4_K moyenne par classe :")
    for cls, vals in sorted(by_cls.items(), key=lambda kv: -np.mean(kv[1])):
        print(f"    {cls:<12} {np.mean(vals):.4f}   (n={len(vals)})")


def spectral_table(layers, limit: int = 12) -> None:
    print(f"\n  {'Tenseur':<40} {'alpha':>8} {'KS':>7} {'rang_eff':>10} "
          f"{'interpretation'}")
    print("  " + "-" * 100)
    shown = 0
    for l in layers:
        if l.weights is None:
            continue
        st = spectral.analyze(l.weights)
        if not st.alpha_ok:
            continue
        from spectral_theory import QuantizationPolicy
        note = QuantizationPolicy.training_quality(st.alpha)
        print(f"  {l.name[:40]:<40} {st.alpha:>8.3f} {st.ks:>7.3f} "
              f"{st.effective_rank:>10.1f} {note[:44]}")
        shown += 1
        if shown >= limit:
            break


def main() -> int:
    console.setup()
    p = argparse.ArgumentParser(description="Banc d'essai D2 sur modeles reels")
    p.add_argument("--model", default="gpt2",
                   help="id HuggingFace, .safetensors ou .gguf")
    p.add_argument("--gpu", default="rtx4090")
    p.add_argument("--budgets", default="0.2,0.35,0.5",
                   help="budgets VRAM en Go, separes par des virgules")
    p.add_argument("--ctx", type=int, default=2048)
    p.add_argument("--spectral", action="store_true",
                   help="calcule aussi le diagnostic spectral")
    args = p.parse_args()

    print("=" * 78)
    print(f"  Banc d'essai D2 — {args.model}")
    print("=" * 78)

    t0 = time.time()
    try:
        if args.model.lower().endswith(".gguf"):
            layers, info = d2.load_gguf(args.model)
        elif args.model.lower().endswith(".safetensors"):
            layers, info = d2.load_safetensors(args.model)
        else:
            layers, info = d2.load_huggingface(args.model)
    except Exception as exc:
        print(f"\n  [!] Chargement impossible : {type(exc).__name__} : {exc}")
        print("  (huggingface_hub + safetensors requis pour les modeles HF,")
        print("   gguf pour les .gguf)")
        return 2

    n_params = sum(l.n_elements for l in layers)
    print(f"\n  {len(layers)} tenseurs, {n_params / 1e6:.1f} M parametres "
          f"({time.time() - t0:.1f} s)")
    for k in ("arch", "n_blocks", "n_kv_heads", "head_dim"):
        if info.get(k):
            print(f"  {k:<12}: {info[k]}")

    print("\n" + "=" * 78)
    print("  Erreur de quantification MESUREE")
    print("=" * 78)
    error_table(layers)

    if args.spectral:
        print("\n" + "=" * 78)
        print("  Diagnostic spectral (indicatif, hors decision)")
        print("=" * 78)
        spectral_table(layers)

    print("\n" + "=" * 78)
    print("  Plans sous contrainte")
    print("=" * 78)
    caps = d2.get_profile(args.gpu)
    f16_size = sum(fmts.format_bytes(l.n_elements, "F16") for l in layers)
    print(f"\n  Reference F16 : {f16_size / 1e9:.3f} Go")
    print(f"  {'Budget':>9} {'Poids':>9} {'Cout Q':>11} {'Repartition'}")
    print("  " + "-" * 74)
    for b in [float(x) for x in args.budgets.split(",")]:
        try:
            plan = d2.plan_layers(layers, caps, vram_budget_gb=b,
                                  ctx_len=args.ctx, **d2.kv_geometry(info))
        except d2.InfeasibleBudget:
            print(f"  {b:>8.2f}G {'intenable':>9}")
            continue
        dist = "  ".join(f"{k}:{v}" for k, v in plan.distribution().items())
        print(f"  {b:>8.2f}G {plan.total_bytes / 1e9:>8.3f}G "
              f"{plan.total_omega:>11.3e} {dist}")

    print("\n  Comparaison aux prereglages uniformes de llama.cpp :")
    print(f"  {'Preset':>9} {'Taille':>9}")
    print("  " + "-" * 21)
    for f in ["F16", "Q8_0", "Q6_K", "Q5_K", "Q4_K"]:
        s = sum(fmts.format_bytes(l.n_elements, f) for l in layers)
        print(f"  {f:>9} {s / 1e9:>8.3f}G")
    print("\n  Un plan D2 de meme taille qu'un preset uniforme repartit les")
    print("  bits differemment ; comparer les colonnes 'Cout Q' ci-dessus.")
    print("\n  Note : ce script ne mesure pas la perplexite. Pour cela,")
    print("  utilisez `llama-perplexity` sur les modeles quantifies.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
