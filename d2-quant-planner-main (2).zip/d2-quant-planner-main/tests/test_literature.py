"""
Invariants issus de la litterature
===================================

Reprend les « angles morts » de `d2_blindspot_tests.py` (v1) et les transforme
en assertions executables sur le code reel. Le v1 « testait » ses constantes en
les comparant a d'autres constantes ecrites dans le meme fichier : aucun de ses
tests ne touchait le code de production. Ceux-ci verifient le comportement
effectif du planificateur.
"""

import numpy as np
import pytest

import d2
from d2 import formats as F
from d2 import hardware as H
from d2.planner import kv_cache_bytes


# ─────────────────────────────────────────────────────────────────────────────
# BS-01 — Attention sink : StreamingLLM (Xiao et al., ICLR 2024)
# ─────────────────────────────────────────────────────────────────────────────


def test_sink_overhead_is_negligible_at_4_tokens():
    """4 tokens proteges, pas 128 : le surcout doit rester sous 1 %."""
    kw = dict(n_layers=32, n_kv_heads=8, head_dim=128, ctx_len=4096,
              kv_format="Q4_K")
    base = kv_cache_bytes(sink_tokens=0, **kw)
    sink4 = kv_cache_bytes(sink_tokens=4, **kw)
    sink128 = kv_cache_bytes(sink_tokens=128, **kw)

    assert (sink4 - base) / base < 0.01
    # Le reglage du v1 coutait un ordre de grandeur de plus.
    assert (sink128 - base) / (sink4 - base) > 20


def test_dynamic_module_uses_literature_value():
    import d2_dynamic_v13

    assert d2_dynamic_v13.SINK_TOKENS == 4


# ─────────────────────────────────────────────────────────────────────────────
# BS-03 — Roofline : le decodage est limite par la memoire
# ─────────────────────────────────────────────────────────────────────────────


def test_decode_throughput_scales_with_bytes_not_bits():
    """Le debit suit les octets *reellement stockes*, echelles comprises.

    Le v1 supposait 0.5 o/poids pour l'INT4 et en deduisait un facteur 4 sur
    F16. Le vrai facteur est 2.0 / 0.5625 = 3.56 : ignorer les echelles
    surestime le gain de 12 %.
    """
    caps = H.get_profile("rtx4090")
    n = 100_000_000
    t_f16 = H.decode_latency_s(F.format_bytes(n, "F16"), caps)
    t_q4k = H.decode_latency_s(F.format_bytes(n, "Q4_K"), caps)
    ratio = t_f16 / t_q4k
    assert ratio == pytest.approx(2.0 / 0.5625, rel=1e-3)
    assert ratio < 4.0


def test_roofline_efficiency_is_applied():
    """La bande passante crete n'est jamais atteinte : facteur < 1 applique."""
    caps = H.get_profile("rtx4090")
    assert 0.5 <= caps.bw_efficiency <= 0.95
    t = H.decode_latency_s(caps.bw_gbs * 1e9, caps)
    assert t > 1.0   # lire 1008 Go prend plus d'une seconde en pratique


# ─────────────────────────────────────────────────────────────────────────────
# BS-04 — Valeurs aberrantes : LLM.int8() / SmoothQuant / AWQ
# ─────────────────────────────────────────────────────────────────────────────


def test_outlier_channels_raise_measured_error():
    """Une matrice a canaux aberrants doit montrer une erreur plus forte.

    Le v1 utilisait un kurtosis *synthetique* calcule a partir de l'indice de
    couche (`80 + 120*(1-4*pos*(1-pos))`), donc sans lien avec les poids. Ici
    l'effet est mesure sur la matrice.
    """
    rng = np.random.default_rng(0)
    clean = rng.standard_normal((256, 256)).astype(np.float32)
    outlier = clean.copy()
    outlier[:, :3] *= 60.0   # quelques canaux dominants

    assert F.relative_error(outlier, "Q4_K") > F.relative_error(clean, "Q4_K")


def test_imatrix_protects_dominant_channels():
    """Ponderer par E[x^2] change l'erreur : c'est l'objectif GPTQ/AWQ."""
    rng = np.random.default_rng(1)
    W = rng.standard_normal((256, 256)).astype(np.float32)
    imp = np.ones(256, dtype=np.float32)
    imp[:8] = 400.0
    assert F.relative_error(W, "Q4_K", weights=imp) != pytest.approx(
        F.relative_error(W, "Q4_K"), rel=1e-3
    )


# ─────────────────────────────────────────────────────────────────────────────
# BS-05 — Le cache KV doit sortir du budget des poids
# ─────────────────────────────────────────────────────────────────────────────


def test_kv_cache_is_subtracted_from_weight_budget():
    layers, info = d2.synthetic_model(n_blocks=4, hidden=1024,
                                      intermediate=2816, vocab=8000,
                                      n_kv_heads=4)
    caps = d2.get_profile("rtx4090")
    short = d2.plan_layers(layers, caps, vram_budget_gb=1.0, ctx_len=1024,
                           **d2.kv_geometry(info))
    long = d2.plan_layers(layers, caps, vram_budget_gb=1.0, ctx_len=32768,
                          **d2.kv_geometry(info))
    assert long.budget.kv_cache > short.budget.kv_cache
    assert long.budget.weights < short.budget.weights


def test_kv_cache_dominates_at_long_context():
    """A 128 K tokens le cache KV depasse les poids d'un 8B en Q4_K.

    C'est le constat de KVQuant/KIVI, et la raison pour laquelle l'ignorer
    (comme le faisait le planificateur d'origine) rend tout plan long-contexte
    faux.
    """
    kv = kv_cache_bytes(32, 8, 128, 131072, "F16")
    weights_8b_q4k = 8e9 * F.bytes_per_weight("Q4_K")
    assert kv > weights_8b_q4k


# ─────────────────────────────────────────────────────────────────────────────
# BS-06 — Coherence des melanges k-quant de llama.cpp
# ─────────────────────────────────────────────────────────────────────────────


def test_kquant_ladder_is_monotone_in_size_and_error():
    """Chaque cran du ladder doit etre strictement plus petit et plus errone."""
    rng = np.random.default_rng(2)
    W = (rng.standard_normal((512, 512)) * rng.standard_normal((512, 512))
         * 0.05).astype(np.float32)
    ladder = ["Q8_0", "Q6_K", "Q5_K", "Q4_K", "Q3_K", "Q2_K"]
    sizes = [F.bytes_per_weight(f) for f in ladder]
    errs = [F.relative_error(W, f) for f in ladder]
    assert sizes == sorted(sizes, reverse=True), dict(zip(ladder, sizes))
    assert errs == sorted(errs), dict(zip(ladder, errs))


def test_no_format_claims_impossible_compression():
    """Aucun format ne doit annoncer moins de bits que son ladder ne permet."""
    for name, fmt in F.FORMATS.items():
        assert fmt.bpw > 0
        if fmt.family in ("kquant", "int", "fp4"):
            # Les metadonnees de bloc interdisent d'atteindre la largeur nue.
            nominal = {"Q2_K": 2, "Q3_K": 3, "Q4_K": 4, "Q5_K": 5, "Q6_K": 6,
                       "Q4_0": 4, "Q5_0": 5, "Q8_0": 8}.get(name)
            if nominal:
                assert fmt.bpw > nominal, name


# ─────────────────────────────────────────────────────────────────────────────
# Coherence globale : une seule definition par grandeur
# ─────────────────────────────────────────────────────────────────────────────


def test_single_source_for_bytes_per_weight():
    """Toute la chaine doit passer par d2.formats, sans constante dupliquee."""
    import d2_production

    assert d2_production.DTYPE_PROPS["INT4"]["bpe"] == F.bytes_per_weight("Q4_K")
    assert d2_production.DTYPE_PROPS["INT8"]["bpe"] == F.bytes_per_weight("Q8_0")
    assert d2_production.DTYPE_PROPS["FP16"]["bpe"] == F.bytes_per_weight("F16")


def test_plan_size_matches_format_accounting():
    """La taille annoncee doit etre la somme exacte des tailles de format."""
    layers, info = d2.synthetic_model(n_blocks=3, hidden=512, intermediate=1024,
                                      vocab=4000, n_kv_heads=2)
    caps = d2.get_profile("rtx4090")
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.05, ctx_len=1024,
                          **d2.kv_geometry(info))
    recomputed = sum(
        F.format_bytes(l.n_elements, e.format)
        for l, e in zip(layers, plan.entries)
    )
    assert plan.total_bytes == pytest.approx(recomputed)


def test_legacy_modules_point_to_the_core():
    """Les anciens doublons ne doivent plus exposer de logique concurrente."""
    import importlib

    for name in ["d2_compiler", "d2_compiler_v2", "quant_graph_compiler_v2",
                 "d2_qdf_bayesian_optimized", "v18", "d2_compile_pipeline"]:
        mod = importlib.import_module(name)
        with pytest.raises(AttributeError, match="d2"):
            getattr(mod, "solve_quantization_plan")
