"""Tests de la classification des couches et du modele de sensibilite."""

import numpy as np
import pytest

from d2 import formats as F
from d2.sensitivity import (
    CLASS_IMPORTANCE,
    LayerSpec,
    block_index,
    classify,
    load_imatrix,
    sensitivity_matrix,
)


# ─────────────────────────────────────────────────────────────────────────────
# Classification
# ─────────────────────────────────────────────────────────────────────────────

CASES = [
    # GGUF
    ("blk.0.attn_v.weight", "attn_v"),
    ("blk.12.attn_k.weight", "attn_k"),
    ("blk.3.attn_q.weight", "attn_q"),
    ("blk.3.attn_output.weight", "attn_o"),
    ("blk.3.attn_qkv.weight", "attn_qkv"),
    ("blk.7.ffn_down.weight", "ffn_down"),
    ("blk.7.ffn_gate.weight", "ffn_gate"),
    ("blk.7.ffn_up.weight", "ffn_up"),
    ("blk.7.attn_norm.weight", "norm"),
    ("output_norm.weight", "norm"),
    ("token_embd.weight", "embed"),
    ("output.weight", "head"),
    ("blk.2.ssm_conv1d.weight", "ssm_conv"),
    # HuggingFace / Llama
    ("model.layers.0.self_attn.v_proj.weight", "attn_v"),
    ("model.layers.0.self_attn.o_proj.weight", "attn_o"),
    ("model.layers.0.mlp.down_proj.weight", "ffn_down"),
    ("model.layers.0.input_layernorm.weight", "norm"),
    ("model.embed_tokens.weight", "embed"),
    ("lm_head.weight", "head"),
    # GPT-2
    ("h.0.attn.c_attn.weight", "attn_qkv"),
    ("h.0.mlp.c_fc.weight", "ffn_up"),
    ("wte.weight", "embed"),
    ("ln_f.weight", "norm"),
]


@pytest.mark.parametrize("name,expected", CASES)
def test_classify(name, expected):
    assert classify(name) == expected


def test_output_norm_is_norm_not_head():
    """Regression : le v1 classait `output_norm.weight` en 'head'."""
    assert classify("output_norm.weight") == "norm"
    assert classify("output.weight") == "head"


def test_token_embd_is_embed_not_mlp():
    """Regression : alpha_w_report.json etiquetait token_embd en 'mlp'."""
    assert classify("token_embd.weight") == "embed"


def test_attn_v_checked_before_generic_attn():
    """L'ordre des motifs compte : v_proj ne doit pas tomber dans 'attn_q'."""
    assert classify("blk.0.attn_v.weight") == "attn_v"
    assert classify("blk.0.attn_gate.weight") == "attn_q"


def test_block_index():
    assert block_index("blk.17.attn_q.weight") == 17
    assert block_index("model.layers.3.mlp.up_proj.weight") == 3
    assert block_index("token_embd.weight") is None


# ─────────────────────────────────────────────────────────────────────────────
# Importances
# ─────────────────────────────────────────────────────────────────────────────


def test_norms_are_forced():
    for cls in ("norm", "bias", "meta"):
        assert not np.isfinite(CLASS_IMPORTANCE[cls])
    assert LayerSpec("blk.0.attn_norm.weight", [4096, 1]).forced is True
    assert LayerSpec("blk.0.attn_q.weight", [4096, 4096]).forced is False


def test_llama_cpp_sensitivity_ordering():
    """attn_v et ffn_down remontes ; conforme a `llama_tensor_get_type`."""
    assert CLASS_IMPORTANCE["attn_v"] > CLASS_IMPORTANCE["attn_q"]
    assert CLASS_IMPORTANCE["ffn_down"] > CLASS_IMPORTANCE["ffn_up"]
    assert CLASS_IMPORTANCE["ffn_down"] > CLASS_IMPORTANCE["ffn_gate"]
    assert CLASS_IMPORTANCE["head"] > CLASS_IMPORTANCE["attn_q"]


# ─────────────────────────────────────────────────────────────────────────────
# Matrice de sensibilite
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def layers():
    rng = np.random.default_rng(3)

    def W(m, n):
        return (rng.standard_normal((m, n)) * rng.standard_normal((m, n))
                * 0.05).astype(np.float32)

    return [
        LayerSpec("blk.0.attn_q.weight", [256, 256], W(256, 256)),
        LayerSpec("blk.0.attn_v.weight", [256, 256], W(256, 256)),
        LayerSpec("blk.0.ffn_down.weight", [256, 256], W(256, 256)),
        LayerSpec("blk.0.attn_norm.weight", [256, 1], W(256, 1)),
    ]


def test_omega_increases_as_bits_decrease(layers):
    fmt = ["Q8_0", "Q6_K", "Q4_K", "Q2_K"]
    omega, size, measured = sensitivity_matrix(layers, fmt)
    for i in range(3):   # hors couche forcee
        assert list(omega[i]) == sorted(omega[i]), omega[i]
        assert list(size[i]) == sorted(size[i], reverse=True)


def test_sensitive_class_gets_higher_omega(layers):
    """A erreur brute comparable, attn_v doit couter plus cher que attn_q."""
    omega, _, _ = sensitivity_matrix(layers, ["Q4_K"])
    assert omega[1, 0] > omega[0, 0]     # attn_v > attn_q
    assert omega[2, 0] > omega[0, 0]     # ffn_down > attn_q


def test_forced_layer_has_infinite_cost_when_quantized(layers):
    omega, _, _ = sensitivity_matrix(layers, ["F16", "Q4_K"])
    assert omega[3, 0] == 0.0
    assert not np.isfinite(omega[3, 1])


def test_measured_flag(layers):
    _, _, measured = sensitivity_matrix(layers, ["Q4_K"])
    assert measured.all()

    shape_only = [LayerSpec("blk.0.attn_q.weight", [256, 256])]
    _, _, m2 = sensitivity_matrix(shape_only, ["Q4_K"], measure=False)
    assert not m2.any()


def test_incompatible_imatrix_is_ignored_not_misapplied(layers):
    """Une imatrix de mauvaise taille ne doit pas produire une ponderation fausse."""
    bad = {"blk.0.attn_q.weight": np.ones(7, dtype=np.float32)}
    omega_bad, _, _ = sensitivity_matrix(layers, ["Q4_K"], imatrix=bad)
    omega_none, _, _ = sensitivity_matrix(layers, ["Q4_K"])
    assert omega_bad[0, 0] == pytest.approx(omega_none[0, 0])


def test_imatrix_changes_decision(layers):
    imp = np.ones(256, dtype=np.float32)
    imp[:5] = 5000.0
    omega_w, _, _ = sensitivity_matrix(
        layers, ["Q4_K"], imatrix={"blk.0.attn_q.weight": imp}
    )
    omega_p, _, _ = sensitivity_matrix(layers, ["Q4_K"])
    assert omega_w[0, 0] != pytest.approx(omega_p[0, 0], rel=1e-6)


# ─────────────────────────────────────────────────────────────────────────────
# imatrix
# ─────────────────────────────────────────────────────────────────────────────


def test_load_imatrix_json(tmp_path):
    import json
    p = tmp_path / "im.json"
    p.write_text(json.dumps({"blk.0.attn_q.weight": [1.0, 2.0, 3.0]}))
    out = load_imatrix(str(p))
    assert np.allclose(out["blk.0.attn_q.weight"], [1.0, 2.0, 3.0])


def test_load_imatrix_binary(tmp_path):
    import struct
    p = tmp_path / "m.imatrix"
    name = b"blk.0.attn_q.weight"
    vals = np.array([1.5, 2.5, 3.5], dtype=np.float32)
    blob = struct.pack("<i", 1) + struct.pack("<i", len(name)) + name \
        + struct.pack("<i", 10) + struct.pack("<i", len(vals)) + vals.tobytes()
    p.write_bytes(blob)
    out = load_imatrix(str(p))
    assert np.allclose(out["blk.0.attn_q.weight"], vals)


def test_load_imatrix_garbage_raises(tmp_path):
    p = tmp_path / "bad.imatrix"
    p.write_bytes(b"not an imatrix at all")
    with pytest.raises(ValueError, match="ni une imatrix"):
        load_imatrix(str(p))
