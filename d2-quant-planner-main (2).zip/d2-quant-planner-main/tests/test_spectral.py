"""Tests de l'analyse spectrale (Martin & Mahoney, Hill, Clauset)."""

import numpy as np
import pytest

from d2 import spectral as S


def power_law_eigenvalues(gamma: float, n: int = 4000) -> np.ndarray:
    """Spectre exact lambda_i = i^(-gamma), dont l'ESD suit alpha = 1 + 1/gamma."""
    return np.arange(1, n + 1, dtype=float) ** (-gamma)


@pytest.mark.parametrize("gamma", [0.5, 1.0, 1.5, 2.0, 3.0])
def test_hill_recovers_known_exponent(gamma):
    """L'estimateur de Hill doit retrouver alpha = 1 + 1/gamma."""
    alpha, ks, xmin, k = S.alpha_hill(power_law_eigenvalues(gamma))
    assert alpha == pytest.approx(1.0 + 1.0 / gamma, rel=0.02)
    assert ks < 0.05
    assert k > 20


@pytest.mark.parametrize("gamma", [0.5, 1.0, 2.0, 3.0])
def test_alpha_conversion_matches_hill(gamma):
    """La conversion pente-de-rang -> exposant ESD doit coïncider avec Hill.

    Régression de fond : le v1 posait alpha = 2*beta, sans justification. La
    relation correcte est alpha = 1 + 1/(2*beta), demontree dans le module.
    """
    lam = power_law_eigenvalues(gamma)
    sv = np.sqrt(lam)                 # sigma_i = sqrt(lambda_i) ~ i^(-gamma/2)
    beta = S.index_slope(sv)          # doit valoir gamma/2
    assert beta == pytest.approx(gamma / 2.0, rel=0.05)

    alpha_conv = S.alpha_from_index_slope(beta)
    alpha_hill, *_ = S.alpha_hill(lam)
    assert alpha_conv == pytest.approx(alpha_hill, rel=0.05)


def test_v1_formula_is_wrong():
    """Documente l'ecart : pour beta=0.5, 2*beta=1.0 mais alpha vaut 2.0."""
    beta = 0.5
    v1 = 2.0 * beta
    correct = S.alpha_from_index_slope(beta)
    assert v1 == pytest.approx(1.0)
    assert correct == pytest.approx(2.0)
    assert abs(correct - v1) > 0.5


def test_random_matrix_has_large_alpha():
    """Une gaussienne est 'sous-entrainee' au sens de M&M : alpha eleve."""
    rng = np.random.default_rng(0)
    W = rng.standard_normal((400, 400)).astype(np.float32)
    st = S.analyze(W)
    assert st.alpha_ok
    assert st.alpha > 5.0


def test_no_silent_fallback_on_degenerate_input():
    """Regression : le v1 renvoyait 1.5 (seuil INT8) sur toute exception."""
    alpha, ks, xmin, k = S.alpha_hill(np.array([1.0, 2.0, 3.0]))
    assert np.isnan(alpha)
    assert k == 0


def test_analyze_marks_failure_explicitly():
    W = np.ones((6, 6), dtype=np.float32)   # rang 1, spectre degenere
    st = S.analyze(W)
    assert st.alpha_ok is False or np.isnan(st.alpha)


def test_no_alpha_floor_at_one():
    """Le clamp max(alpha, 1.0) du v1 produisait 202/274 valeurs a 1.0."""
    alphas = [S.alpha_hill(power_law_eigenvalues(g))[0] for g in (3.0, 5.0, 8.0)]
    assert all(a < 1.5 for a in alphas), alphas
    assert len(set(np.round(alphas, 3))) == 3   # valeurs distinctes, pas ecrasees


def test_stable_rank_bounds():
    rng = np.random.default_rng(1)
    W = rng.standard_normal((128, 128)).astype(np.float32)
    sv, _ = S.singular_values(W)
    sr = S.stable_rank(sv)
    assert 1.0 <= sr <= 128.0


def test_effective_rank_of_identity_is_full():
    """Spectre plat -> rang effectif = dimension (Roy & Vetterli 2007)."""
    sv = np.ones(64)
    assert S.effective_rank(sv) == pytest.approx(64.0, rel=1e-6)
    assert S.spectral_entropy(sv) == pytest.approx(1.0, rel=1e-6)


def test_effective_rank_of_rank_one_is_one():
    sv = np.array([1.0] + [0.0] * 63)
    assert S.effective_rank(sv) == pytest.approx(1.0, abs=1e-9)


def test_single_svd_is_reproducible():
    """Meme entree -> meme sortie (le sous-echantillonnage est graine)."""
    rng = np.random.default_rng(7)
    W = rng.standard_normal((5000, 64)).astype(np.float32)
    a = S.analyze(W, max_dim=512)
    b = S.analyze(W, max_dim=512)
    assert a.sampled is True
    assert a.alpha == pytest.approx(b.alpha, rel=1e-12)


def test_handles_1d_and_3d_input():
    assert np.isfinite(S.singular_values(np.ones(32, dtype=np.float32))[0]).all()
    W3 = np.random.default_rng(0).standard_normal((8, 4, 4)).astype(np.float32)
    sv, _ = S.singular_values(W3)
    assert sv.size == 8
