"""Tests des exports llama.cpp et TensorRT-LLM."""

import json

import pytest

import d2
from d2.exporters import detect_arch, export_llama_cpp, export_tensorrt_llm, hf_to_gguf_name


@pytest.fixture(scope="module")
def plan():
    layers, info = d2.synthetic_model(n_blocks=4, hidden=512, intermediate=1024,
                                      vocab=4000, weight_dim_cap=128)
    caps = d2.get_profile("rtx4090")
    return d2.plan_layers(layers, caps, vram_budget_gb=0.05, ctx_len=1024,
                          **d2.kv_geometry(info))


# ─────────────────────────────────────────────────────────────────────────────
# Nommage
# ─────────────────────────────────────────────────────────────────────────────


def test_detect_arch():
    assert detect_arch(["blk.0.attn_q.weight"]) == "gguf"
    assert detect_arch(["model.layers.0.self_attn.q_proj.weight"]) == "llama"
    assert detect_arch(["transformer.h.0.attn.c_attn.weight"]) == "gpt2"


LLAMA_MAP_CASES = [
    ("model.embed_tokens.weight", "token_embd.weight"),
    ("model.norm.weight", "output_norm.weight"),
    ("lm_head.weight", "output.weight"),
    ("model.layers.5.self_attn.v_proj.weight", "blk.5.attn_v.weight"),
    ("model.layers.5.mlp.down_proj.weight", "blk.5.ffn_down.weight"),
    ("model.layers.5.input_layernorm.weight", "blk.5.attn_norm.weight"),
]


@pytest.mark.parametrize("hf,gguf", LLAMA_MAP_CASES)
def test_llama_name_mapping(hf, gguf):
    assert hf_to_gguf_name(hf, "llama") == gguf


def test_gpt2_name_mapping():
    assert hf_to_gguf_name("h.3.attn.c_attn.weight", "gpt2") == "blk.3.attn_qkv.weight"
    assert hf_to_gguf_name("h.3.mlp.c_proj.weight", "gpt2") == "blk.3.ffn_down.weight"
    assert hf_to_gguf_name("wte.weight", "gpt2") == "token_embd.weight"


def test_unmapped_name_returns_none_not_the_input():
    """Regression : le v1 renvoyait le nom HF brut, que llama.cpp ignore en
    silence -- la couche n'etait alors pas quantifiee comme prevu."""
    assert hf_to_gguf_name("some.exotic.tensor.weight", "llama") is None


# ─────────────────────────────────────────────────────────────────────────────
# llama.cpp
# ─────────────────────────────────────────────────────────────────────────────


def test_uses_tensor_type_not_override_tensor(plan):
    """`--override-tensor` gere le placement memoire, pas la quantification."""
    out = export_llama_cpp(plan)
    assert "--tensor-type" in out["command"]
    assert "--override-tensor" not in out["command"]
    assert "llama-quantize" in out["command"]


def test_command_mentions_input_and_output(plan):
    out = export_llama_cpp(plan, input_gguf="in.gguf", output_gguf="out.gguf")
    assert "in.gguf" in out["command"]
    assert "out.gguf" in out["command"]


def test_types_are_valid_ggml_names(plan):
    valid = {"f32", "f16", "bf16", "q4_0", "q5_0", "q8_0",
             "q2_K", "q3_K", "q4_K", "q5_K", "q6_K", "mxfp4"}
    out = export_llama_cpp(plan)
    assert set(out["tensor_types"].values()) <= valid, out["tensor_types"]


def test_unmapped_tensors_are_reported(plan):
    out = export_llama_cpp(plan)
    assert "unmapped" in out and isinstance(out["unmapped"], list)


def test_collapse_reduces_command_size(plan):
    long = export_llama_cpp(plan, collapse=False)["command"]
    short = export_llama_cpp(plan, collapse=True)["command"]
    assert short.count("--tensor-type") <= long.count("--tensor-type")


def test_json_written_as_utf8(plan, tmp_path):
    p = tmp_path / "plan.json"
    export_llama_cpp(plan, json_path=str(p))
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["format"] == "llama_cpp_tensor_type"


def test_nvfp4_reported_unsupported_by_gguf():
    """NVFP4 n'a pas d'equivalent ggml : il faut le signaler, pas le traduire."""
    layers, info = d2.synthetic_model(n_blocks=2, hidden=256, intermediate=512,
                                      vocab=1000, n_kv_heads=2, head_dim=128,
                                      weight_dim_cap=64)
    caps = d2.get_profile("rtx5090")
    p = d2.plan_layers(layers, caps, vram_budget_gb=0.01, ctx_len=512,
                       candidate_formats=["F16", "NVFP4"], **d2.kv_geometry(info))
    out = export_llama_cpp(p)
    if any(e.format == "NVFP4" for e in p.entries):
        assert out["unsupported"], "NVFP4 doit apparaitre dans `unsupported`"


# ─────────────────────────────────────────────────────────────────────────────
# TensorRT-LLM
# ─────────────────────────────────────────────────────────────────────────────


def test_trt_export_has_no_invented_flags(plan):
    """`--per_layer_precision` n'existe pas ; `--max_output_len` est obsolete."""
    out = export_tensorrt_llm(plan)
    cmd = out["build"]["command"]
    assert "--per_layer_precision" not in cmd
    assert "--max_output_len" not in cmd
    assert "--max_seq_len" in cmd


def test_trt_export_shape(plan, tmp_path):
    p = tmp_path / "trt.json"
    out = export_tensorrt_llm(plan, out_path=str(p))
    assert "quant_config" in out
    assert "exclude_modules" in out["quant_config"]
    assert json.loads(p.read_text(encoding="utf-8"))["quant_config"] is not None
