"""Tests du planificateur : optimalite, faisabilite, budget, cache KV."""

import numpy as np
import pytest

import d2
from d2 import formats as F
from d2.planner import InfeasibleBudget, kv_cache_bytes, solve
from d2.sensitivity import LayerSpec


@pytest.fixture(scope="module")
def model():
    return d2.synthetic_model(n_blocks=6, hidden=1024, intermediate=2816,
                              vocab=16000, n_kv_heads=4, head_dim=128)


@pytest.fixture(scope="module")
def caps():
    return d2.get_profile("rtx4090")


# ─────────────────────────────────────────────────────────────────────────────
# Contrainte de budget
# ─────────────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("budget_gb", [0.30, 0.45, 0.8, 2.0])
def test_plan_respects_budget(model, caps, budget_gb):
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=budget_gb,
                          ctx_len=2048, **d2.kv_geometry(info))
    assert plan.total_bytes <= plan.budget.weights + 1e-6


def test_generous_budget_keeps_full_precision(model, caps):
    """Si le modele tient en F16, il ne faut degrader aucune couche."""
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=8.0, ctx_len=2048,
                          **d2.kv_geometry(info))
    assert set(plan.distribution()) <= {"F16", "BF16"}


def test_tighter_budget_is_monotone(model, caps):
    """Reduire le budget ne peut qu'augmenter le cout qualite."""
    layers, info = model
    omegas = []
    for b in [2.0, 1.0, 0.6, 0.4, 0.3]:
        p = d2.plan_layers(layers, caps, vram_budget_gb=b, ctx_len=2048,
                           **d2.kv_geometry(info))
        omegas.append(p.total_omega)
    assert omegas == sorted(omegas), omegas


def test_infeasible_budget_raises(model, caps):
    """Regression : le v1 rendait un plan hors budget presente comme valide."""
    layers, info = model
    with pytest.raises(InfeasibleBudget, match="insuffisant"):
        d2.plan_layers(layers, caps, vram_budget_gb=0.05, ctx_len=2048,
                       **d2.kv_geometry(info))


def test_kv_cache_can_exhaust_budget(model, caps):
    """Un contexte enorme doit lever, pas produire un plan silencieusement faux."""
    layers, info = model
    with pytest.raises(InfeasibleBudget):
        d2.plan_layers(layers, caps, vram_budget_gb=0.5, ctx_len=4_000_000,
                       **d2.kv_geometry(info))


# ─────────────────────────────────────────────────────────────────────────────
# Solveurs
# ─────────────────────────────────────────────────────────────────────────────


def test_greedy_never_exceeds_budget(model, caps):
    """Regression majeure : le glouton du v1 augmentait la memoire en cas de
    depassement, donc ne convergeait jamais."""
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.4, ctx_len=2048,
                          solver="greedy", **d2.kv_geometry(info))
    assert plan.total_bytes <= plan.budget.weights + 1e-6


def test_greedy_close_to_optimal(model, caps):
    """Le glouton lagrangien doit rester a quelques pourcents de l'optimum."""
    layers, info = model
    kw = dict(vram_budget_gb=0.45, ctx_len=2048, **d2.kv_geometry(info))
    exact = d2.plan_layers(layers, caps, solver="scipy", **kw)
    greedy = d2.plan_layers(layers, caps, solver="greedy", **kw)
    assert exact.optimal
    assert greedy.total_omega >= exact.total_omega * 0.999
    assert greedy.total_omega <= exact.total_omega * 1.30


def test_solver_finds_true_optimum_on_tiny_instance():
    """Verification par enumeration exhaustive sur 4 couches x 3 formats."""
    omega = np.array([[0.0, 1.0, 4.0],
                      [0.0, 2.0, 3.0],
                      [0.0, 0.5, 9.0],
                      [0.0, 1.5, 2.0]])
    size = np.array([[100.0, 50.0, 25.0]] * 4)
    forced = np.zeros(4, dtype=bool)
    budget = 200.0

    asg, name, optimal = solve(omega, size, budget, forced, 0, solver="scipy")
    got = sum(omega[i, asg[i]] for i in range(4))

    import itertools
    best = min(
        sum(omega[i, c[i]] for i in range(4))
        for c in itertools.product(range(3), repeat=4)
        if sum(size[i, c[i]] for i in range(4)) <= budget
    )
    assert got == pytest.approx(best)
    assert optimal


# ─────────────────────────────────────────────────────────────────────────────
# Couches contraintes
# ─────────────────────────────────────────────────────────────────────────────


def test_norms_are_never_quantized(model, caps):
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.3, ctx_len=2048,
                          **d2.kv_geometry(info))
    for e in plan.entries:
        if e.cls == "norm":
            assert e.format in ("F16", "BF16", "F32"), e


def test_sensitive_layers_get_more_bits_than_peers(model, caps):
    """attn_v et ffn_down sont remontes, conformement au melange k-quant."""
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.42, ctx_len=2048,
                          **d2.kv_geometry(info))
    bpw = {e.name: F.get(e.format).bpw for e in plan.entries}
    by_cls = {}
    for e in plan.entries:
        by_cls.setdefault(e.cls, []).append(bpw[e.name])
    mean = {c: float(np.mean(v)) for c, v in by_cls.items()}
    assert mean["attn_v"] >= mean["attn_q"], mean
    assert mean["ffn_down"] >= mean["ffn_gate"], mean


# ─────────────────────────────────────────────────────────────────────────────
# Cache KV
# ─────────────────────────────────────────────────────────────────────────────


def test_kv_cache_formula():
    """2 (K+V) x couches x ctx x tetes_kv x dim_tete x octets."""
    b = kv_cache_bytes(n_layers=32, n_kv_heads=8, head_dim=128,
                       ctx_len=4096, kv_format="F16", sink_tokens=0)
    assert b == pytest.approx(2 * 32 * 4096 * 8 * 128 * 2.0)


def test_kv_cache_gqa_reduces_size():
    full = kv_cache_bytes(32, 32, 128, 4096)
    gqa = kv_cache_bytes(32, 8, 128, 4096)
    assert gqa == pytest.approx(full / 4, rel=1e-6)


def test_kv_quantization_reduces_size():
    f16 = kv_cache_bytes(32, 8, 128, 4096, kv_format="F16", sink_tokens=0)
    q8 = kv_cache_bytes(32, 8, 128, 4096, kv_format="Q8_0", sink_tokens=0)
    assert q8 < f16


def test_sink_tokens_kept_in_f16():
    """StreamingLLM : 4 tokens proteges, pas 128 comme dans le v1."""
    a = kv_cache_bytes(32, 8, 128, 4096, kv_format="Q8_0", sink_tokens=0)
    b = kv_cache_bytes(32, 8, 128, 4096, kv_format="Q8_0", sink_tokens=4)
    assert b > a
    assert (b - a) / b < 0.01   # surcout marginal, contrairement a sink=128


def test_n_blocks_not_double_counted(model):
    """Regression : le v1 comptait les tenseurs 'attn', pas les blocs."""
    layers, info = model
    assert info["n_blocks"] == 6
    n_attn_tensors = sum(1 for l in layers if l.cls.startswith("attn"))
    assert n_attn_tensors > info["n_blocks"]   # 4 tenseurs attn par bloc


# ─────────────────────────────────────────────────────────────────────────────
# Coherence du plan
# ─────────────────────────────────────────────────────────────────────────────


def test_plan_serializes_to_json(model, caps, tmp_path):
    import json
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.6, ctx_len=2048,
                          **d2.kv_geometry(info))
    path = tmp_path / "plan.json"
    d2.export_json(plan, str(path))
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["total_gb"] == pytest.approx(plan.total_bytes / 1e9)
    assert len(data["layers"]) == len(plan.entries)


def test_budget_decomposition_sums_to_total(model, caps):
    """Regression : le v1 melangeait GiB et GB, le detail ne totalisait pas."""
    layers, info = model
    plan = d2.plan_layers(layers, caps, vram_budget_gb=1.0, ctx_len=2048,
                          **d2.kv_geometry(info))
    b = plan.budget
    assert b.weights + b.kv_cache + b.activations + b.overhead == pytest.approx(b.total)
    d = b.to_dict()
    assert d["weights_gb"] + d["kv_cache_gb"] + d["activations_gb"] \
        + d["overhead_gb"] == pytest.approx(d["total_gb"])


def test_empty_layers_raises(caps):
    with pytest.raises(ValueError, match="aucune couche"):
        d2.plan_layers([], caps, vram_budget_gb=1.0)


def test_missing_budget_raises(model):
    layers, info = model
    cpu = d2.get_profile("cpu")
    with pytest.raises(ValueError, match="budget VRAM inconnu"):
        d2.plan_layers(layers, cpu, **d2.kv_geometry(info))


def test_unmeasured_layers_are_flagged(caps):
    """Planifier sans les poids doit etre signale, pas presente comme mesure."""
    layers, info = d2.synthetic_model(n_blocks=2, hidden=512, intermediate=1024,
                                      vocab=4000, with_weights=False)
    plan = d2.plan_layers(layers, caps, vram_budget_gb=0.5, ctx_len=1024,
                          measure=False, **d2.kv_geometry(info))
    assert all(not e.measured for e in plan.entries)
    assert any("sans leurs poids" in n for n in plan.notes)
