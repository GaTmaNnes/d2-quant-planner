"""Tests des capacites materielles et du modele roofline."""

import pytest

from d2 import hardware as H


# ─────────────────────────────────────────────────────────────────────────────
# Regression principale du v1 : comparaison major/minor independante
# ─────────────────────────────────────────────────────────────────────────────

# (sm, int8_tc, bf16, fp8, fp4)
CAPABILITIES = [
    ((6, 1), False, False, False, False),   # Pascal GTX 1080
    ((7, 0), False, False, False, False),   # Volta V100 : pas d'INT8 tensor core
    ((7, 5), True,  False, False, False),   # Turing RTX 2080
    ((8, 0), True,  True,  False, False),   # Ampere A100  <- casse dans le v1
    ((8, 6), True,  True,  False, False),   # Ampere RTX 3090
    ((8, 9), True,  True,  True,  False),   # Ada RTX 4090
    ((9, 0), True,  True,  True,  False),   # Hopper H100  <- casse dans le v1
    ((10, 0), True, True,  True,  True),    # Blackwell B200
    ((12, 0), True, True,  True,  True),    # Blackwell RTX 50xx <- absent du v1
]


@pytest.mark.parametrize("sm,int8,bf16,fp8,fp4", CAPABILITIES)
def test_capability_flags(sm, int8, bf16, fp8, fp4):
    c = H.GPUCaps("test", sm, 24.0, 1000.0, 100.0)
    assert c.int8_tc is int8, f"{sm} int8"
    assert c.bf16 is bf16, f"{sm} bf16"
    assert c.fp8 is fp8, f"{sm} fp8"
    assert c.fp4 is fp4, f"{sm} fp4"


def test_v1_bug_a100_had_no_int8():
    """Documente le bug : `sm[0]>=7 and sm[1]>=5` est faux pour (8,0)."""
    sm = (8, 0)
    v1_int8 = sm[0] >= 7 and sm[1] >= 5
    assert v1_int8 is False
    assert H.GPUCaps("A100", sm, 80.0, 2039.0, 312.0).int8_tc is True


def test_int4_tensor_cores_removed_in_hopper():
    """`mma.s4` existe de Turing a Ada, pas au-dela."""
    assert H.GPUCaps("t", (7, 5), 8, 448, 40).int4_tc is True
    assert H.GPUCaps("t", (8, 9), 24, 1008, 165).int4_tc is True
    assert H.GPUCaps("t", (9, 0), 80, 3350, 989).int4_tc is False


def test_int4_weight_only_needs_dp4a_not_tensor_cores():
    """Les k-quants (kernel MMQ) utilisent DP4A (Pascal+), pas les tensor cores.

    Pascal (GTX 10xx) n'a pas de tensor core FP16 mais execute Q4_K/Q5_K/Q6_K
    couramment et efficacement via MMQ : les exclure serait une erreur de
    domaine (confusion DP4A / tensor cores FP16).
    """
    assert H.GPUCaps("t", (9, 0), 80, 3350, 989).int4_weight_only is True
    assert H.GPUCaps("t", (6, 1), 8, 320, 0).int4_weight_only is True
    assert H.GPUCaps("t", (6, 0), 16, 300, 0).int4_weight_only is False  # < Pascal 6.1


def test_marlin_requires_ampere_not_just_tensor_cores():
    """Le kernel Marlin (INT4_AWQ) exige Ampere (8.0+), pas seulement Volta/Turing."""
    assert H.GPUCaps("t", (7, 0), 16, 900, 120).marlin is False   # Volta
    assert H.GPUCaps("t", (7, 5), 8, 448, 40).marlin is False     # Turing
    assert H.GPUCaps("t", (8, 0), 80, 2039, 312).marlin is True   # Ampere
    assert "INT4_AWQ" not in H.supported_formats(H.get_profile("rtx2080"))
    assert "INT4_AWQ" in H.supported_formats(H.get_profile("a100"))


# ─────────────────────────────────────────────────────────────────────────────
# Profils
# ─────────────────────────────────────────────────────────────────────────────


def test_blackwell_profiles_exist():
    """Le README annoncait 'SM61 a SM120' sans aucun profil sm_120."""
    for name in ["rtx5090", "rtx5080", "rtx5070", "b200"]:
        assert H.get_profile(name).sm >= (10, 0)
    assert H.get_profile("rtx5070").sm_str == "sm_120"


def test_unknown_profile_raises():
    """Le v1 affichait un avertissement et continuait avec la mauvaise cible."""
    with pytest.raises(KeyError, match="profil GPU inconnu"):
        H.get_profile("rtx9999")


def test_profile_name_normalisation():
    assert H.get_profile("RTX-4090").name == H.get_profile("rtx4090").name


@pytest.mark.parametrize("name", sorted(H.GPU_PROFILES))
def test_profiles_are_self_consistent(name):
    p = H.GPU_PROFILES[name]
    assert p.bw_gbs > 0
    assert p.vram_gb >= 0
    assert 0 < p.bw_efficiency <= 1.0
    if p.available:
        assert p.vram_gb > 0


def test_supported_formats_gated_by_hardware():
    ada = H.get_profile("rtx4090")
    blackwell = H.get_profile("rtx5090")
    pascal = H.get_profile("gtx1080")
    assert "NVFP4" not in H.supported_formats(ada)
    assert "NVFP4" in H.supported_formats(blackwell)
    assert "INT8" not in H.supported_formats(pascal)   # pas de tensor core
    assert "F16" in H.supported_formats(pascal)
    # Pascal (GTX 10xx) n'a pas de tensor core mais fait tourner les k-quants
    # (Q4_K etc) couramment via le kernel MMQ/DP4A de llama.cpp.
    assert "Q4_K" in H.supported_formats(pascal)
    assert "Q5_K" in H.supported_formats(pascal)
    assert "Q6_K" in H.supported_formats(pascal)
    # INT4_AWQ (kernel Marlin) reste hors de portée de Pascal (exige Ampere+).
    assert "INT4_AWQ" not in H.supported_formats(pascal)


def test_gtx1050_profiles_exist():
    for name in ["gtx1050", "gtx1050ti"]:
        p = H.get_profile(name)
        assert p.sm == (6, 1)
        assert p.vram_gb > 0
        assert "Q4_K" in H.supported_formats(p)


# ─────────────────────────────────────────────────────────────────────────────
# Roofline
# ─────────────────────────────────────────────────────────────────────────────


def test_decode_is_memory_bound():
    """A batch 1, une GEMM lit ~1 octet par FLOP : toujours limite memoire."""
    caps = H.get_profile("rtx4090")
    n = 4096 * 4096
    assert H.roofline_regime(n * 2.0, n, caps, batch=1) == "memory"


def test_large_batch_becomes_compute_bound():
    """Regression : le v1 ne propageait jamais `batch`, donc prefill == decode."""
    caps = H.get_profile("rtx4090")
    n = 4096 * 4096
    assert H.roofline_regime(n * 2.0, n, caps, batch=1) == "memory"
    assert H.roofline_regime(n * 2.0, n, caps, batch=4096) == "compute"


def test_halving_bytes_halves_decode_latency():
    caps = H.get_profile("rtx4090")
    t_f16 = H.decode_latency_s(1e9, caps)
    t_q4 = H.decode_latency_s(0.5e9, caps)
    assert t_q4 == pytest.approx(t_f16 / 2, rel=1e-9)


def test_latency_uses_real_bandwidth():
    """Le v1 supposait 1 Go/s implicite (`lat = m*n*bpe/1000`)."""
    caps = H.get_profile("rtx4090")
    t = H.decode_latency_s(1008e9 * 0.80, caps)   # exactement 1 s de lecture
    assert t == pytest.approx(1.0, rel=1e-6)
