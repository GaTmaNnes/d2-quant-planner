"""Tests des formats : tailles exactes et erreurs de quantification."""

import numpy as np
import pytest

from d2 import formats as F


# ─────────────────────────────────────────────────────────────────────────────
# Tailles de blocs — valeurs de référence de ggml-common.h
# ─────────────────────────────────────────────────────────────────────────────

# (format, bits par poids attendus)
REFERENCE_BPW = [
    ("F32", 32.0),
    ("F16", 16.0),
    ("BF16", 16.0),
    ("Q8_0", 8.5),      # 34 o / 32 poids
    ("Q6_K", 6.5625),   # 210 o / 256
    ("Q5_K", 5.5),      # 176 o / 256
    ("Q4_K", 4.5),      # 144 o / 256
    ("Q3_K", 3.4375),   # 110 o / 256
    ("Q2_K", 2.625),    # 84 o / 256
    ("Q4_0", 4.5),      # 18 o / 32
    ("Q5_0", 5.5),      # 22 o / 32
    ("NVFP4", 4.5),     # E2M1 + E4M3 par 16
    ("MXFP4", 4.25),    # E2M1 + E8M0 par 32
]


@pytest.mark.parametrize("name,bpw", REFERENCE_BPW)
def test_bits_per_weight_matches_ggml(name, bpw):
    """Un Q4_K_M ne fait pas 4 bits/poids mais 4.5 : les échelles comptent."""
    assert F.FORMATS[name].bpw == pytest.approx(bpw, rel=1e-9)


def test_q4k_is_not_4_bits():
    """Régression : le v1 utilisait bpe=0.5 pour INT4, soit 11 % d'erreur."""
    assert F.bytes_per_weight("Q4_K") == pytest.approx(0.5625)
    assert F.bytes_per_weight("Q4_K") != 0.5


def test_format_bytes_rounds_up_to_block():
    """40 poids en Q4_K occupent un super-bloc entier de 256."""
    assert F.format_bytes(40, "Q4_K") == 144.0
    assert F.format_bytes(256, "Q4_K") == 144.0
    assert F.format_bytes(257, "Q4_K") == 288.0
    assert F.format_bytes(1000, "F16") == 2000.0


def test_aliases_resolve():
    assert F.canonical("FP16") == "F16"
    assert F.canonical("Q4_K_M") == "Q4_K"
    assert F.canonical("NVFP4_SAFE") == "NVFP4"


def test_unknown_format_raises():
    """Le v1 se repliait silencieusement sur FP16 pour un format inconnu."""
    with pytest.raises(KeyError, match="format inconnu"):
        F.get("INT3_MAGIC")


# ─────────────────────────────────────────────────────────────────────────────
# Aller-retour de quantification
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def W():
    rng = np.random.default_rng(42)
    a = rng.standard_normal((256, 256)).astype(np.float32)
    b = rng.standard_normal((256, 256)).astype(np.float32)
    return (a * b * 0.05).astype(np.float32)


ALL_QUANT = ["Q8_0", "Q6_K", "Q5_K", "Q4_K", "Q3_K", "Q2_K",
             "Q4_0", "Q5_0", "NVFP4", "MXFP4", "INT8", "INT4_AWQ"]


@pytest.mark.parametrize("fmt", ALL_QUANT + ["F16", "BF16", "F32"])
def test_roundtrip_preserves_shape_and_dtype(W, fmt):
    out = F.roundtrip(W, fmt)
    assert out.shape == W.shape
    assert out.dtype == np.float32
    assert np.isfinite(out).all()


@pytest.mark.parametrize("fmt", ALL_QUANT)
def test_roundtrip_is_not_identity(W, fmt):
    assert not np.array_equal(F.roundtrip(W, fmt), W)


def test_error_decreases_with_bit_width(W):
    """L'erreur doit décroître strictement avec la largeur effective."""
    ladder = ["Q2_K", "Q3_K", "Q4_K", "Q5_K", "Q6_K", "Q8_0", "F16"]
    errs = [F.relative_error(W, f) for f in ladder]
    assert errs == sorted(errs, reverse=True), dict(zip(ladder, errs))


def test_f32_roundtrip_is_lossless(W):
    assert F.relative_error(W, "F32") == 0.0


def test_bf16_less_precise_than_f16(W):
    """BF16 a 8 bits de mantisse contre 11 pour F16, à taille égale."""
    assert F.relative_error(W, "BF16") > F.relative_error(W, "F16")
    assert F.FORMATS["BF16"].bpw == F.FORMATS["F16"].bpw


def test_zero_matrix_has_zero_error():
    Z = np.zeros((64, 64), dtype=np.float32)
    for fmt in ALL_QUANT:
        assert F.relative_error(Z, fmt) == 0.0


def test_constant_matrix_survives_quantization():
    """Un bloc constant est représentable exactement par l'échelle seule."""
    C = np.full((64, 64), 0.37, dtype=np.float32)
    assert F.relative_error(C, "Q8_0") < 0.01


def test_kquant_error_is_upper_bound(W):
    """Notre choix d'échelle min/max majore celui, itératif, de llama.cpp.

    On vérifie que l'erreur reste dans une plage plausible : ni nulle (bug de
    quantification) ni catastrophique (structure de bloc fausse).
    """
    err = F.relative_error(W, "Q4_K")
    assert 0.02 < err < 0.25


def test_imatrix_weighting_changes_error(W):
    """Une pondération d'activation modifie l'erreur mesurée."""
    plain = F.relative_error(W, "Q4_K")
    imp = np.ones(W.shape[1], dtype=np.float32)
    imp[:10] = 1000.0  # 10 canaux dominants
    weighted = F.relative_error(W, "Q4_K", weights=imp)
    assert weighted != pytest.approx(plain, rel=1e-6)
    assert np.isfinite(weighted)


def test_uniform_imatrix_matches_unweighted(W):
    """Une imatrix uniforme ne doit rien changer."""
    imp = np.full(W.shape[1], 2.5, dtype=np.float32)
    assert F.relative_error(W, "Q4_K", weights=imp) == pytest.approx(
        F.relative_error(W, "Q4_K"), rel=1e-5
    )


def test_bad_imatrix_shape_raises(W):
    with pytest.raises(ValueError, match="1-D"):
        F.relative_error(W, "Q4_K", weights=np.ones(7, dtype=np.float32))


def test_e2m1_grid_is_exact():
    """Les valeurs sur la grille E2M1 doivent être conservées exactement."""
    levels = np.array([0, 0.5, 1, 1.5, 2, 3, 4, 6], dtype=np.float32)
    x = np.concatenate([levels, -levels]).reshape(1, -1)
    x = np.repeat(x, 16, axis=0)  # 16 lignes -> blocs pleins
    out = F.roundtrip(x * 6.0, "NVFP4") / 6.0
    assert np.allclose(out, x, atol=1e-3)


def test_nvfp4_beats_q4_0_at_similar_size(W):
    """La grille non uniforme E2M1 gère mieux les queues que l'uniforme 4 bits."""
    assert F.FORMATS["NVFP4"].bpw == F.FORMATS["Q4_0"].bpw
    assert F.relative_error(W, "NVFP4") < F.relative_error(W, "Q4_0")


def test_roundtrip_handles_non_multiple_of_block():
    """Une matrice dont la taille n'est pas multiple du bloc est complétée."""
    rng = np.random.default_rng(0)
    W = rng.standard_normal((7, 13)).astype(np.float32)  # 91 éléments
    for fmt in ["Q4_K", "Q8_0", "NVFP4"]:
        out = F.roundtrip(W, fmt)
        assert out.shape == (7, 13)
        assert np.isfinite(out).all()
