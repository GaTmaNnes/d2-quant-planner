# Migration — ce qui a changé et pourquoi

Ce document liste les défauts corrigés et les correspondances d'API. Il est écrit pour être vérifiable : chaque point renvoie à un comportement précis, et la plupart sont couverts par un test de régression dans `tests/`.

---

## 1. Le problème de fond : six implémentations contradictoires

Le dépôt contenait six modules calculant la même chose avec des conventions incompatibles. Le plus visible : **la politique α était inversée selon le fichier.**

| Module | α élevé signifiait |
|---|---|
| `alpha_spectral_scanner`, `d2_rtx_gguf_profiler`, `d2_compile_pipeline` | quantifier agressivement (INT4 / NVFP4) |
| `spectral_theory`, `d2_compiler`, `test_real_models` | protéger en FP16 |

Aucune des deux n'est étayée. Chez Martin & Mahoney, α mesure la *qualité d'entraînement* d'une couche ; aucun travail publié ne le relie à une largeur de bits soutenable. La décision repose désormais sur l'**erreur de quantification mesurée**, et α est exporté comme diagnostic.

À cela s'ajoutait une divergence d'échelle : `KPEv14` (dans `d2_compiler_v2`) définissait `alpha_w = −pente` là où trois autres modules utilisaient `−2 × pente`, tout en partageant les mêmes seuils. Une couche notée 1,05 par l'un valait 2,1 pour l'autre.

---

## 2. Correction mathématique : α n'est pas `2 × pente`

L'exposant de Martin & Mahoney porte sur la densité spectrale empirique des **valeurs propres** de `X = WᵀW` :

```
ρ(λ) ∝ λ^(−α)
```

Le v1 ajustait `log σᵢ = −β log i + c` — une décroissance en fonction du *rang* — puis posait `α = 2β`. Si `λᵢ = C·i^(−γ)` avec `γ = 2β`, alors `N(λ) = (C/λ)^(1/γ)`, la queue de la CDF est en `λ^(−1/γ)` et donc :

```
α = 1 + 1/(2β)
```

Pour `β = 0,5` la formule correcte donne **α = 2,0** — le bas de la plage « bien entraîné » — là où `2β` donnait 1,0. Vérifié dans `tests/test_spectral.py::test_alpha_conversion_matches_hill`, qui compare la conversion à un estimateur de Hill sur des spectres synthétiques : les deux coïncident à 2 % près.

L'estimation utilise maintenant Hill (1975) avec balayage de `x_min` minimisant la distance KS (Clauset et al., 2009), au lieu d'une régression sur tout le spectre qui mélange le « bulk » de Marchenko–Pastur et la queue.

---

## 3. Le scanner n'analysait pas les poids

`alpha_spectral_scanner.alpha_w(tensor.data)` appliquait un SVD aux **octets bruts** du GGUF. Pour un tenseur quantifié, `data` est une suite de blocs compressés : échelles f16, nibbles empaquetés, masques. Le spectre analysé n'était pas celui de la matrice.

Le fichier `alpha_w_report.json` livré dans le dépôt en porte la trace : **202 de ses 274 tenseurs valent exactement 1,0**, c'est-à-dire le plancher de `max(−2·slope, 1.0)`. 224 sur 274 (82 %) finissaient en `FP16_REQUIRED`, ce qui contredit les répartitions annoncées dans le README (« Llama-3-8B : FP16 23 %, INT8 47 %, INT4 28 % ») et explique que `build_blackwell_sm120.ps1` ne quantifie quasiment rien.

Correction : déquantification via `gguf.quants.dequantize`, l'implémentation de référence de llama.cpp, qui couvre F32/F16/BF16, tous les `Q*_0`/`Q*_1`, tous les K-quants et les IQ*. Un ajustement qui échoue renvoie `null`, jamais une constante.

---

## 4. Bugs de calcul

| Où | Défaut | Test de régression |
|---|---|---|
| `v18.py:1` | Première ligne `i #!/usr/bin/env python3` → `NameError` à l'import | — (fichier remplacé) |
| `app.py:66`, `example/run_example.py:52` | `summarize(plan, budget, 1.0, w_risk)` : `w_risk` atterrissait dans `w_speed`, le résumé affichait toujours `lam=1.00` | `d2_production.summarize` lit le `Plan` |
| `d2_compiler_v2._greedy`, `d2_compile_pipeline._greedy` | En cas de dépassement, « relâchait vers une précision plus haute », ce qui **augmente** la mémoire : la boucle ne pouvait pas converger | `test_planner.py::test_greedy_never_exceeds_budget` |
| `d2_rtx_gguf_profiler.detect_gpu` | `sm[0]>=7 and sm[1]>=5` : A100 (8,0), H100 (9,0) et Blackwell (12,0) déclarés sans INT8 ni INT4 | `test_hardware.py::test_capability_flags` |
| `d2_compiler_v2.gain` | `batch` jamais transmis à `_latency` : les modes `decode` et `prefill` rendaient le même plan | `test_hardware.py::test_large_batch_becomes_compute_bound` |
| `d2_compiler_v2.spec_risk` | `tanh(max(0, α−2.0))` avec des α < 2 → terme nul partout, la composante spectrale ne pesait rien | — (formulation remplacée) |
| `d2_compiler.CUDA_TRANSITION_MATRIX` | Lookup par `tuple(sorted(...))` sur des clés non triées : 3 entrées sur 9 inatteignables, retombant sur un défaut plus coûteux que les valeurs déclarées | — (module remplacé) |
| `d2_compile_pipeline.infer_kv_params` | Comptait les tenseurs de classe `attn` (q_proj *et* o_proj) au lieu des blocs : cache KV surestimé ×2 | `test_planner.py::test_n_blocks_not_double_counted` |
| `d2_compile_pipeline._ilp_scipy` | `linprog` avec bornes continues = relaxation LP, pas un ILP ; arrondi à 0,5 pouvant violer la contrainte VRAM | `test_planner.py::test_solver_finds_true_optimum_on_tiny_instance` |
| `d2_compiler_v2.dp_switching` | DP sans contrainte mémoire, faisabilité testée après coup | — (supprimé) |
| `d2_compile_pipeline.alpha_w_synthetic` | `hash(cls)` dans la graine → résultats non reproductibles entre exécutions (hachage randomisé par processus) | `synthetic_model` utilise `default_rng(seed)` |
| `d2_qdf_bayesian.build_nodes` | Analysait `np.random.randn(*shape)` — du bruit gaussien, pas les poids du modèle | — (module remplacé) |
| `d2_qdf_bayesian.bayesian_coherence` | `svd(..., compute_uv=False)` dépaqueté en trois → `ValueError` | — |
| `quant_graph_compiler_v2.optimize` | Passe sans effet dans les deux branches ; graphe `networkx` construit puis inutilisé | — |
| `d2_rtx_gguf_profiler.build_clusters` | Fusion de singletons laissant deux clusters adjacents de même politique → compte de transitions faux | `Plan.n_switches` |
| `spectral_theory.SpectralIR` | Quatre SVD complets de la même matrice par couche | `d2.spectral.analyze` en fait un |
| `spectral_theory.test_power_law` | `ks_2samp` contre une suite **déterministe** : la p-valeur et `is_power_law` n'avaient pas d'interprétation | `power_law_fit` renvoie la distance KS, sans p-valeur |
| `d2_compiler._save_artifacts` | `csv.DictWriter` sans `newline=''` : une ligne vide sur deux sous Windows | — |
| `app.py` | `share=True` par défaut → tunnel public à chaque démarrage | `--share` opt-in |
| `app.py._load_layers_from_model` | `except Exception: return _get_example_layers()` → un échec de chargement renvoyait 8 couches d'exemple sans le dire | erreurs remontées |
| `app.py` | Tenseurs >2D repliés en `[shape[0], -1]` → dimension puis VRAM négatives | `d2.loaders` replie correctement |
| Partout | `/tmp/hf_cache` codé en dur | cache par défaut de `huggingface_hub` |
| Partout | Emoji et caractères de dessin sur console cp1252 → `UnicodeEncodeError` en fin de scan | `d2.console.setup()` |

---

## 5. Comptabilité mémoire

Le v1 utilisait `bpe = 0.5` pour l'INT4 et `1.0` pour l'INT8. Les vraies tailles ggml, échelles comprises :

| Format | v1 | réel | écart |
|---|---:|---:|---:|
| Q4_K_M | 0,5 o/poids | 0,5625 | +11 % |
| Q8_0 | 1,0 | 1,0625 | +6 % |
| Q6_K | — | 0,8203 | — |

Sur un modèle de 8 milliards de paramètres, l'erreur Q4_K représente 500 Mo — de quoi faire déborder un budget serré sans que rien ne le signale. `tests/test_formats.py` vérifie chaque valeur contre `ggml-common.h`.

Le budget mélangeait par ailleurs les unités : `budget_b = vram_budget_gb * 1024**3` mais affichage du détail en `1e9`, si bien que les lignes W + KV + Act + Frag ne totalisaient pas le total affiché. Tout est en base 10 désormais (`test_planner.py::test_budget_decomposition_sums_to_total`).

---

## 6. Export : la mauvaise option

`d2_production.export_gguf` produisait :

```
--override-tensor blk.0.attn_q.weight=q8_0
```

`--override-tensor` (`-ot`) de llama.cpp associe un motif de nom de tenseur à un **type de buffer** — c'est un réglage de placement mémoire (`-ot "\.ffn_.*_exps\.=CPU"`). Lui passer un nom de type ggml ne quantifie rien. Le README indiquait de surcroît de l'utiliser avec `llama-cli`, côté inférence, alors que la quantification a lieu à la conversion.

La bonne option est `llama-quantize --tensor-type`. Par ailleurs, un nom de tenseur non reconnu était renvoyé tel quel « puisque llama.cpp l'ignorera sans erreur » — c'est précisément le problème : la couche n'était alors pas quantifiée comme prévu, silencieusement. Les noms non traduits sont maintenant listés dans le champ `unmapped`.

Côté TensorRT : `trtllm-build` n'a pas d'option `--per_layer_precision`, utilisée par les deux scripts `.ps1`, et `--max_output_len` a été remplacé par `--max_seq_len`.

---

## 7. Mesures présentées comme telles sans en être

`d2_profiler.py` titrait « Mesures reelles vs Predictions D2-V12 » au-dessus de :

```python
lat = m * n * bpe / 1000
bw  = (m * n * bpe) / (lat * 1e-6) / 1e9
```

La seconde ligne se simplifie en `bw = 1.0` pour toute entrée — la « bande passante mesurée » valait 1 Go/s sur chaque ligne. Les valeurs de référence portaient le commentaire `# Dummy model metadata`. Aucune mesure n'avait lieu, et le README décrivait ce fichier comme un « Profiler GPU torch.profiler » alors que `torch` n'y était pas importé.

De même, `--benchmark` du scanner RTX exécutait `F.linear(x, Wq.to(float16) * scale)` pour l'INT8 et `F.linear(x, Wt)` pour l'INT4 et le FP8 : les trois « mesures » étaient du FP16, et `bw_gbs` utilisait `rows*cols*2` quel que soit le format.

Règle appliquée maintenant : toute grandeur non mesurée est préfixée `~` et sa provenance figure dans la sortie.

---

## 8. Tests

`d2_blindspot_tests.py` ne touchait aucun code de production. Il comparait des constantes déclarées dans le fichier à d'autres constantes du même fichier :

```python
SINK_OLD, SINK_NEW = 128, 4
ok1 = frac_new < frac_old            # 4 < 128
for age in [0, 1, 2, 3]:
    ok = age < SINK_NEW              # 0 < 4
```

Aucun de ces contrôles n'aurait échoué si tout le code de production avait été supprimé. Les mêmes points de littérature sont désormais vérifiés sur le comportement réel dans `tests/test_literature.py`.

Les deux scripts `test_real_models*.py` avaient par ailleurs divergé (politiques et seuils différents pour le même modèle) et étaient ramassés par pytest bien qu'ils téléchargent des modèles et ne contiennent aucune assertion.

---

## 9. Correspondance des API

| v1 | v3 |
|---|---|
| `d2_production.solve_quantization_plan` | conservée (façade) ou `d2.plan_layers` |
| `d2_production.export_gguf` | conservée ou `d2.export_llama_cpp` |
| `d2_compiler.D2QuantizationCompiler` | `d2.plan_layers` + `d2.export_llama_cpp` |
| `d2_compiler_v2.KPEv14` | `d2.spectral.analyze` |
| `d2_compiler_v2.from_huggingface` | `d2.load_huggingface` |
| `d2_compiler_v2.MemoryModel` | `d2.planner.MemoryBudget`, `d2.planner.kv_cache_bytes` |
| `d2_compiler_v2.ILPSolver` | `d2.planner.solve` |
| `quant_graph_compiler_v2.QuantGraphCompilerV2` | `d2.plan_layers` |
| `d2_qdf_bayesian*.QDFV5Engine` | `d2.sensitivity.sensitivity_matrix` |
| `v18.solve_quantization` | `d2.plan_layers` |
| `d2_compile_pipeline.run_pipeline` | `python d2_rtx_gguf_profiler.py` |
| `d2_compile_pipeline.kv_cache_gb` | `d2.planner.kv_cache_bytes` |
| `d2_compile_pipeline.D2DynamicRouter` | `d2_dynamic_v13.kv_plan` |
| `spectral_theory.QuantizationPolicy.recommend_dtype` | supprimée — voir §1 |
| `d2_blindspot_tests` | `pytest tests/` |
| `test_real_models_fr` | fusionné dans `test_real_models.py` |

Les modules remplacés lèvent une `AttributeError` explicite indiquant la fonction correspondante. Ils peuvent être supprimés sans conséquence : rien dans le dépôt ne les importe.

---

## 10. Points restés ouverts

- **Les erreurs des K-quants sont majorées.** llama.cpp choisit ses échelles par une recherche itérative pondérée (`make_qkx2_quants`) ; on reproduit la structure exacte des blocs mais avec un choix min/max direct. L'erreur simulée est donc pessimiste de l'ordre de 5 à 15 % sur Q4_K. C'est conservateur dans le bon sens, mais un plan calibré sur les vrais quantificateurs serait plus fin.
- **Pas de validation aval.** Rien ici ne mesure la perplexité ou la qualité de génération. Confirmer qu'un plan D2 bat le préréglage uniforme de même taille demande de quantifier les deux et de lancer `llama-perplexity`. Les gains ne sont pas revendiqués tant que ce n'est pas fait.
- **Les préfacteurs d'importance de couche restent des a priori** tant qu'aucune imatrix n'est fournie. Avec `--imatrix`, la décision repose sur des statistiques mesurées.
