#!/usr/bin/env python3
"""
Fondements spectraux — module de référence
===========================================

Ce fichier expose les grandeurs spectrales et documente **ce qu'elles ne
permettent pas de conclure**. Le calcul est délégué à `d2.spectral`, seule
implémentation du dépôt.

Ce qui a changé
---------------

1. **La politique était inversée entre les fichiers.** Le v1 contenait deux
   règles contradictoires pour la même grandeur :

   =========================================  =========================
   `alpha_spectral_scanner`, `d2_rtx_gguf_…`  alpha élevé -> INT4/NVFP4
   `spectral_theory`, `d2_compiler`           alpha élevé -> FP16
   =========================================  =========================

   Aucune des deux n'est étayée. Chez Martin & Mahoney, alpha mesure la
   *qualité d'entraînement* d'une couche, pas sa robustesse à la
   quantification, et aucun travail publié ne relie alpha à une largeur de
   bits soutenable. `QuantizationPolicy` ci-dessous ne renvoie donc plus un
   type : elle renvoie un **diagnostic**, et renvoie vers le planificateur
   pour la décision.

2. **Le test de loi de puissance était invalide.** `ks_2samp(s, s_synthetic)`
   comparait les valeurs singulières à une suite *déterministe* `i^(-beta)`
   renormalisée. Un test à deux échantillons suppose deux tirages aléatoires ;
   la p-valeur obtenue n'avait aucune interprétation, et `is_power_law` non
   plus. On rapporte désormais la distance KS à une loi ajustée
   (Clauset–Shalizi–Newman), sans p-valeur — l'obtenir correctement demande un
   bootstrap semi-paramétrique, coûteux et hors périmètre.

3. **`instability = alpha * (1 + rho_d)` était constant.** `rho_d` était la
   densité, c'est-à-dire la fraction d'éléments non nuls : pour une matrice de
   poids flottants elle vaut ~1.0 partout. Le facteur `(1 + rho_d)` valait donc
   toujours 2 et n'apportait aucune information.

4. **Quatre SVD par couche.** `SpectralIR.__init__` recalculait la même
   décomposition dans `CVector`, `stable_rank`, `spectral_radius` puis une
   quatrième fois. Un seul SVD suffit.

5. **`compressibility` était mal documentée.** `1/log(1+alpha)` tend vers 0
   quand alpha croît, pas vers 0.5.

Références
----------
- Martin & Mahoney, JMLR 22(165), 2021.
- Martin, Peng & Mahoney, Nature Communications 12:4122, 2021.
- Clauset, Shalizi & Newman, SIAM Review 51(4), 2009.
- Roy & Vetterli, EUSIPCO 2007 (rang effectif).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from d2 import spectral as _spectral
from d2.spectral import (  # ré-export
    SpectralStats,
    alpha_from_index_slope,
    alpha_hill,
    effective_rank,
    index_slope,
    singular_values,
    spectral_entropy,
    stable_rank,
)

__all__ = [
    "SpectralStats", "SpectralDescriptor", "QuantizationPolicy",
    "analyze", "power_law_fit", "alpha_hill", "alpha_from_index_slope",
    "index_slope", "stable_rank", "effective_rank", "spectral_entropy",
    "singular_values",
]


def analyze(W: np.ndarray, max_dim: int = 4096) -> SpectralStats:
    """Analyse spectrale complète (un seul SVD)."""
    return _spectral.analyze(W, max_dim=max_dim)


@dataclass
class SpectralDescriptor:
    """Descripteur d'une couche. Remplace l'ancien « C-vector ».

    L'ancien vecteur mélangeait des grandeurs d'échelles incompatibles
    (`C_r = alpha*(1+densité)` non borné, `C_s = 1/log(1+alpha)` divergent en
    0) et les combinait par une somme pondérée dont les poids
    `[0.35, 0.30, 0.20, 0.15]` n'étaient adossés à rien. On expose ici les
    grandeurs séparément, chacune avec sa définition et sa plage.
    """

    name: str
    alpha: float           # exposant ESD ; nan si non estimable
    ks: float              # distance KS de l'ajustement
    stable_rank: float     # [1, rang]
    effective_rank: float  # [1, rang]
    entropy: float         # [0, 1] ; 1 = spectre plat
    spectral_norm: float   # plus grande valeur singulière

    @classmethod
    def from_matrix(cls, W: np.ndarray, name: str = "") -> "SpectralDescriptor":
        sv, _ = singular_values(W)
        st = _spectral.analyze(W)
        return cls(
            name=name,
            alpha=st.alpha,
            ks=st.ks,
            stable_rank=st.stable_rank,
            effective_rank=st.effective_rank,
            entropy=st.entropy,
            spectral_norm=float(sv[0]) if sv.size else float("nan"),
        )

    def to_dict(self) -> Dict:
        return {k: (None if isinstance(v, float) and not np.isfinite(v) else v)
                for k, v in self.__dict__.items()}


class QuantizationPolicy:
    """Diagnostic spectral. **Ne renvoie pas de type de quantification.**

    Le v1 exposait `recommend_dtype(c_vector) -> str` avec des seuils
    (1.2 / 1.6 / 2.0) posés sans source, et dans le sens inverse de trois
    autres fichiers du dépôt. Cette classe se limite à ce que la littérature
    autorise à dire.
    """

    #: Plages de Martin & Mahoney (2021), sur la qualité d'*entraînement*.
    TRAINING_QUALITY = [
        (0.0, 2.0, "queue tres lourde ; couche fortement correlee, "
                   "possiblement sur-entrainee"),
        (2.0, 4.0, "bien entrainee (auto-regularisation a queue lourde)"),
        (4.0, 6.0, "moyennement entrainee"),
        (6.0, float("inf"), "proche d'une matrice aleatoire ; sous-entrainee"),
    ]

    @staticmethod
    def training_quality(alpha: float) -> str:
        """Interprétation de alpha au sens de Martin & Mahoney."""
        if not np.isfinite(alpha):
            return "non estimable (queue spectrale trop courte)"
        for lo, hi, label in QuantizationPolicy.TRAINING_QUALITY:
            if lo <= alpha < hi:
                return label
        return "hors plage"

    @staticmethod
    def recommend_dtype(*_args, **_kwargs):
        """Supprimée : alpha ne prédit pas la largeur de bits soutenable."""
        raise NotImplementedError(
            "Choisir une précision à partir du seul alpha n'est pas étayé : le "
            "v1 le faisait dans deux directions opposées selon le fichier. "
            "Utilisez `d2.plan_layers`, qui décide à partir de l'erreur de "
            "quantification mesurée (d2.formats.relative_error) pondérée par "
            "l'importance de couche, et sous contrainte mémoire."
        )


def power_law_fit(sv: np.ndarray) -> Dict:
    """Ajustement loi de puissance de la queue spectrale.

    Returns:
        `{'alpha', 'ks_distance', 'xmin', 'n_tail', 'note'}`.

    Il n'y a **pas** de p-valeur ni de booléen `is_power_law` : les obtenir
    correctement suppose le bootstrap semi-paramétrique de Clauset et al.
    (§4.1), pas un `ks_2samp` contre une suite déterministe comme dans le v1.
    Une distance KS faible indique un bon ajustement *relatif*, elle ne teste
    aucune hypothèse.
    """
    sv = np.asarray(sv, dtype=np.float64)
    alpha, ks, xmin, n_tail = alpha_hill(sv[sv > 0] ** 2)
    return {
        "alpha": None if not np.isfinite(alpha) else float(alpha),
        "ks_distance": None if not np.isfinite(ks) else float(ks),
        "xmin": None if not np.isfinite(xmin) else float(xmin),
        "n_tail": int(n_tail),
        "note": (
            "distance KS d'ajustement, pas un test d'hypothese. "
            "Une p-valeur exigerait un bootstrap semi-parametrique "
            "(Clauset et al. 2009, sec. 4.1)."
        ),
    }


if __name__ == "__main__":
    import json

    from d2 import console

    console.setup()
    rng = np.random.default_rng(42)

    print("Comparaison de trois spectres\n" + "=" * 62)
    cases = {
        "gaussienne (Marchenko-Pastur)": rng.standard_normal((512, 512)),
        "queue lourde (produit de gaussiennes)":
            rng.standard_normal((512, 512)) * rng.standard_normal((512, 512)),
        "rang faible (rang 8 + bruit)":
            rng.standard_normal((512, 8)) @ rng.standard_normal((8, 512))
            + 0.01 * rng.standard_normal((512, 512)),
    }
    for label, W in cases.items():
        d = SpectralDescriptor.from_matrix(W.astype(np.float32), label)
        print(f"\n{label}")
        print(f"  alpha          : {d.alpha:.3f}  (KS={d.ks:.3f})")
        print(f"  interpretation : {QuantizationPolicy.training_quality(d.alpha)}")
        print(f"  rang stable    : {d.stable_rank:.1f}")
        print(f"  rang effectif  : {d.effective_rank:.1f}")
        print(f"  entropie norm. : {d.entropy:.3f}")

    print("\n" + "=" * 62)
    print("Pour un plan de quantification : d2_rtx_gguf_profiler.py")
    print("alpha seul ne suffit pas a choisir une precision.")
