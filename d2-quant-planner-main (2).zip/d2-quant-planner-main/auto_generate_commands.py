#!/usr/bin/env python3
"""
Auto-generate llama-quantize commands pour toutes les stratégies
Puis exécute les commandes automatiquement si llama-quantize est disponible
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime
import logging
import shutil

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)-8s | %(message)s')
logger = logging.getLogger(__name__)

# Configuration
MODEL_PATH = r"C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"
OUTPUT_DIR = Path("qwen_optimized")

STRATEGIES = [
    {
        'name': 'conservative',
        'budget': '8GB',
        'attention': 'q4_k',
        'mlp': 'q4_k',
        'embedding': 'q5_k',
        'base_fmt': 'Q4_K_M',
    },
    {
        'name': 'balanced',
        'budget': '12GB',
        'attention': 'q5_k',
        'mlp': 'q4_k',
        'embedding': 'f16',
        'base_fmt': 'Q4_K_M',
    },
    {
        'name': 'quality',
        'budget': '16GB',
        'attention': 'q6_k',
        'mlp': 'q5_k',
        'embedding': 'f16',
        'base_fmt': 'Q5_K_M',
    },
    {
        'name': 'maximum',
        'budget': '24GB',
        'attention': 'f16',
        'mlp': 'q6_k',
        'embedding': 'f16',
        'base_fmt': 'Q6_K',
    },
]

def find_llama_quantize():
    """Chercher llama-quantize dans les chemins courants"""
    candidates = [
        "llama-quantize",
        "llama-quantize.exe",
        r"C:\Program Files\llama.cpp\llama-quantize.exe",
        r"C:\llama.cpp\llama-quantize.exe",
        Path.home() / "llama.cpp" / "build" / "bin" / "llama-quantize.exe",
    ]

    for candidate in candidates:
        try:
            result = subprocess.run(
                f"{candidate} --version",
                shell=True,
                capture_output=True,
                timeout=2
            )
            if result.returncode == 0:
                logger.info(f"✅ Found llama-quantize: {candidate}")
                return candidate
        except:
            continue

    return None

def generate_commands():
    """Générer les commandes pour chaque stratégie"""
    logger.info("\n" + "="*70)
    logger.info("GENERATION DES COMMANDES LLAMA-QUANTIZE")
    logger.info("="*70 + "\n")

    OUTPUT_DIR.mkdir(exist_ok=True)

    commands = {}
    script_lines = []

    for strategy in STRATEGIES:
        name = strategy['name']
        budget = strategy['budget']
        output_name = f"qwen-{name}-{budget.replace('GB', 'gb')}.gguf"
        output_path = OUTPUT_DIR / output_name

        cmd = [
            'llama-quantize',
            '--tensor-type', f"attention={strategy['attention']}",
            '--tensor-type', f"mlp={strategy['mlp']}",
            '--tensor-type', f"embedding={strategy['embedding']}",
            str(MODEL_PATH),
            str(output_path),
            strategy['base_fmt'],
        ]

        cmd_str = ' '.join(cmd)

        commands[name] = {
            'strategy': strategy,
            'command': cmd_str,
            'output': str(output_path),
        }

        logger.info(f"📝 {name.upper()} ({budget}):")
        logger.info(f"   {cmd_str}\n")

        script_lines.append(f"# {name.upper()} ({budget})")
        script_lines.append(cmd_str)
        script_lines.append("")

    # Sauvegarder les commandes en JSON
    commands_path = OUTPUT_DIR / "quantize_commands.json"
    with open(commands_path, 'w') as f:
        json.dump(commands, f, indent=2)
    logger.info(f"✅ Commands saved: {commands_path}\n")

    # Sauvegarder le script PowerShell
    ps_script_path = OUTPUT_DIR / "run_quantization.ps1"
    ps_lines = [
        "# Auto-generated quantization script",
        "# Run each command to generate optimized GGUFs",
        "",
    ] + [line if line.startswith("#") else line.replace("llama-quantize", "& llama-quantize")
         if line and not line.startswith("#") else line for line in script_lines]

    with open(ps_script_path, 'w') as f:
        f.write("\n".join(ps_lines))
    logger.info(f"✅ PowerShell script: {ps_script_path}\n")

    # Sauvegarder le script Bash
    sh_script_path = OUTPUT_DIR / "run_quantization.sh"
    with open(sh_script_path, 'w') as f:
        f.write("#!/bin/bash\n")
        f.write("# Auto-generated quantization script\n")
        f.write("\n".join(script_lines))
    logger.info(f"✅ Bash script: {sh_script_path}\n")

    return commands

def try_execute_commands(commands):
    """Essayer d'exécuter les commandes si llama-quantize est disponible"""
    llama_path = find_llama_quantize()

    if not llama_path:
        logger.info("="*70)
        logger.warning("⚠️  llama-quantize not found in PATH")
        logger.info("="*70)
        logger.info("\n📋 TO COMPLETE QUANTIZATION:\n")
        logger.info("1. Install llama.cpp from: https://github.com/ggerganov/llama.cpp/releases")
        logger.info("   - Download pre-built binaries (or build from source)")
        logger.info("   - Add directory to PATH, or copy llama-quantize.exe to your project")
        logger.info("")
        logger.info("2. Then run one of these:")
        logger.info(f"   PowerShell: .\\qwen_optimized\\run_quantization.ps1")
        logger.info(f"   Bash: bash qwen_optimized/run_quantization.sh")
        logger.info("")
        logger.info("3. Or run individual commands from: qwen_optimized/quantize_commands.json")
        logger.info("")
        return False

    logger.info("="*70)
    logger.info("🚀 EXECUTING QUANTIZATION COMMANDS")
    logger.info("="*70 + "\n")

    for name, cmd_data in sorted(commands.items()):
        logger.info(f"▶️  {name.upper()}...")
        logger.info(f"   Output: {cmd_data['output']}")

        try:
            result = subprocess.run(
                cmd_data['command'],
                shell=True,
                capture_output=True,
                timeout=3600,  # 1 hour timeout
                text=True
            )

            if result.returncode == 0:
                logger.info(f"✅ Complete!")

                # Check file size
                output_path = Path(cmd_data['output'])
                if output_path.exists():
                    size_gb = output_path.stat().st_size / 1e9
                    logger.info(f"   Size: {size_gb:.2f} GB")
            else:
                logger.error(f"❌ Failed!")
                logger.error(result.stderr)

        except subprocess.TimeoutExpired:
            logger.error(f"❌ Timeout!")
        except Exception as e:
            logger.error(f"❌ Error: {e}")

        logger.info("")

    return True

def generate_report():
    """Générer un rapport final"""
    logger.info("="*70)
    logger.info("📊 RAPPORT FINAL")
    logger.info("="*70 + "\n")

    gguf_files = list(OUTPUT_DIR.glob("qwen-*.gguf"))

    if gguf_files:
        logger.info("✅ GENERATED GGUF FILES:\n")
        for gguf_file in sorted(gguf_files):
            size_gb = gguf_file.stat().st_size / 1e9
            logger.info(f"  {gguf_file.name:<40} {size_gb:.2f} GB")
    else:
        logger.info("❌ No GGUF files generated yet")

    logger.info("\n" + "="*70)
    logger.info("NEXT STEPS:")
    logger.info("="*70)
    logger.info("1. Use the quantized GGUFs with llama-cli:")
    logger.info("   llama-cli -m qwen-balanced-12gb.gguf -ngl 33 -p 'Your prompt'")
    logger.info("")
    logger.info("2. For faster loading, use llama-server:")
    logger.info("   llama-server -m qwen-balanced-12gb.gguf -ngl 33")
    logger.info("")
    logger.info("3. Benchmark perplexity:")
    logger.info("   llama-perplexity -m qwen-balanced-12gb.gguf -f calibration.txt")
    logger.info("")

def main():
    logger.info("\n" + "█"*70)
    logger.info("QWEN3.5-9B AUTO-QUANTIZATION COMMAND GENERATOR")
    logger.info("█"*70 + "\n")

    logger.info(f"Model: {MODEL_PATH}")
    logger.info(f"Output dir: {OUTPUT_DIR}")
    logger.info("")

    # Générer les commandes
    commands = generate_commands()

    # Essayer d'exécuter
    success = try_execute_commands(commands)

    # Générer le rapport
    generate_report()

    logger.info("\n" + "█"*70)
    logger.info("✅ DONE!")
    logger.info("█"*70 + "\n")

if __name__ == "__main__":
    main()
