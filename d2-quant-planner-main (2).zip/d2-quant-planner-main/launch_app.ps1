# Qwen3.5-9B Optimizer - Application Launcher
# ==============================================

Write-Host "╔════════════════════════════════════════════════════════════╗"
Write-Host "║                                                            ║"
Write-Host "║        Qwen3.5-9B Optimizer - Desktop Application          ║"
Write-Host "║                                                            ║"
Write-Host "╚════════════════════════════════════════════════════════════╝"
Write-Host ""

# Check Python
Write-Host "🔍 Checking Python..." -ForegroundColor Cyan
$python = Get-Command python3 -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command python -ErrorAction SilentlyContinue
}

if (-not $python) {
    Write-Host "❌ Python not found!" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Python found: $($python.Source)" -ForegroundColor Green
Write-Host ""

# Install PySide6
Write-Host "📦 Installing dependencies..." -ForegroundColor Cyan
& $python.Source -m pip install PySide6 -q

Write-Host "✅ Dependencies ready!" -ForegroundColor Green
Write-Host ""

# Launch app
Write-Host "🚀 Launching application..." -ForegroundColor Green
Write-Host ""

& $python.Source qwen_optimizer_app.py

Write-Host ""
Write-Host "Application closed." -ForegroundColor Yellow
