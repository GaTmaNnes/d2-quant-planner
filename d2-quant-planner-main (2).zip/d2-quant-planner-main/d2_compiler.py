#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_compiler - remplace par le package `d2`
==========================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
Ce module implementait un troisieme modele de decision, incompatible avec les
deux autres du depot :

* `_infer_type` posait « risque eleve -> FP16 » a partir de
  `0.6*alpha + 0.4*alpha*(1+densite)`, soit `alpha*(1.0 + 0.4*densite)`. Comme
  la densite d'une matrice de poids flottants vaut ~1.0, le second terme etait
  constant : le critere se reduisait a un seuil sur alpha, dans le sens inverse
  de celui de `d2_rtx_gguf_profiler`.
* `CUDA_TRANSITION_MATRIX` etait consultee via `tuple(sorted(...))` alors que
  ses cles ne sont pas triees : ("NVFP4","INT8"), ("NVFP4","FP8") et
  ("INT8","FP8") etaient introuvables et retombaient sur le defaut 2.0,
  superieur aux couts declares (1.5, 1.2, 0.7).
* `simulate_and_fix_fragmentation` comptait les fragmentations *avant*
  correction puis renvoyait le graphe *apres* correction, et ne rattrapait
  qu'un seul evenement en arriere (`fixed_graph[-1]`).
* `csv.DictWriter` sans `newline=''` : une ligne vide sur deux sous Windows.
* Son entree `precision_map.json` n'existe pas dans le depot.

Correspondance
--------------
* ``build_ir_from_json`` -> ``d2.load_gguf / d2.load_safetensors``
* ``unified_optimizer`` -> ``d2.plan_layers``
* ``simulate_and_fix_fragmentation`` -> ``Plan.n_switches``
* ``D2QuantizationCompiler`` -> ``d2.plan_layers + d2.export_llama_cpp``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'd2_compiler'

_MOVED = {'build_ir_from_json': 'd2.load_gguf / d2.load_safetensors', 'unified_optimizer': 'd2.plan_layers', 'simulate_and_fix_fragmentation': 'Plan.n_switches', 'D2QuantizationCompiler': 'd2.plan_layers + d2.export_llama_cpp'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
