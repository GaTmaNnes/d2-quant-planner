#!/usr/bin/env python3
"""
d2_production — Façade de compatibilité au-dessus du package `d2`
==================================================================

Ce module ne contient plus de logique : il traduit l'API historique
(`solve_quantization_plan`, `summarize`, `export_gguf`) vers `d2.planner`.
Tout le contenu du v1 a été remplacé pour trois raisons :

* il importait `ortools` sans que le paquet figure dans `requirements.txt` ;
* son modèle de coût `G(q) − λ·lw·risk(q)` reposait sur des valeurs de `risk`
  posées à la main (0.00 / 0.35 / 1.00) sans source, alors que l'erreur de
  quantification est directement mesurable ;
* `export_gguf` produisait des options `--override-tensor`, qui pilotent le
  *placement mémoire* dans llama.cpp et ne quantifient rien.

Le paramètre `w_risk` / `lam` n'a plus d'équivalent direct : le nouveau
planificateur minimise l'erreur mesurée sous contrainte mémoire, sans arbitrage
scalaire à régler. Il est réinterprété en **plafond d'erreur par couche** et
émet un `DeprecationWarning`.

Préférez directement :

```python
import d2
plan = d2.plan_layers(layers, d2.get_profile("rtx4090"), vram_budget_gb=8.0)
```
"""

from __future__ import annotations

import warnings
from typing import Dict, List, Optional

import numpy as np

import d2
from d2.sensitivity import LayerSpec, classify

__all__ = [
    "solve_quantization_plan",
    "summarize",
    "export_gguf",
    "classify",
    "DTYPE_PROPS",
]

#: Conservé pour les scripts qui l'introspectaient. Les octets par poids sont
#: désormais exacts (un Q4_K_M occupe 0.5625 o/poids, pas 0.5).
DTYPE_PROPS: Dict[str, Dict] = {
    "FP16": {"bpe": d2.bytes_per_weight("F16"), "gguf": "f16", "d2": "F16"},
    "INT8": {"bpe": d2.bytes_per_weight("Q8_0"), "gguf": "q8_0", "d2": "Q8_0"},
    "INT4": {"bpe": d2.bytes_per_weight("Q4_K"), "gguf": "q4_K", "d2": "Q4_K"},
}

_LEGACY_OF = {"F16": "FP16", "BF16": "FP16", "Q8_0": "INT8", "INT8": "INT8",
              "Q6_K": "INT8", "Q5_K": "INT4", "Q4_K": "INT4",
              "INT4_AWQ": "INT4", "Q3_K": "INT4", "Q2_K": "INT4"}


def _risk_to_ceiling(w_risk: Optional[float]) -> Optional[float]:
    """Traduit l'ancien λ en plafond d'erreur relative par couche.

    L'échelle historique allait de 0.1 (agressif) à 5.0 (conservateur). On la
    projette sur [20 %, 0.5 %] de façon monotone décroissante. La
    correspondance est arbitraire — c'est inévitable, les deux formulations ne
    décrivent pas la même chose — mais elle préserve le *sens* du réglage.
    """
    if w_risk is None:
        return None
    lam = float(np.clip(w_risk, 0.1, 5.0))
    return float(np.interp(lam, [0.1, 1.0, 2.0, 5.0], [0.20, 0.08, 0.03, 0.005]))


def solve_quantization_plan(
    layers: List[Dict],
    vram_budget_gb: float,
    lam: Optional[float] = None,
    w_speed: float = 1.0,
    w_risk: Optional[float] = None,
    gpu: str = "rtx4090",
    ctx_len: int = 4096,
    **kwargs,
) -> List[Dict]:
    """Planifie la quantification (signature historique).

    Args:
        layers: `[{'name': str, 'shape': [m, n], 'weights': np.ndarray?}, ...]`.
            Si `weights` est fourni, l'erreur est **mesurée** ; sinon un modèle
            analytique est utilisé et le champ `measured` du résultat vaut False.
        vram_budget_gb: budget VRAM total en Go.
        lam / w_risk:   plafond d'erreur (déprécié, voir `_risk_to_ceiling`).
        w_speed:        ignoré. En décodage, la vitesse est déterminée par les
            octets lus, donc par la contrainte mémoire : un poids séparé
            comptait deux fois la même grandeur.
        gpu:            profil matériel cible.
        ctx_len:        contexte, pour dimensionner le cache KV.

    Returns:
        Liste de dicts avec les clés historiques (`dtype`, `vram_gb`, ...)
        enrichies de `format`, `rel_error`, `measured`.
    """
    if w_speed != 1.0:
        warnings.warn(
            "w_speed est ignoré : en décodage la latence est proportionnelle "
            "aux octets lus, déjà couverts par la contrainte mémoire.",
            DeprecationWarning, stacklevel=2,
        )
    ceiling = _risk_to_ceiling(w_risk if w_risk is not None else lam)
    if ceiling is not None:
        warnings.warn(
            "w_risk/lam est déprécié : le planificateur minimise l'erreur "
            f"mesurée sous contrainte mémoire. Réinterprété en plafond "
            f"d'erreur par couche de {ceiling:.1%}. Utilisez "
            "`d2.plan_layers(..., max_rel_error=...)`.",
            DeprecationWarning, stacklevel=2,
        )

    specs = [
        LayerSpec(
            name=l["name"],
            shape=list(l["shape"]),
            weights=(np.asarray(l["weights"], dtype=np.float32)
                     if l.get("weights") is not None else None),
        )
        for l in layers
    ]
    measure = any(s.weights is not None for s in specs)

    plan = d2.plan_layers(
        specs,
        d2.get_profile(gpu),
        vram_budget_gb=vram_budget_gb,
        ctx_len=ctx_len,
        measure=measure,
        max_rel_error=ceiling if measure else None,
        **kwargs,
    )

    out = []
    for src, e in zip(layers, plan.entries):
        out.append({
            **src,
            "dtype": _LEGACY_OF.get(e.format, "FP16"),
            "format": e.format,
            "layer_type": e.cls,
            "vram_gb": e.bytes / 1e9,
            "rel_error": e.rel_error,
            "omega": e.omega,
            "measured": e.measured,
            "forced": e.forced,
        })
    out_obj = out
    # On attache le Plan pour que `summarize`/`export_gguf` n'aient pas à
    # replanifier (le v1 recalculait tout à chaque appel).
    try:
        out_obj = _PlanList(out)
        out_obj._plan = plan
    except Exception:
        pass
    return out_obj


class _PlanList(list):
    """`list` porteuse du `Plan` d'origine, pour les fonctions en aval."""

    _plan = None


def summarize(plan: List[Dict], vram_budget_gb: float,
              lam: float = 1.0, w_speed: float = 1.0,
              w_risk: Optional[float] = None) -> str:
    """Résumé textuel.

    Contrairement au v1, cette fonction ne dépend plus de l'ordre des
    arguments pour retrouver λ : elle lit le `Plan` réel. Le bug historique —
    `summarize(plan, budget, 1.0, w_risk)` faisait atterrir `w_risk` dans
    `w_speed`, si bien que le résumé affichait toujours `lam=1.00` — ne peut
    plus se produire.
    """
    obj = getattr(plan, "_plan", None)
    if obj is not None:
        return d2.summarize(obj)

    from collections import Counter
    counts = Counter(e.get("dtype", "?") for e in plan)
    total = sum(e.get("vram_gb", 0.0) for e in plan)
    lines = [
        "=" * 54,
        "  D2 -- Plan de quantification",
        "=" * 54,
        f"  Couches   : {len(plan)}",
        f"  Budget    : {vram_budget_gb:.1f} Go   Utilise : {total:.3f} Go",
    ]
    for k, v in counts.most_common():
        lines.append(f"  {k:<9} : {v}")
    return "\n".join(lines)


def export_gguf(plan: List[Dict], path: str = "quant_plan.json",
                arch: Optional[str] = None,
                input_gguf: str = "model-f16.gguf",
                output_gguf: str = "model-d2.gguf") -> str:
    """Exporte le plan et retourne la commande `llama-quantize`.

    Le v1 générait des `--override-tensor NAME=q8_0` et documentait
    `llama-cli --model model.gguf $(cat plan_cmd.txt)`. Ces options ne
    quantifient rien : `--override-tensor` associe un motif de nom à un type de
    *buffer* (placement CPU/GPU). La quantification par tenseur se fait à la
    conversion, avec `llama-quantize --tensor-type`.
    """
    obj = getattr(plan, "_plan", None)
    if obj is None:
        raise TypeError(
            "export_gguf attend le résultat de solve_quantization_plan. "
            "Pour un plan construit à la main, utilisez "
            "`d2.export_llama_cpp(plan, ...)`."
        )
    payload = d2.export_llama_cpp(
        obj, input_gguf=input_gguf, output_gguf=output_gguf, json_path=path
    )
    cmd_path = path.replace(".json", "_cmd.txt")
    with open(cmd_path, "w", encoding="utf-8") as f:
        f.write(payload["command"] + "\n")
    return payload["command"]


# ─────────────────────────────────────────────────────────────────────────────


def _demo() -> None:
    from d2 import console

    console.setup()
    layers, info = d2.synthetic_model(n_blocks=8, hidden=2048,
                                      intermediate=5632, vocab=32000)
    caps = d2.get_profile("rtx4090")
    plan = d2.plan_layers(layers, caps, vram_budget_gb=1.0, ctx_len=4096,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan, caps, ctx_len=4096))
    print()
    print(d2.layer_table(plan, limit=10))
    print()
    payload = d2.export_llama_cpp(plan, json_path="quant_plan.json")
    print("  Commande llama-quantize :")
    for line in payload["command"].split("\n")[:8]:
        print("   ", line)
    print("  ...")
    print("  -> quant_plan.json")


if __name__ == "__main__":
    _demo()
