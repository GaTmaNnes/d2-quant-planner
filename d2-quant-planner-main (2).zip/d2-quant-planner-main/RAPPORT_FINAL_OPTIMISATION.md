# Rapport archivé — optimisation Qwen 3.5 (GTX 1080 / RTX 5070)

> **Statut : archivé.** Ce rapport décrit une expérience menée avec la version 1
> du planificateur. Les chiffres de benchmark qu'il contient ne sont pas
> reproductibles avec le contenu de ce dépôt. Les corrections sont signalées en
> ligne. Conservé pour la traçabilité, pas comme référence.
>
> Pour l'état actuel : [README.md](README.md), [THEORY.md](THEORY.md),
> [MIGRATION.md](MIGRATION.md).

---

## 1. Analyse spectrale — ⚠️ mesures invalides

> La plupart des couches sont stables (α ≈ 1.0), mais les couches SSM montrent
> une sensibilité accrue (α > 1.4). Les couches `ssm_conv1d.weight` présentent
> une densité d'outliers de 41 %.

Le α ≈ 1.0 était le plancher de l'estimateur, pas une mesure : le scanner
analysait les octets bruts du GGUF au lieu des poids déquantifiés. Voir
[RAPPORT_ALPHA_GRAPH_BLACKWELL.md §1](RAPPORT_ALPHA_GRAPH_BLACKWELL.md).

Le chiffre de « 41 % de densité d'outliers » n'est produit par aucun script du
dépôt et sa définition n'est pas donnée.

**Ce qui reste probablement juste :** la prudence sur les couches `ssm_conv1d`.
Dans une récurrence, l'erreur de quantification s'accumule au fil des pas de
temps au lieu d'être amortie couche par couche. D2 leur attribue pour cette
raison un préfacteur d'importance de 5,0 — au-dessus de `attn_v` et `ffn_down`
(voir [THEORY.md §4](THEORY.md)). La conclusion était bonne, le raisonnement qui
y menait ne l'était pas.

---

## 2. Cibles matérielles — ⚠️ identifiants incorrects

Le rapport donnait la RTX 5070 en **sm_100** dans un paragraphe et **sn120**
dans un autre. Aucun des deux n'est correct :

| GPU | Compute capability |
|---|---|
| GTX 1080 | sm_61 |
| RTX 5070 / 5080 / 5090 | **sm_120** |
| B200 (Blackwell datacenter) | sm_100 |

`sn120` n'existe pas. Le v1 n'avait par ailleurs aucun profil Blackwell, et sa
détection de capacités déclarait A100, H100 et Blackwell dépourvus d'INT8
(voir [MIGRATION.md §4](MIGRATION.md)).

À noter : la GTX 1080 (sm_61) **n'a pas de tensor cores**. INT8 et INT4 n'y
apportent pas d'accélération de calcul ; le gain vient uniquement de la
réduction du trafic mémoire. D2 le reflète : `supported_formats` n'y propose
pas INT8.

---

## 3. Benchmarks — ⚠️ non reproductibles

| Mode | Vitesse Gen (tg128) | Économie VRAM KV |
|---|---|---|
| Standard (f16) | 28,9 t/s | 0 % |
| TurboQuant 3 | 28,1 t/s | −80 % |
| TurboQuant 4 | 28,3 t/s | −74 % |

Ces chiffres ne peuvent pas être reproduits avec ce dépôt : aucun script n'y
mesure de débit. Le seul « profileur » du v1 calculait
`lat = m*n*bpe/1000`, une formule fermée équivalente à supposer une mémoire à
1 Go/s (voir [MIGRATION.md §7](MIGRATION.md)).

Le point le plus douteux est la vitesse quasi inchangée (28,9 → 28,1 t/s) pour
une réduction de 80 % du cache KV. En décodage, la latence est proportionnelle
aux octets lus ; réduire fortement le trafic KV devrait se voir sur le débit.
Un résultat plat suggère que le goulot était ailleurs — ce qui aurait mérité
d'être investigué plutôt que présenté comme une validation.

Les kernels « TurboQuant 3/4 », « EDEN » et « QJL » ne figurent pas dans ce
dépôt et ne correspondent à aucun format de `d2/formats.py`.

---

## 4. Fichiers cités mais absents

`precision_map.json`, `run_gtx_1080_pascal.bat`, `llama-server.exe`,
`ggml-cuda.dll`, ainsi que le dossier `lama 1080-5070`. Le `.gitignore` de
l'époque ignorait `*.json` en bloc.

« beellama.cpp » est une coquille pour llama.cpp ; elle figurait aussi en dur
dans un `sys.path.append` d'`alpha_spectral_scanner.py`.

L'option `--adaptive-quant-level 2` recommandée en conclusion n'existe pas dans
llama.cpp amont.

---

## 5. Refaire l'exercice

```bash
# Statistiques d'activation
llama-imatrix -m qwen-f16.gguf -f calibration.txt -o qwen.imatrix

# Plan RTX 5070 (12 Go, sm_120)
python d2_rtx_gguf_profiler.py qwen-f16.gguf \
    --gpu-target rtx5070 --budget 12 --ctx 32768 --imatrix qwen.imatrix

# Plan GTX 1080 (8 Go, sm_61, pas de tensor core)
python d2_rtx_gguf_profiler.py qwen-f16.gguf \
    --gpu-target gtx1080 --budget 8 --ctx 8192 --imatrix qwen.imatrix

# Politique de cache KV
python d2_dynamic_v13.py --gpu rtx5070 --ctx 32768
```

Pour obtenir de vrais chiffres — ce que ce rapport n'a jamais fait :

```bash
llama-quantize <options du plan> qwen-f16.gguf qwen-d2.gguf Q4_K_M
llama-perplexity -m qwen-d2.gguf -f wikitext-2-raw/wiki.test.raw
llama-bench -m qwen-d2.gguf -p 512 -n 128
```

Comparer à un préréglage uniforme de **taille équivalente** (pas au F16) :
c'est la seule comparaison qui dit si la répartition par couche apporte quelque
chose.
