#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_real_models_fr — fusionné dans `test_real_models.py`
==========================================================

Le v1 maintenait deux copies du même banc d'essai, l'une avec les libellés en
anglais et l'autre en français. Elles avaient divergé : la politique de
quantification, les tables `DTYPE_INFO` et les seuils n'étaient déjà plus
identiques entre les deux fichiers, ce qui donnait deux verdicts différents
pour le même modèle.

Les deux souffraient par ailleurs des mêmes défauts :

* `compute_alpha_w`, `compute_stable_rank`, `compute_spectral_entropy` et
  `compute_spectral_radius` calculaient **chacune un SVD complet** de la même
  matrice, soit quatre décompositions par couche ;
* chaque fonction rattrapait toute exception par un `except: return <constante>`,
  donc une erreur mémoire ou une matrice dégénérée se traduisait par une
  valeur d'apparence plausible ;
* `quantization_policy(alpha_w, density)` appliquait « instabilité élevée ->
  FP16 », c'est-à-dire l'inverse de la politique de `d2_rtx_gguf_profiler` ;
* le nom `test_*.py` les faisait ramasser par pytest alors qu'ils téléchargent
  des modèles et ne contiennent aucune assertion.

Il n'y a plus qu'un script, `test_real_models.py`, entièrement en français.

    python test_real_models.py --model gpt2
    python test_real_models.py --model model.gguf --budgets 4,6,8 --spectral

La vraie suite de tests est dans `tests/`, lancée par `pytest tests/ -q`.

Ce fichier peut être supprimé sans conséquence.
"""

from __future__ import annotations

import sys

_MESSAGE = (
    "test_real_models_fr a ete fusionne dans test_real_models.py.\n"
    "Les deux copies avaient diverge (politique, seuils et tables differents).\n\n"
    "Executer :  python test_real_models.py --model gpt2\n"
    "Suite de tests :  pytest tests/ -q\n"
)


def __getattr__(name: str):
    raise AttributeError(
        "module 'test_real_models_fr' n'a pas d'attribut " + repr(name)
        + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
