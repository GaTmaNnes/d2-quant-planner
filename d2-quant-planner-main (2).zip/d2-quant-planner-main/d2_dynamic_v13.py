#!/usr/bin/env python3
"""
Politique de cache KV dynamique
================================

Recentré sur ce qui est réellement implémentable.

Le v1 faisait commuter la précision des **poids** token par token, avec
hystérésis. Ce n'est pas réalisable : les poids sont quantifiés une fois à la
conversion et résident sous cette forme en VRAM. Changer le format d'une
couche entre deux tokens supposerait de la requantifier à chaud, ce qui
coûterait des ordres de grandeur de plus que ce qu'on économise. Aucun runtime
(llama.cpp, TensorRT-LLM, vLLM) n'expose une telle bascule.

Ce qui **est** implémentable et soutenu par la littérature, c'est une politique
de précision sur le **cache KV** :

* StreamingLLM (Xiao et al., ICLR 2024) : les tout premiers tokens concentrent
  une masse d'attention disproportionnée ; les conserver en haute précision
  suffit à préserver la génération longue. 1 à 4 tokens suffisent.
* KVQuant (Hooper et al., NeurIPS 2024) et KIVI (Liu et al., ICML 2024) :
  le cache K se quantifie mieux par canal, le cache V par token ; 2–4 bits sont
  atteignables sur V, K est plus sensible.
* Le cache KV est réallouable et croît avec le contexte, donc une politique
  dépendant de la longueur a un sens opérationnel.

Corrections de bugs héritées
-----------------------------
* `SINK_THRESHOLD = 128` (v1) protégeait 128 tokens là où la littérature en
  valide 1 à 4 — un surcoût de deux ordres de grandeur. Le module principal
  était passé à 4 mais `d2_compile_pipeline` gardait 128 : deux constantes
  contradictoires pour la même notion.
* L'EMA de stabilité utilisait le switch *désiré* et non le switch *effectif*
  dans `d2_compile_pipeline` (le correctif « FIX-1 » n'avait été appliqué qu'à
  une des deux copies).
* `_batch_best_quant` avait deux branches identiques (`batch <= 1` et
  `2 <= batch <= 7` renvoyaient toutes deux `Q4_K_M`).
* Le README annonçait `SINK_THRESHOLD = 128` alors que le code était à 4.

Usage :
    python d2_dynamic_v13.py --ctx 32768 --gpu rtx4090
    python d2_dynamic_v13.py --ctx 131072 --kv-format Q4_K --budget 24
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Dict, List, Optional

import d2
from d2 import console

__all__ = ["KVPolicy", "SINK_TOKENS", "kv_plan"]

#: Tokens conservés en haute précision (StreamingLLM). La littérature valide
#: 1 à 4 ; toute valeur supérieure est spéculative et coûte proportionnellement.
SINK_TOKENS = 4

#: Formats de cache KV, du plus sûr au plus compact. K est plus sensible que V
#: (KVQuant §4.2) : la politique ci-dessous ne descend K qu'après V.
KV_LADDER = ["F16", "Q8_0", "Q5_K", "Q4_K"]


@dataclass
class KVPolicy:
    """Politique de cache KV pour un contexte donné."""

    ctx_len: int
    k_format: str
    v_format: str
    sink_tokens: int
    bytes_total: float
    fits: bool
    rationale: str

    def to_dict(self) -> Dict:
        d = dict(self.__dict__)
        d["gb_total"] = self.bytes_total / 1e9
        return d


def kv_bytes(n_blocks: int, n_kv_heads: int, head_dim: int, ctx_len: int,
             k_format: str, v_format: str, sink_tokens: int = SINK_TOKENS) -> float:
    """Octets du cache KV avec formats K et V distincts.

    K et V sont comptés séparément : les quantifier au même format, comme le
    faisait le v1, ignore que K supporte beaucoup moins bien la compression.
    """
    from d2 import formats as fmts

    n_sink = min(max(sink_tokens, 0), ctx_len)
    n_quant = max(ctx_len - n_sink, 0)
    per_tok_per_side = n_blocks * n_kv_heads * head_dim
    f16 = fmts.bytes_per_weight("F16")
    k = per_tok_per_side * (n_quant * fmts.bytes_per_weight(k_format) + n_sink * f16)
    v = per_tok_per_side * (n_quant * fmts.bytes_per_weight(v_format) + n_sink * f16)
    return k + v


def kv_plan(n_blocks: int, n_kv_heads: int, head_dim: int, ctx_len: int,
            budget_bytes: float) -> KVPolicy:
    """Choisit les formats K et V les plus sûrs qui tiennent dans le budget.

    Ordre de dégradation : V d'abord (plus tolérant), puis K. C'est la
    conclusion empirique de KVQuant et KIVI, pas un réglage arbitraire.
    """
    candidates: List[tuple] = []
    for ki, kf in enumerate(KV_LADDER):
        for vi, vf in enumerate(KV_LADDER):
            if vi < ki:
                continue  # V jamais plus large que K
            # coût de dégradation : K pèse double
            candidates.append((2 * ki + vi, kf, vf))
    candidates.sort()

    for _, kf, vf in candidates:
        b = kv_bytes(n_blocks, n_kv_heads, head_dim, ctx_len, kf, vf)
        if b <= budget_bytes:
            return KVPolicy(
                ctx_len=ctx_len, k_format=kf, v_format=vf,
                sink_tokens=SINK_TOKENS, bytes_total=b, fits=True,
                rationale=(
                    f"K={kf} V={vf} : configuration la plus sûre tenant dans "
                    f"{budget_bytes / 1e9:.2f} Go. V est dégradé avant K "
                    "(KVQuant, KIVI)."
                ),
            )

    kf, vf = KV_LADDER[-1], KV_LADDER[-1]
    b = kv_bytes(n_blocks, n_kv_heads, head_dim, ctx_len, kf, vf)
    return KVPolicy(
        ctx_len=ctx_len, k_format=kf, v_format=vf, sink_tokens=SINK_TOKENS,
        bytes_total=b, fits=False,
        rationale=(
            f"Même en {kf}/{vf} le cache occupe {b / 1e9:.2f} Go pour un budget "
            f"de {budget_bytes / 1e9:.2f} Go. Réduisez le contexte."
        ),
    )


def main() -> int:
    console.setup()
    p = argparse.ArgumentParser(description="Politique de cache KV D2")
    p.add_argument("--gpu", default="rtx4090")
    p.add_argument("--budget", type=float, default=None,
                   help="VRAM totale en Go (défaut : celle de la cible)")
    p.add_argument("--ctx", type=int, default=32768, help="contexte en tokens")
    p.add_argument("--blocks", type=int, default=32)
    p.add_argument("--kv-heads", type=int, default=8)
    p.add_argument("--head-dim", type=int, default=128)
    p.add_argument("--weights-gb", type=float, default=None,
                   help="taille des poids ; sinon un plan D2 est calculé")
    args = p.parse_args()

    caps = d2.get_profile(args.gpu)
    total = (args.budget or caps.vram_gb) * 1e9

    print("=" * 70)
    print(f"  Politique de cache KV — {caps.name}  {total / 1e9:.0f} Go")
    print(f"  {args.blocks} blocs, {args.kv_heads} tetes KV, "
          f"dim {args.head_dim}, contexte {args.ctx} tokens")
    print("=" * 70)

    if args.weights_gb is not None:
        weights = args.weights_gb * 1e9
    else:
        layers, info = d2.synthetic_model(
            n_blocks=args.blocks, n_kv_heads=args.kv_heads,
            head_dim=args.head_dim, with_weights=False)
        from d2 import formats as fmts
        weights = sum(fmts.format_bytes(l.n_elements, "Q4_K") for l in layers)
        print(f"\n  Poids (Q4_K, modele synthetique) : {weights / 1e9:.2f} Go")

    budget_kv = total * 0.95 - weights
    print(f"  Budget disponible pour le cache  : {budget_kv / 1e9:.2f} Go\n")

    if budget_kv <= 0:
        print("  [!] Les poids saturent deja la VRAM : aucun cache possible.")
        return 1

    pol = kv_plan(args.blocks, args.kv_heads, args.head_dim, args.ctx, budget_kv)
    print(f"  K : {pol.k_format}")
    print(f"  V : {pol.v_format}")
    print(f"  Tokens 'sink' en F16 : {pol.sink_tokens} (StreamingLLM, ICLR 2024)")
    print(f"  Cache KV : {pol.bytes_total / 1e9:.3f} Go  "
          f"-> {'tient' if pol.fits else 'DEPASSE'}")
    print(f"\n  {pol.rationale}")

    print("\n  Comparaison des configurations :")
    print(f"  {'K':<7} {'V':<7} {'Go':>9}  {'vs F16/F16':>11}")
    print("  " + "-" * 38)
    ref = kv_bytes(args.blocks, args.kv_heads, args.head_dim, args.ctx, "F16", "F16")
    for kf in KV_LADDER:
        for vf in KV_LADDER:
            if KV_LADDER.index(vf) < KV_LADDER.index(kf):
                continue
            b = kv_bytes(args.blocks, args.kv_heads, args.head_dim, args.ctx, kf, vf)
            mark = " <-" if (kf, vf) == (pol.k_format, pol.v_format) else ""
            print(f"  {kf:<7} {vf:<7} {b / 1e9:>9.3f}  {b / ref * 100:>10.1f}%{mark}")

    print(f"\n  Option llama.cpp : --type-k {pol.k_format.lower()} "
          f"--type-v {pol.v_format.lower()} --ctx-size {args.ctx}")
    print("  (llama.cpp accepte f16, q8_0, q5_1, q5_0, q4_1, q4_0 pour le cache ;")
    print("   verifiez la liste de votre version avec `llama-server --help`.)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
