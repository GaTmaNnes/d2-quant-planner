$env:TMP = "D:\Temp"
$env:TEMP = "D:\Temp"
py optimize_for_gtx1080.py "C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"