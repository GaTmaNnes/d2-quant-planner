#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v18 - remplace par le package `d2`
==================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
* **Le fichier ne s'executait pas.** Sa premiere ligne etait
  `i #!/usr/bin/env python3` : le `i` parasite est syntaxiquement une
  expression valide, donc l'analyse syntaxique passait, mais l'import levait
  `NameError: name 'i' is not defined`.
* L'objectif ILP etait degenere :
  `tps = TPS_GAIN[q] * size * 1e-12` valait ~1.6e-05 tandis que
  `risk = RISK[q] * log1p(size)` valait ~3.3. Le terme de vitesse etait cinq
  ordres de grandeur trop petit : le solveur choisissait FP16 partout, quel
  que soit le budget.
* `roofline_cycles`, `vram_cost`, `FLOPS` et `L2` etaient definis et jamais
  utilises.
* Le `__main__` iterait sur le retour de `solve_quantization` sans verifier le
  `None` renvoye en cas d'echec.

Correspondance
--------------
* ``solve_quantization`` -> ``d2.plan_layers``
* ``export_gguf`` -> ``d2.export_llama_cpp``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'v18'

_MOVED = {'solve_quantization': 'd2.plan_layers', 'export_gguf': 'd2.export_llama_cpp'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
