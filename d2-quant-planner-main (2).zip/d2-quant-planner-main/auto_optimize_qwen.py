#!/usr/bin/env python3
"""
Auto-optimization pipeline pour Qwen3.5-9B
==========================================

Automatise complètement:
1. Profiling des layers
2. Génération des plans
3. Exécution llama-quantize
4. Benchmark
5. Rapport final
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime
import logging
import time
import shutil

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
MODEL_PATH = r"C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"
OUTPUT_DIR = Path("qwen_optimized")
QUANTIZE_STRATEGIES = [
    {
        'name': 'conservative',
        'budget': '8GB',
        'attention': 'q4_k',
        'mlp': 'q4_k',
        'embedding': 'q5_k',
        'base_fmt': 'Q4_K_M',
        'priority': 1,  # Run first
    },
    {
        'name': 'balanced',
        'budget': '12GB',
        'attention': 'q5_k',
        'mlp': 'q4_k',
        'embedding': 'f16',
        'base_fmt': 'Q4_K_M',
        'priority': 1,  # Run first
    },
    {
        'name': 'quality',
        'budget': '16GB',
        'attention': 'q6_k',
        'mlp': 'q5_k',
        'embedding': 'f16',
        'base_fmt': 'Q5_K_M',
        'priority': 2,  # Run second
    },
    {
        'name': 'maximum',
        'budget': '24GB',
        'attention': 'f16',
        'mlp': 'q6_k',
        'embedding': 'f16',
        'base_fmt': 'Q6_K',
        'priority': 3,  # Run last
    },
]

class AutoOptimizer:
    def __init__(self):
        self.model_path = Path(MODEL_PATH)
        self.output_dir = OUTPUT_DIR
        self.output_dir.mkdir(exist_ok=True)
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'model': str(self.model_path),
            'strategies': {}
        }

        if not self.model_path.exists():
            logger.error(f"❌ Model not found: {self.model_path}")
            sys.exit(1)

    def check_dependencies(self):
        """Vérifier que les outils sont disponibles"""
        logger.info("🔍 Vérification des dépendances...")

        required_tools = {
            'llama-quantize': 'Quantization tool from llama.cpp',
            'llama-cli': 'Inference CLI from llama.cpp',
            'llama-perplexity': 'Perplexity measurement tool',
        }

        missing = []
        for tool, desc in required_tools.items():
            result = subprocess.run(
                f"{tool} --version",
                shell=True,
                capture_output=True,
                timeout=5
            )
            if result.returncode != 0:
                missing.append(tool)
                logger.warning(f"  ⚠️  {tool} not found ({desc})")
            else:
                logger.info(f"  ✓ {tool}")

        if missing:
            logger.error(f"\n❌ Missing tools: {', '.join(missing)}")
            logger.error("Install from: https://github.com/ggerganov/llama.cpp/releases")
            return False

        logger.info("✅ All dependencies available\n")
        return True

    def profile_model(self):
        """Profiler le modèle"""
        logger.info("="*70)
        logger.info("PHASE 1: PROFILING DU MODÈLE")
        logger.info("="*70)

        try:
            import d2

            logger.info(f"Chargement: {self.model_path.name}")
            layers, info = d2.load_gguf(str(self.model_path), dequantize=False)

            logger.info(f"✓ {len(layers)} tensors loaded")
            logger.info(f"  Architecture: {info.get('arch')}")
            logger.info(f"  Blocks: {info.get('n_blocks')}")

            self.results['model_info'] = {
                'n_tensors': len(layers),
                'arch': info.get('arch'),
                'n_blocks': info.get('n_blocks'),
                'n_kv_heads': info.get('n_kv_heads'),
            }

            return layers, info
        except Exception as e:
            logger.error(f"❌ Profiling error: {e}")
            return None, None

    def quantize_strategy(self, strategy):
        """Quantifier selon une stratégie"""
        name = strategy['name']
        budget = strategy['budget']

        logger.info(f"\n{'─'*70}")
        logger.info(f"🎯 {name.upper()} ({budget})")
        logger.info(f"{'─'*70}")

        output_name = f"qwen-{name}-{budget.replace('GB', 'gb')}.gguf"
        output_path = self.output_dir / output_name

        # Construire la commande llama-quantize
        cmd = [
            'llama-quantize',
            '--tensor-type', f"attention={strategy['attention']}",
            '--tensor-type', f"mlp={strategy['mlp']}",
            '--tensor-type', f"embedding={strategy['embedding']}",
            str(self.model_path),
            str(output_path),
            strategy['base_fmt'],
        ]

        logger.info(f"Quantization en cours...")
        logger.info(f"  Attention: {strategy['attention']}")
        logger.info(f"  MLP: {strategy['mlp']}")
        logger.info(f"  Embedding: {strategy['embedding']}")
        logger.info(f"  Output: {output_name}")

        try:
            start = time.time()
            result = subprocess.run(
                ' '.join(cmd),
                shell=True,
                capture_output=True,
                timeout=3600,  # 1 hour timeout
                text=True
            )
            elapsed = time.time() - start

            if result.returncode != 0:
                logger.error(f"❌ Quantization failed")
                logger.error(result.stderr)
                return None

            # Vérifier que le fichier a été créé
            if not output_path.exists():
                logger.error(f"❌ Output file not found: {output_path}")
                return None

            file_size_gb = output_path.stat().st_size / 1e9
            logger.info(f"✅ Quantization complete!")
            logger.info(f"  Size: {file_size_gb:.2f} GB")
            logger.info(f"  Time: {elapsed:.1f}s")

            return {
                'path': str(output_path),
                'size_gb': file_size_gb,
                'time_seconds': elapsed,
            }

        except subprocess.TimeoutExpired:
            logger.error(f"❌ Quantization timeout (>1h)")
            return None
        except Exception as e:
            logger.error(f"❌ Error: {e}")
            return None

    def benchmark_gguf(self, gguf_path, strategy_name):
        """Benchmarker un GGUF"""
        logger.info(f"  Benchmarking...")

        try:
            # Test d'inférence simple
            cmd = [
                'llama-cli',
                '-m', str(gguf_path),
                '-n', '128',  # 128 tokens
                '-p', 'The quick brown fox jumps over',
                '-ngl', '33',  # GPU layers
                '--timing',
            ]

            start = time.time()
            result = subprocess.run(
                ' '.join(cmd),
                shell=True,
                capture_output=True,
                timeout=120,
                text=True
            )
            elapsed = time.time() - start

            if result.returncode == 0:
                # Parse timing info from output
                output = result.stdout + result.stderr

                # Simple estimation: 128 tokens / elapsed time
                est_tps = 128 / elapsed if elapsed > 0 else 0

                logger.info(f"  ✓ Benchmark: ~{est_tps:.1f} tokens/sec")

                return {
                    'test_tokens': 128,
                    'elapsed_seconds': elapsed,
                    'estimated_tps': est_tps,
                }
            else:
                logger.warning(f"  ⚠️  Benchmark failed")
                return None

        except subprocess.TimeoutExpired:
            logger.warning(f"  ⚠️  Benchmark timeout")
            return None
        except Exception as e:
            logger.warning(f"  ⚠️  Benchmark error: {e}")
            return None

    def run_all_strategies(self):
        """Exécuter toutes les stratégies"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 2: QUANTIZATION DE TOUTES LES STRATÉGIES")
        logger.info("="*70)

        # Trier par priorité
        sorted_strategies = sorted(QUANTIZE_STRATEGIES, key=lambda x: x['priority'])

        for strategy in sorted_strategies:
            name = strategy['name']

            # Quantifier
            quant_result = self.quantize_strategy(strategy)
            if not quant_result:
                logger.warning(f"❌ {name.upper()} quantization failed, skipping...")
                continue

            # Benchmarker
            bench_result = self.benchmark_gguf(quant_result['path'], name)

            # Sauvegarder les résultats
            self.results['strategies'][name] = {
                'strategy': strategy,
                'quantization': quant_result,
                'benchmark': bench_result,
            }

            logger.info(f"✅ {name.upper()} complete\n")

    def generate_report(self):
        """Générer un rapport final"""
        logger.info("="*70)
        logger.info("PHASE 3: RAPPORT FINAL")
        logger.info("="*70)

        lines = []
        lines.append("="*80)
        lines.append("QWEN3.5-9B AUTO-OPTIMIZATION REPORT")
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("="*80)
        lines.append("")

        lines.append("QUANTIZATION RESULTS:")
        lines.append("")

        # Tableau des résultats
        lines.append(f"{'Strategy':<15} {'Size':<10} {'Time':<10} {'Est. TPS':<12} {'Status':<10}")
        lines.append(f"{'-'*15} {'-'*10} {'-'*10} {'-'*12} {'-'*10}")

        for name, data in sorted(self.results['strategies'].items()):
            q_data = data.get('quantization', {})
            b_data = data.get('benchmark', {})

            size = f"{q_data.get('size_gb', 0):.2f} GB"
            time_s = f"{q_data.get('time_seconds', 0):.0f}s"
            tps = f"{b_data.get('estimated_tps', 0):.1f}" if b_data else "N/A"
            status = "✅" if q_data else "❌"

            lines.append(f"{name:<15} {size:<10} {time_s:<10} {tps:<12} {status:<10}")

        lines.append("")
        lines.append("GENERATED FILES:")
        for gguf_file in self.output_dir.glob("qwen-*.gguf"):
            size_gb = gguf_file.stat().st_size / 1e9
            lines.append(f"  {gguf_file.name:<40} {size_gb:.2f} GB")

        lines.append("")
        lines.append("RECOMMENDATIONS:")
        lines.append("  1. Use 'balanced' for general purpose (best quality/speed)")
        lines.append("  2. Use 'conservative' for minimal RAM usage")
        lines.append("  3. Use 'quality' for maximum fidelity")
        lines.append("")

        lines.append("USAGE EXAMPLES:")
        lines.append("")
        lines.append("  Inference with GPU acceleration:")
        lines.append("    llama-cli -m qwen-balanced-12gb.gguf -ngl 33 -p 'Your prompt'")
        lines.append("")
        lines.append("  Batch processing:")
        lines.append("    llama-cli -m qwen-balanced-12gb.gguf -n 512 -f input.txt")
        lines.append("")

        lines.append("="*80)

        # Sauvegarder le rapport
        report_path = self.output_dir / "AUTO_OPTIMIZATION_REPORT.txt"
        report_path.write_text("\n".join(lines), encoding='utf-8')

        logger.info(f"✅ Report saved: {report_path}")
        logger.info("")

        # Afficher le rapport
        for line in lines:
            logger.info(line)

        # Sauvegarder JSON
        json_path = self.output_dir / "optimization_results.json"
        with open(json_path, 'w') as f:
            json.dump(self.results, f, indent=2)
        logger.info(f"✅ Results saved: {json_path}")

    def run(self):
        """Exécuter le pipeline complet"""
        logger.info("\n" + "█"*70)
        logger.info("AUTO-OPTIMIZATION PIPELINE POUR QWEN3.5-9B")
        logger.info("█"*70 + "\n")

        # Vérifier les dépendances
        if not self.check_dependencies():
            return False

        # Profiler
        layers, info = self.profile_model()
        if not layers:
            return False

        # Quantifier toutes les stratégies
        self.run_all_strategies()

        # Générer le rapport
        self.generate_report()

        logger.info("\n" + "█"*70)
        logger.info("✅ PIPELINE COMPLET!")
        logger.info(f"Output: {self.output_dir}")
        logger.info("█"*70 + "\n")

        return True


if __name__ == "__main__":
    optimizer = AutoOptimizer()
    success = optimizer.run()
    sys.exit(0 if success else 1)
