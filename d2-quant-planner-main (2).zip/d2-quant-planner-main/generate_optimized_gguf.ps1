# Generate optimized GGUF files for Qwen3.5-9B
# Using llama-quantize with recommended settings

$ModelInput = "C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"
$OutputDir = "C:\Users\videl\Documents\d2-quant-planner-main\qwen_optimized"

Write-Host "=================================="
Write-Host "Qwen3.5-9B GGUF Optimization"
Write-Host "=================================="
Write-Host ""

# Check if llama-quantize is available
$llama = Get-Command llama-quantize -ErrorAction SilentlyContinue
if (-not $llama) {
    Write-Host "❌ llama-quantize not found!"
    Write-Host "Install from: https://github.com/ggerganov/llama.cpp"
    exit 1
}

Write-Host "✓ llama-quantize found: $($llama.Source)"
Write-Host ""

# Strategy 1: Conservative (8GB, maximum compression)
Write-Host "[1/4] CONSERVATIVE (8GB, max compression)..."
$cmd1 = @(
    "llama-quantize",
    '--tensor-type', "attention=q4_k",
    '--tensor-type', "mlp=q4_k",
    '--tensor-type', "embedding=q5_k",
    "`"$ModelInput`"",
    "`"$OutputDir\qwen-conservative-8gb.gguf`"",
    "Q4_K_M"
) -join " "
Write-Host "Command: $cmd1"
Write-Host ""

# Strategy 2: Balanced (12GB, recommended)
Write-Host "[2/4] BALANCED (12GB, recommended)..."
Write-Host "Command:"
Write-Host "  llama-quantize --tensor-type attention=q5_k --tensor-type mlp=q4_k --tensor-type embedding=f16 model.gguf output.gguf Q4_K_M"
Write-Host ""

# Strategy 3: Quality (16GB, quality focus)
Write-Host "[3/4] QUALITY (16GB, quality focus)..."
Write-Host "Command:"
Write-Host "  llama-quantize --tensor-type attention=q6_k --tensor-type mlp=q5_k --tensor-type embedding=f16 model.gguf output.gguf Q5_K_M"
Write-Host ""

# Strategy 4: Maximum (24GB, best quality)
Write-Host "[4/4] MAXIMUM (24GB, best quality)..."
Write-Host "Command:"
Write-Host "  llama-quantize --tensor-type attention=f16 --tensor-type mlp=q6_k --tensor-type embedding=f16 model.gguf output.gguf Q6_K"
Write-Host ""

Write-Host "=================================="
Write-Host ""
Write-Host "📋 MANUAL QUANTIZATION COMMANDS"
Write-Host ""
Write-Host "Run these commands one by one:"
Write-Host ""

$commands = @(
    @{
        name = "Conservative"
        budget = "8GB"
        cmd = 'llama-quantize --tensor-type attention=q4_k --tensor-type mlp=q4_k --tensor-type embedding=q5_k model.gguf qwen-conservative-8gb.gguf Q4_K_M'
    },
    @{
        name = "Balanced"
        budget = "12GB (recommended)"
        cmd = 'llama-quantize --tensor-type attention=q5_k --tensor-type mlp=q4_k --tensor-type embedding=f16 model.gguf qwen-balanced-12gb.gguf Q4_K_M'
    },
    @{
        name = "Quality"
        budget = "16GB"
        cmd = 'llama-quantize --tensor-type attention=q6_k --tensor-type mlp=q5_k --tensor-type embedding=f16 model.gguf qwen-quality-16gb.gguf Q5_K_M'
    },
    @{
        name = "Maximum"
        budget = "24GB"
        cmd = 'llama-quantize --tensor-type attention=f16 --tensor-type mlp=q6_k --tensor-type embedding=f16 model.gguf qwen-maximum-24gb.gguf Q6_K'
    }
)

foreach ($strategy in $commands) {
    Write-Host "$($strategy.name) ($($strategy.budget)):"
    Write-Host "  $($strategy.cmd)"
    Write-Host ""
}

Write-Host "=================================="
Write-Host "Notes:"
Write-Host "  • Run commands from: $OutputDir"
Write-Host "  • Replace 'model.gguf' with full path to input GGUF"
Write-Host "  • Each quantization takes 5-15 minutes"
Write-Host "  • Benchmark with: llama-perplexity -m output.gguf -f calibration.txt"
Write-Host "=================================="
