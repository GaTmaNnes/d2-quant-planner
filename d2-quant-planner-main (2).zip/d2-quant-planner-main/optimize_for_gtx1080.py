#!/usr/bin/env python3
"""
Script d'optimisation spécifique pour GTX 1080 (Pascal sm_61).
Force l'utilisation de l'INT8 pour exploiter les instructions DP4A.
"""
import subprocess
import sys
import os

def optimize_model(model_path):
    if not os.path.exists(model_path):
        print(f"Erreur: Modèle non trouvé: {model_path}")
        return

    # Configuration des flags pour forcer l'INT8 et cibler la 1080
    cmd = [
        sys.executable, "d2_rtx_gguf_profiler.py",
        model_path,
        "--gpu-target", "gtx1080",
        "--formats", "INT8",
        "--solver", "scipy",
        "--target", "tensorrt", # TensorRT est le meilleur moteur pour INT8/Pascal
        "--out", "pascal_quant_plan.json"
    ]

    print(f"Lancement de l'optimisation Pascal pour: {model_path}")
    print("Forçage du format: INT8 (DP4A)")
    
    try:
        subprocess.run(cmd, check=True)
        print("\nOptimisation terminée.")
        print("Plan généré : pascal_quant_plan.json")
        print("Utilisez ce plan avec TensorRT-LLM pour la calibration INT8.")
    except subprocess.CalledProcessError as e:
        print(f"Erreur lors de l'exécution : {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python optimize_for_gtx1080.py <chemin_vers_gguf>")
    else:
        optimize_model(sys.argv[1])
