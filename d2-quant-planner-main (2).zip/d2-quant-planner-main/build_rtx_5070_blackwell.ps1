# Build TensorRT-LLM pour RTX 5070 (Blackwell, sm_120)
# =====================================================
#
# Reecrit : la version precedente utilisait des options qui n'existent pas.
#
#   --per_layer_precision   n'est pas une option de trtllm-build. La
#                           quantification par couche se declare dans le
#                           quant_config du checkpoint (quantize.py / modelopt).
#   --max_output_len        remplace par --max_seq_len.
#   --quantization nvfp4    trtllm-build ne prend pas d'option --quantization ;
#                           l'algorithme vient du checkpoint quantifie.
#   --use_gpt_attention_plugin / --use_gemm_plugin
#                           remplaces par --gemm_plugin (le plugin d'attention
#                           est active par defaut).
#
# Le fichier portait par ailleurs un encodage cp1252 mal interprete
# ("optimis?", "s?res"). Celui-ci est en UTF-8.
#
# La RTX 5070 est sm_120, pas "sn120" comme l'indiquait le nom du dossier de
# sortie, ni sm_100 comme l'affirmait RAPPORT_FINAL_OPTIMISATION.md (sm_100
# correspond au B200, Blackwell datacenter).

$ErrorActionPreference = "Stop"

$Model      = "qwen-f16.gguf"       # GGUF source, pour le plan D2
$HfModel    = "./hf_model"          # source HuggingFace, pour quantize.py
$Budget     = 12                    # Go de VRAM
$Ctx        = 32768                 # tokens
$Checkpoint = "./trt_checkpoint"
$Engine     = "./engine_blackwell_sm120"

Write-Host "=== Etape 1/3 : plan D2 ===" -ForegroundColor Cyan

# Une imatrix ameliore nettement le plan : elle fait reposer la decision sur
# des statistiques d'activation mesurees plutot que sur des a priori de couche.
$imatrixArg = @()
if (Test-Path "model.imatrix") {
    $imatrixArg = @("--imatrix", "model.imatrix")
} else {
    Write-Host "  Astuce : generez d'abord une imatrix" -ForegroundColor Yellow
    Write-Host "    llama-imatrix -m $Model -f calibration.txt -o model.imatrix"
}

python d2_rtx_gguf_profiler.py $Model `
    --gpu-target rtx5070 `
    --budget $Budget `
    --ctx $Ctx `
    --target tensorrt `
    --tensorrt-out tensorrt_plan.json `
    @imatrixArg

if ($LASTEXITCODE -ne 0) { throw "Le plan D2 a echoue (code $LASTEXITCODE)" }

Write-Host "`n=== Etape 2/3 : checkpoint quantifie ===" -ForegroundColor Cyan
Write-Host "  Le quant_config et la liste d'exclusions sont dans tensorrt_plan.json."
Write-Host "  Les reporter dans l'appel a quantize.py de TensorRT-LLM :"
Write-Host ""
Write-Host "    python TensorRT-LLM/examples/quantization/quantize.py ``"
Write-Host "        --model_dir $HfModel ``"
Write-Host "        --dtype float16 ``"
Write-Host "        --qformat nvfp4 ``"
Write-Host "        --output_dir $Checkpoint ``"
Write-Host "        --calib_size 512"
Write-Host ""
Write-Host "  NVFP4 exige sm_100 ou sm_120. Sur une cible anterieure, utilisez"
Write-Host "  --qformat int4_awq (Ada, Ampere) ou int8_sq."
Write-Host ""

if (-not (Test-Path $Checkpoint)) {
    Write-Host "  $Checkpoint absent : arret avant la construction." -ForegroundColor Yellow
    Write-Host "  Executez quantize.py ci-dessus, puis relancez ce script."
    exit 0
}

Write-Host "=== Etape 3/3 : construction du moteur ===" -ForegroundColor Cyan

trtllm-build `
    --checkpoint_dir $Checkpoint `
    --output_dir $Engine `
    --gemm_plugin auto `
    --max_batch_size 4 `
    --max_input_len 4096 `
    --max_seq_len $Ctx

if ($LASTEXITCODE -ne 0) { throw "trtllm-build a echoue (code $LASTEXITCODE)" }

Write-Host "`nMoteur construit dans $Engine" -ForegroundColor Green
Write-Host "Verifiez la qualite avant mise en service :" -ForegroundColor Yellow
Write-Host "  python TensorRT-LLM/examples/summarize.py --engine_dir $Engine --test_trt_llm"
