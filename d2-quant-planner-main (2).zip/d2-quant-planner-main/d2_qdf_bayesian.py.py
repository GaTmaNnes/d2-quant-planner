#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_qdf_bayesian - remplace par le package `d2`
==============================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
Ce fichier portait une double extension `.py.py` et ne pouvait pas s'executer :

* `_, S, _ = svd(W, full_matrices=False, compute_uv=False)` - avec
  `compute_uv=False`, scipy ne renvoie qu'un tableau 1-D ; le depaquetage en
  trois leve `ValueError`.
* Chemins codes en dur `/home/workdir/attachments/...`, propres au bac a sable
  d'origine.
* **`build_nodes` analysait `np.random.randn(*node.shape)`**, c'est-a-dire du
  bruit gaussien, pas les poids du modele. Les `bayesian_coherence` et
  `C_global` ecrits dans le plan etaient des statistiques de matrices
  aleatoires.
* `bayesian_coherence` appliquait `-sum(p*log p)` a `p = sigmoid(moyenne)`, qui
  n'est pas une distribution de probabilite : la « coherence bayesienne » ne
  correspondait a aucune quantite definie.

Correspondance
--------------
* ``QDFV5Engine.analyze_layer`` -> ``d2.spectral.analyze``
* ``D2Compiler.generate_unified_plan`` -> ``d2.plan_layers``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'd2_qdf_bayesian.py'

_MOVED = {'QDFV5Engine.analyze_layer': 'd2.spectral.analyze', 'D2Compiler.generate_unified_plan': 'd2.plan_layers'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
