#!/usr/bin/env python3
"""
D2 — Interface web Gradio
=========================

Corrections par rapport au v1 :

* `demo.launch(share=True)` ouvrait un **tunnel public** à chaque démarrage,
  exposant l'interface et le système de fichiers accessible depuis les champs
  de saisie. Le partage est désormais opt-in (`--share`).
* Le chargement d'un modèle rattrapait toute exception et renvoyait
  silencieusement 8 couches d'exemple : l'utilisateur croyait analyser son
  modèle. Les erreurs sont maintenant affichées.
* Les tenseurs de rang > 2 étaient repliés en `[shape[0], -1]`, d'où une
  dimension négative et une VRAM négative.
* `NamedTemporaryFile(delete=False)` laissait un fichier par clic.
* `summarize(plan, budget, 1.0, w_risk)` faisait atterrir `w_risk` dans
  `w_speed` : le résumé affichait toujours `lam=1.00`.

Lancement :
    python app.py                 # local uniquement
    python app.py --share         # tunnel public Gradio (à vos risques)
    python app.py --port 7861
"""

from __future__ import annotations

import argparse
import html
import os
import tempfile
from typing import List, Optional, Tuple

import gradio as gr

import d2
from d2 import console

console.setup()

# Répertoire de travail unique pour la session, nettoyé à la sortie.
_WORKDIR = tempfile.TemporaryDirectory(prefix="d2_gradio_")

DTYPE_COLORS = {
    "F16": "#4682B4", "BF16": "#5F9EA0", "Q8_0": "#3CB371", "INT8": "#2E8B57",
    "Q6_K": "#9ACD32", "Q5_K": "#DAA520", "Q4_K": "#FF8C00",
    "INT4_AWQ": "#FF7F50", "NVFP4": "#DC143C", "Q3_K": "#B22222",
    "Q2_K": "#8B0000",
}


def _load_layers(source: str, custom_json: str):
    """Charge les couches. Retourne (layers, info, message d'erreur ou None)."""
    if custom_json and custom_json.strip():
        import json

        try:
            raw = json.loads(custom_json)
        except json.JSONDecodeError as exc:
            return None, None, f"JSON invalide : {exc}"
        try:
            specs = [
                d2.LayerSpec(name=e["name"], shape=[int(v) for v in e["shape"]])
                for e in raw
            ]
        except (KeyError, TypeError, ValueError) as exc:
            return None, None, (
                "Chaque entrée doit être {\"name\": str, \"shape\": [m, n]} — " f"{exc}"
            )
        return specs, {"source": "custom"}, None

    src = (source or "").strip()
    if not src:
        return None, None, "Renseignez un modèle ou des couches personnalisées."

    try:
        if src.lower().endswith(".gguf"):
            return (*d2.load_gguf(src), None)
        if os.path.isfile(src):
            return (*d2.load_safetensors(src), None)
        return (*d2.load_huggingface(src), None)
    except Exception as exc:
        # Erreur remontée telle quelle : pas de repli silencieux sur un exemple.
        return None, None, f"{type(exc).__name__} : {exc}"


def _table_html(plan: d2.Plan, limit: int = 300) -> str:
    head = (
        '<table style="width:100%;border-collapse:collapse;font-size:13px">'
        '<thead style="background:#f0f0f0"><tr>'
        + "".join(
            f'<th style="border:1px solid #ddd;padding:6px;text-align:left">{h}</th>'
            for h in ("Tenseur", "Classe", "Format", "Taille (Go)",
                      "Erreur rel.", "Coût Ω")
        )
        + "</tr></thead><tbody>"
    )
    rows = []
    for e in plan.entries[:limit]:
        color = DTYPE_COLORS.get(e.format, "#777")
        err = f"{e.rel_error:.4f}" if e.rel_error == e.rel_error else "~n/a"
        mark = " *" if e.forced else ("" if e.measured else " ~")
        rows.append(
            "<tr>"
            f'<td style="border:1px solid #ddd;padding:6px">{html.escape(e.name)}{mark}</td>'
            f'<td style="border:1px solid #ddd;padding:6px;text-align:center">{e.cls}</td>'
            f'<td style="border:1px solid #ddd;padding:6px;text-align:center;'
            f'background:{color};color:#fff;font-weight:bold">{e.format}</td>'
            f'<td style="border:1px solid #ddd;padding:6px;text-align:right">{e.bytes / 1e9:.5f}</td>'
            f'<td style="border:1px solid #ddd;padding:6px;text-align:right">{err}</td>'
            f'<td style="border:1px solid #ddd;padding:6px;text-align:right">{e.omega:.3e}</td>'
            "</tr>"
        )
    tail = "</tbody></table>"
    if len(plan.entries) > limit:
        tail += f"<p><em>… {len(plan.entries) - limit} couches supplémentaires</em></p>"
    tail += "<p><small>* couche contrainte en haute précision — ~ estimé, non mesuré</small></p>"
    return head + "".join(rows) + tail


def run_planner(
    source: str,
    gpu_target: str,
    vram_budget: float,
    ctx_len: int,
    max_rel_error: float,
    custom_json: str,
) -> Tuple[str, str, str, str]:
    """Callback principal. Retourne (table, résumé, commande, statut)."""
    layers, info, err = _load_layers(source, custom_json)
    if err:
        return "", "", "", f"Échec du chargement — {err}"
    if not layers:
        return "", "", "", "Aucune couche exploitable trouvée."

    try:
        caps = d2.get_profile(gpu_target)
    except KeyError as exc:
        return "", "", "", str(exc)

    measure = any(l.weights is not None for l in layers)
    try:
        plan = d2.plan_layers(
            layers,
            caps,
            vram_budget_gb=float(vram_budget),
            ctx_len=int(ctx_len),
            measure=measure,
            max_rel_error=(float(max_rel_error) if max_rel_error > 0 and measure
                           else None),
            **d2.kv_geometry(info or {}),
        )
    except d2.InfeasibleBudget as exc:
        return "", "", "", f"Budget intenable — {exc}"
    except Exception as exc:
        return "", "", "", f"{type(exc).__name__} : {exc}"

    json_path = os.path.join(_WORKDIR.name, "plan.json")
    payload = d2.export_llama_cpp(plan, json_path=json_path)

    status = [
        f"Plan calculé — solveur {plan.solver}"
        + (" (optimum prouvé)" if plan.optimal else " (admissible)"),
        f"{len(plan.entries)} couches, "
        f"{plan.total_bytes / 1e9:.3f} / {plan.budget.weights / 1e9:.3f} Go de budget poids",
    ]
    if not measure:
        status.append(
            "Poids non chargés : l'erreur est estimée analytiquement, pas mesurée."
        )
    status += [f"- {n}" for n in plan.notes]
    if payload["unmapped"]:
        status.append(
            f"{len(payload['unmapped'])} tenseurs sans correspondance GGUF "
            "(non couverts par la commande)."
        )

    return (
        _table_html(plan),
        d2.summarize(plan, caps, ctx_len=int(ctx_len)),
        payload["command"],
        "\n".join(status),
    )


def build_ui() -> gr.Blocks:
    with gr.Blocks(title="D2 — Planificateur de quantification",
                   theme=gr.themes.Soft()) as demo:
        gr.Markdown(
            "# D2 — Planificateur de quantification\n"
            "Allocation de précision par couche sous contrainte VRAM. "
            "Le coût qualité est **mesuré** (erreur de quantification réelle), "
            "pas estimé par un score spectral."
        )
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("## Configuration")
                source = gr.Textbox(
                    value="gpt2",
                    label="Modèle",
                    placeholder="gpt2 | org/modele | /chemin/model.safetensors | /chemin/model.gguf",
                )
                gpu_target = gr.Dropdown(
                    choices=sorted(d2.GPU_PROFILES),
                    value="rtx4090",
                    label="Cible GPU",
                )
                vram_budget = gr.Slider(
                    0.5, 192, value=8.0, step=0.5, label="Budget VRAM (Go)",
                    info="Total, cache KV et marge inclus",
                )
                ctx_len = gr.Slider(
                    512, 131072, value=4096, step=512, label="Contexte (tokens)",
                    info="Dimensionne le cache KV, soustrait du budget",
                )
                max_rel_error = gr.Slider(
                    0.0, 0.30, value=0.0, step=0.005,
                    label="Plafond d'erreur par couche (0 = désactivé)",
                    info="Aucune couche ne dépassera cette erreur relative",
                )
                with gr.Accordion("Couches personnalisées (avancé)", open=False):
                    custom_json = gr.Textbox(
                        label="JSON",
                        placeholder='[{"name": "blk.0.attn_q.weight", "shape": [4096, 4096]}]',
                        lines=4,
                        info="Sans poids : l'erreur sera estimée, pas mesurée.",
                    )
                solve_btn = gr.Button("Générer le plan", variant="primary")

            with gr.Column(scale=1):
                gr.Markdown("## Résultat")
                status_out = gr.Textbox(label="Statut", lines=6, interactive=False)
                summary_out = gr.Textbox(label="Résumé", lines=20,
                                         interactive=False, show_copy_button=True)

        gr.Markdown("## Plan par couche")
        table_out = gr.HTML()

        gr.Markdown(
            "## Commande llama.cpp\n"
            "`--tensor-type` s'applique à la **conversion** (`llama-quantize`). "
            "Ne pas confondre avec `--override-tensor` de `llama-cli`, qui gère "
            "le placement mémoire et ne quantifie rien."
        )
        export_out = gr.Textbox(label="llama-quantize", lines=8,
                                interactive=False, show_copy_button=True)

        solve_btn.click(
            run_planner,
            inputs=[source, gpu_target, vram_budget, ctx_len, max_rel_error,
                    custom_json],
            outputs=[table_out, summary_out, export_out, status_out],
        )
    return demo


def main() -> None:
    parser = argparse.ArgumentParser(description="Interface web D2")
    parser.add_argument("--share", action="store_true",
                        help="crée un tunnel public Gradio (désactivé par défaut)")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--host", default="127.0.0.1",
                        help="127.0.0.1 par défaut ; 0.0.0.0 pour exposer sur le réseau")
    args = parser.parse_args()

    if args.share:
        print("  [!] --share crée une URL publique temporaire. "
              "Toute personne disposant du lien peut lancer des chargements "
              "de modèles depuis cette machine.")
    build_ui().launch(share=args.share, server_port=args.port,
                      server_name=args.host)


if __name__ == "__main__":
    main()
