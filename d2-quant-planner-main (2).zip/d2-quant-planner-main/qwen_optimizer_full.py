#!/usr/bin/env python3
"""
Qwen3.5-9B Optimizer - Full Desktop Application
================================================

Complete optimization suite with:
✅ Per-layer profiling
✅ Advanced strategy selection
✅ Real-time progress
✅ Interactive model launching
✅ Automatic llama.cpp download
"""

import sys
import json
import subprocess
import threading
from pathlib import Path
from datetime import datetime
import logging

try:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QComboBox, QProgressBar, QTextEdit,
        QGroupBox, QTabWidget, QFileDialog, QMessageBox, QSpinBox,
        QTableWidget, QTableWidgetItem, QHeaderView, QDialog,
        QCheckBox, QGridLayout, QSplitter, QListWidget, QListWidgetItem
    )
    from PySide6.QtCore import Qt, QThread, Signal, QTimer
    from PySide6.QtGui import QFont, QColor, QIcon, QPixmap
except ImportError:
    print("📦 Installing PySide6...")
    subprocess.run([sys.executable, "-m", "pip", "install", "PySide6", "-q"])
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QComboBox, QProgressBar, QTextEdit,
        QGroupBox, QTabWidget, QFileDialog, QMessageBox, QSpinBox,
        QTableWidget, QTableWidgetItem, QHeaderView, QDialog,
        QCheckBox, QGridLayout, QSplitter, QListWidget, QListWidgetItem
    )
    from PySide6.QtCore import Qt, QThread, Signal, QTimer
    from PySide6.QtGui import QFont, QColor, QIcon, QPixmap

# ═══════════════════════════════════════════════════════════════════════════════

STRATEGIES = [
    {
        'name': 'Conservative',
        'budget': '8GB',
        'attention': 'q4_k',
        'mlp': 'q4_k',
        'embedding': 'q5_k',
        'normalization': 'q5_k',
        'lm_head': 'f16',
        'other': 'q4_k',
        'base_fmt': 'Q4_K_M',
        'desc': '⬇️ Maximum compression, minimum RAM',
        'est_tps': '6.0',
    },
    {
        'name': 'Balanced',
        'budget': '12GB',
        'attention': 'q5_k',
        'mlp': 'q4_k',
        'embedding': 'f16',
        'normalization': 'f16',
        'lm_head': 'f16',
        'other': 'q4_k',
        'base_fmt': 'Q4_K_M',
        'desc': '⭐ RECOMMENDED - Great quality/speed balance',
        'est_tps': '7.0',
        'recommended': True,
    },
    {
        'name': 'Quality',
        'budget': '16GB',
        'attention': 'q6_k',
        'mlp': 'q5_k',
        'embedding': 'f16',
        'normalization': 'f16',
        'lm_head': 'f16',
        'other': 'q5_k',
        'base_fmt': 'Q5_K_M',
        'desc': '⬆️ High fidelity, still good speed',
        'est_tps': '6.5',
    },
    {
        'name': 'Maximum',
        'budget': '24GB',
        'attention': 'f16',
        'mlp': 'q6_k',
        'embedding': 'f16',
        'normalization': 'f16',
        'lm_head': 'f16',
        'other': 'q6_k',
        'base_fmt': 'Q6_K',
        'desc': '📈 Best quality, bandwidth limited',
        'est_tps': '6.0',
    },
]

# ═══════════════════════════════════════════════════════════════════════════════

class LayerProfiler(QThread):
    """Thread pour profiler les layers"""
    progress = Signal(int)
    log = Signal(str)
    finished = Signal(dict)

    def __init__(self, model_path):
        super().__init__()
        self.model_path = Path(model_path)

    def run(self):
        try:
            import d2
            import numpy as np
            from collections import defaultdict

            self.log.emit(f"📊 Profiling {self.model_path.name}...\n")

            # Charger sans déquantifier pour économiser la RAM
            layers, info = d2.load_gguf(str(self.model_path), dequantize=False)

            self.log.emit(f"✅ Loaded {len(layers)} tensors\n\n")

            profiles = {}
            layer_types = defaultdict(list)

            for i, layer in enumerate(layers):
                name = layer.name
                shape = tuple(layer.shape)
                n_params = 1
                for d in shape:
                    n_params *= d

                # Estimer taille Q4_K
                bpe = 0.56
                size_mb = n_params * bpe / 1e6

                # Classifier
                if 'embed' in name:
                    ltype = 'embedding'
                elif 'attn' in name or 'self_attn' in name:
                    ltype = 'attention'
                elif 'mlp' in name or 'gate' in name or 'up_proj' in name or 'down_proj' in name:
                    ltype = 'mlp'
                elif 'norm' in name:
                    ltype = 'normalization'
                elif 'lm_head' in name:
                    ltype = 'lm_head'
                else:
                    ltype = 'other'

                layer_types[ltype].append((name, size_mb, n_params))

                profiles[name] = {
                    'shape': list(shape),
                    'size_mb': round(size_mb, 3),
                    'n_params': n_params,
                    'type': ltype,
                    'dtype': layer.extra.get('source_type', 'unknown'),
                }

                # Progress
                self.progress.emit(int((i + 1) / len(layers) * 100))

            # Log results
            self.log.emit("\n📊 Layer Distribution:\n")
            for ltype in sorted(layer_types.keys()):
                items = layer_types[ltype]
                count = len(items)
                size = sum(s for _, s, _ in items)
                self.log.emit(f"  {ltype:20s}: {count:3d} layers | {size:8.2f} MB\n")

            total_size = sum(p['size_mb'] for p in profiles.values())
            self.log.emit(f"\n📈 Total: {total_size:.2f} MB ({total_size/1024:.2f} GB)\n")

            result = {
                'profiles': profiles,
                'layer_types': dict(layer_types),
                'total_size_mb': total_size,
                'n_layers': len(layers),
            }

            self.finished.emit(result)

        except Exception as e:
            self.log.emit(f"❌ Error: {e}\n")
            self.finished.emit({})

# ═══════════════════════════════════════════════════════════════════════════════

class QwenOptimizerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.model_path = None
        self.profiles = {}
        self.output_dir = Path("qwen_optimized")
        self.output_dir.mkdir(exist_ok=True)

        self.init_ui()
        self.check_llama()

    def init_ui(self):
        """Initialiser l'interface"""
        self.setWindowTitle("Qwen3.5-9B Optimizer - Advanced Edition")
        self.setGeometry(100, 100, 1400, 900)

        # Style
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
                color: #ffffff;
            }
            QPushButton {
                background-color: #0d47a1;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d3a91;
            }
            QPushButton:disabled {
                background-color: #555555;
            }
            QGroupBox {
                color: #ffffff;
                border: 1px solid #444;
                border-radius: 5px;
                margin-top: 15px;
                padding-top: 15px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 0 8px;
            }
            QTextEdit, QTableWidget, QListWidget {
                background-color: #2d2d2d;
                color: #00ff00;
                border: 1px solid #444;
                border-radius: 4px;
                gridline-color: #444;
            }
            QHeaderView::section {
                background-color: #444;
                color: white;
                padding: 5px;
                border: 1px solid #555;
            }
            QComboBox, QSpinBox, QCheckBox {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444;
                padding: 5px;
                border-radius: 4px;
            }
            QProgressBar {
                border: 1px solid #444;
                border-radius: 4px;
                text-align: center;
                color: #ffffff;
                background-color: #2d2d2d;
            }
            QProgressBar::chunk {
                background-color: #0d47a1;
            }
            QLabel {
                color: #ffffff;
            }
        """)

        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        # ─────────────────────────────────────────────────────────────────────
        # Panneau gauche - Configuration
        # ─────────────────────────────────────────────────────────────────────
        left_panel = QVBoxLayout()

        # Model Selection
        model_group = QGroupBox("📁 Model Selection")
        model_layout = QVBoxLayout()

        self.model_path_label = QLabel("❌ No model selected")
        self.model_path_label.setWordWrap(True)
        model_layout.addWidget(self.model_path_label)

        btn_browse = QPushButton("🔍 Browse Model File")
        btn_browse.clicked.connect(self.browse_model)
        model_layout.addWidget(btn_browse)

        model_group.setLayout(model_layout)
        left_panel.addWidget(model_group)

        # Layer Profiling
        profile_group = QGroupBox("📊 Layer Analysis")
        profile_layout = QVBoxLayout()

        btn_profile = QPushButton("🔬 Analyze Layers")
        btn_profile.clicked.connect(self.profile_layers)
        profile_layout.addWidget(btn_profile)

        self.profile_info = QLabel("Ready to analyze")
        self.profile_info.setWordWrap(True)
        profile_layout.addWidget(self.profile_info)

        self.profile_progress = QProgressBar()
        self.profile_progress.setValue(0)
        profile_layout.addWidget(self.profile_progress)

        profile_group.setLayout(profile_layout)
        left_panel.addWidget(profile_group)

        # Strategy Selection
        strategy_group = QGroupBox("🎯 Strategy Selection")
        strategy_layout = QVBoxLayout()

        self.strategy_combo = QComboBox()
        for s in STRATEGIES:
            marker = "⭐ " if s.get('recommended') else "  "
            self.strategy_combo.addItem(f"{marker}{s['name']} ({s['budget']})")
        self.strategy_combo.setCurrentIndex(1)  # Balanced
        self.strategy_combo.currentIndexChanged.connect(self.update_strategy_info)
        strategy_layout.addWidget(self.strategy_combo)

        self.strategy_info = QLabel("")
        self.strategy_info.setWordWrap(True)
        strategy_layout.addWidget(self.strategy_info)
        self.update_strategy_info()

        strategy_group.setLayout(strategy_layout)
        left_panel.addWidget(strategy_group)

        # Options
        options_group = QGroupBox("⚙️ Options")
        options_layout = QGridLayout()

        options_layout.addWidget(QLabel("GPU Layers:"), 0, 0)
        self.gpu_spin = QSpinBox()
        self.gpu_spin.setMinimum(0)
        self.gpu_spin.setMaximum(33)
        self.gpu_spin.setValue(33)
        options_layout.addWidget(self.gpu_spin, 0, 1)

        options_layout.addWidget(QLabel("Context:"), 1, 0)
        self.ctx_spin = QSpinBox()
        self.ctx_spin.setMinimum(512)
        self.ctx_spin.setMaximum(32768)
        self.ctx_spin.setValue(8192)
        self.ctx_spin.setSingleStep(512)
        options_layout.addWidget(self.ctx_spin, 1, 1)

        options_group.setLayout(options_layout)
        left_panel.addWidget(options_group)

        # Actions
        action_group = QGroupBox("🚀 Actions")
        action_layout = QVBoxLayout()

        self.btn_quantize = QPushButton("▶️ Start Quantization")
        self.btn_quantize.clicked.connect(self.start_quantization)
        self.btn_quantize.setEnabled(False)
        action_layout.addWidget(self.btn_quantize)

        self.btn_benchmark = QPushButton("📊 Benchmark")
        self.btn_benchmark.clicked.connect(self.start_benchmark)
        self.btn_benchmark.setEnabled(False)
        action_layout.addWidget(self.btn_benchmark)

        self.btn_run = QPushButton("💬 Run Interactive Chat")
        self.btn_run.clicked.connect(self.run_model)
        self.btn_run.setEnabled(False)
        action_layout.addWidget(self.btn_run)

        action_group.setLayout(action_layout)
        left_panel.addWidget(action_group)

        left_panel.addStretch()

        # ─────────────────────────────────────────────────────────────────────
        # Panneau droit - Logs et résultats
        # ─────────────────────────────────────────────────────────────────────
        right_panel = QVBoxLayout()

        tabs = QTabWidget()

        # Tab Logs
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        self.log_display.setFont(QFont("Courier New", 9))
        tabs.addTab(self.log_display, "📋 Logs")

        # Tab Layers
        self.layers_table = QTableWidget()
        self.layers_table.setColumnCount(5)
        self.layers_table.setHorizontalHeaderLabels(
            ["Layer Name", "Type", "Shape", "Size (MB)", "Format"]
        )
        header = self.layers_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        tabs.addTab(self.layers_table, "🧠 Layers")

        # Tab Results
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["File", "Size", "Strategy", "Status"])
        header = self.results_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        tabs.addTab(self.results_table, "✅ Results")

        right_panel.addWidget(tabs, 1)

        # Progress
        self.progress = QProgressBar()
        self.progress.setValue(0)
        right_panel.addWidget(self.progress)

        # Status
        self.status_label = QLabel("🟢 Ready")
        right_panel.addWidget(self.status_label)

        # ─────────────────────────────────────────────────────────────────────
        # Assembly
        # ─────────────────────────────────────────────────────────────────────
        left_widget = QWidget()
        left_widget.setLayout(left_panel)
        left_widget.setMaximumWidth(400)

        right_widget = QWidget()
        right_widget.setLayout(right_panel)

        main_layout.addWidget(left_widget)
        main_layout.addWidget(right_widget, 1)

    def log(self, message):
        """Ajouter un message aux logs"""
        self.log_display.append(message.rstrip())
        self.log_display.verticalScrollBar().setValue(
            self.log_display.verticalScrollBar().maximum()
        )

    def check_llama(self):
        """Vérifier et télécharger llama.cpp"""
        self.log("⏳ Checking llama.cpp...\n")
        self.status_label.setText("⏳ Checking dependencies...")

        # Vérifier simplement si disponible
        result = subprocess.run(
            "llama-quantize --version",
            shell=True,
            capture_output=True,
            timeout=2
        )

        if result.returncode == 0:
            self.log("✅ llama.cpp is ready!\n")
            self.status_label.setText("✅ Ready")
        else:
            self.log("⚠️  llama-quantize not found\n")
            self.log("📥 To complete installation, visit:\n")
            self.log("   https://github.com/ggerganov/llama.cpp/releases\n")
            self.log("\n✅ App will run but quantization requires llama.cpp\n")
            self.status_label.setText("⚠️ llama.cpp not found")

    def update_strategy_info(self):
        """Mettre à jour info stratégie"""
        idx = self.strategy_combo.currentIndex()
        s = STRATEGIES[idx]
        self.strategy_info.setText(
            f"<b>{s['name']}</b><br>"
            f"{s['desc']}<br><br>"
            f"Budget: <b>{s['budget']}</b><br>"
            f"Estimated: <b>{s['est_tps']} tok/s</b><br>"
            f"Attention: {s['attention']}<br>"
            f"MLP: {s['mlp']}<br>"
            f"Embedding: {s['embedding']}"
        )

    def browse_model(self):
        """Parcourir les modèles"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Model",
            "",
            "GGUF (*.gguf);;Safetensors (*.safetensors);;All (*)"
        )

        if file_path:
            self.model_path = Path(file_path)
            self.model_path_label.setText(f"✅ {self.model_path.name}")
            self.log(f"✅ Model: {self.model_path.name}\n\n")
            self.btn_quantize.setEnabled(True)

    def profile_layers(self):
        """Profiler les layers"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Select a model first!")
            return

        self.log(f"\n🔬 Profiling {self.model_path.name}...\n")
        self.status_label.setText("⏳ Profiling layers...")

        profiler = LayerProfiler(self.model_path)
        profiler.progress.connect(self.profile_progress.setValue)
        profiler.log.connect(self.log)
        profiler.finished.connect(self.on_profile_finished)
        profiler.start()

    def on_profile_finished(self, result):
        """Résultats du profiling"""
        if not result:
            self.status_label.setText("❌ Profiling failed")
            return

        self.profiles = result['profiles']
        layer_types = result['layer_types']

        # Remplir la table des layers
        self.layers_table.setRowCount(0)
        for name, profile in sorted(self.profiles.items()):
            row = self.layers_table.rowCount()
            self.layers_table.insertRow(row)

            self.layers_table.setItem(row, 0, QTableWidgetItem(name))
            self.layers_table.setItem(row, 1, QTableWidgetItem(profile['type']))
            self.layers_table.setItem(row, 2, QTableWidgetItem(str(profile['shape'])))
            self.layers_table.setItem(row, 3, QTableWidgetItem(f"{profile['size_mb']:.2f}"))
            self.layers_table.setItem(row, 4, QTableWidgetItem(profile['dtype']))

        self.profile_info.setText(
            f"✅ Analyzed {len(self.profiles)} layers\n"
            f"Total: {result['total_size_mb']:.2f} MB"
        )
        self.status_label.setText("✅ Profiling complete")
        self.btn_benchmark.setEnabled(True)

    def start_quantization(self):
        """Lancer quantification"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Select a model first!")
            return

        strategy = STRATEGIES[self.strategy_combo.currentIndex()]
        output_path = self.output_dir / f"qwen-{strategy['name'].lower()}-{strategy['budget'].replace('GB', 'gb')}.gguf"

        self.log(f"\n🚀 Starting quantization with {strategy['name']} strategy...\n")
        self.progress.setValue(0)
        self.btn_quantize.setEnabled(False)
        self.status_label.setText(f"⏳ Quantizing ({strategy['name']})...")

        # Construire la commande
        cmd = [
            'llama-quantize',
            '--tensor-type', f"attention={strategy['attention']}",
            '--tensor-type', f"mlp={strategy['mlp']}",
            '--tensor-type', f"embedding={strategy['embedding']}",
            '--tensor-type', f"normalization={strategy.get('normalization', 'f16')}",
            '--tensor-type', f"lm_head={strategy.get('lm_head', 'f16')}",
            str(self.model_path),
            str(output_path),
            strategy['base_fmt'],
        ]

        try:
            process = subprocess.Popen(
                ' '.join(cmd),
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            for line in process.stdout:
                if line.strip():
                    self.log(line.rstrip())

            process.wait()

            if process.returncode == 0 and output_path.exists():
                size = output_path.stat().st_size / 1e9
                self.log(f"\n✅ Complete! Size: {size:.2f} GB\n")
                self.add_result(output_path.name, f"{size:.2f} GB", strategy['name'])
                self.status_label.setText("✅ Quantization complete")
                self.model_path = output_path
                self.btn_run.setEnabled(True)
            else:
                self.log("\n❌ Quantization failed!\n")
                self.status_label.setText("❌ Quantization failed")

        except Exception as e:
            self.log(f"\n❌ Error: {e}\n")
        finally:
            self.btn_quantize.setEnabled(True)
            self.progress.setValue(100)

    def start_benchmark(self):
        """Benchmarker"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Select a model first!")
            return

        self.log(f"\n📊 Benchmarking...\n")
        self.btn_benchmark.setEnabled(False)

        cmd = [
            'llama-cli',
            '-m', str(self.model_path),
            '-n', '128',
            '-p', 'The quick brown fox',
            '-ngl', str(self.gpu_spin.value()),
            '--timing',
        ]

        try:
            process = subprocess.Popen(
                ' '.join(cmd),
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            for line in process.stdout:
                if line.strip():
                    self.log(line.rstrip() + "\n")

            process.wait()
        except:
            self.log("⚠️ Benchmark not available\n")
        finally:
            self.btn_benchmark.setEnabled(True)

    def run_model(self):
        """Lancer le modèle"""
        if not self.model_path:
            QMessageBox.warning(self, "Error", "Select a model first!")
            return

        self.log(f"\n💬 Launching model...\n")
        self.status_label.setText("▶️ Model running...")

        cmd = [
            'llama-cli',
            '-m', str(self.model_path),
            '-ngl', str(self.gpu_spin.value()),
            '-c', str(self.ctx_spin.value()),
            '-n', '512',
        ]

        subprocess.Popen(' '.join(cmd), shell=True)

    def add_result(self, filename, size, strategy):
        """Ajouter un résultat"""
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)

        self.results_table.setItem(row, 0, QTableWidgetItem(filename))
        self.results_table.setItem(row, 1, QTableWidgetItem(size))
        self.results_table.setItem(row, 2, QTableWidgetItem(strategy))
        self.results_table.setItem(row, 3, QTableWidgetItem("✅ Ready"))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = QwenOptimizerApp()
    window.show()
    sys.exit(app.exec())
