#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_blindspot_tests — remplacé par `tests/test_literature.py`
=============================================================

Cette suite ne testait rien du code de production.

Chaque « test » comparait des constantes déclarées dans ce même fichier à
d'autres constantes du même fichier. Par exemple ::

    SINK_OLD = 128
    SINK_NEW = 4
    ...
    ok1 = frac_new < frac_old
    _result(ok1, "SINK_NEW < SINK_OLD en fraction protegee")

    for age in [0, 1, 2, 3]:
        ok = age < SINK_NEW
        _result(ok, f"token_age={age} -> protege FP16")

`4 < 128` et `0 < 4` sont vrais par arithmétique, indépendamment de ce que fait
le planificateur. Aucun de ces contrôles n'aurait échoué si le code de
production avait été supprimé. De la même façon, `PPL_LOSS` et `TPS_REL`
étaient des tables écrites à la main et jamais confrontées à une mesure.

Les mêmes points de la littérature — seuil de sink StreamingLLM, correction
roofline, valeurs aberrantes d'activation, budget de cache KV, cohérence du
ladder k-quant — sont désormais vérifiés **sur le comportement réel** dans
``tests/test_literature.py``, avec pytest.

Exécution ::

    pip install pytest
    pytest tests/ -q                       # toute la suite
    pytest tests/test_literature.py -v     # uniquement ces invariants

Ce fichier peut être supprimé sans conséquence.
"""

from __future__ import annotations

import subprocess
import sys

_MESSAGE = (
    "d2_blindspot_tests a ete remplace par tests/test_literature.py.\n"
    "Ses controles comparaient des constantes locales entre elles et ne\n"
    "touchaient pas le code de production.\n\n"
    "Executer :  pytest tests/ -q\n"
)


def __getattr__(name: str):
    raise AttributeError(
        "module 'd2_blindspot_tests' n'a pas d'attribut " + repr(name)
        + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    try:
        import pytest  # noqa: F401
    except ImportError:
        print("pytest n'est pas installe : pip install pytest")
        sys.exit(2)
    print("Lancement de la suite reelle...\n")
    sys.exit(subprocess.call([sys.executable, "-m", "pytest", "tests/", "-q"]))
