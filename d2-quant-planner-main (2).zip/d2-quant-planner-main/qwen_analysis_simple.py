#!/usr/bin/env python3
"""
Analyse simple Qwen3.5-9B — Profiling + recommandations
========================================================

Sans calcul lourd en mémoire, analyse rapide du modèle GGUF.
"""

import json
from pathlib import Path
from collections import defaultdict
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)-8s | %(message)s')
logger = logging.getLogger(__name__)

MODEL = r"C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"

class SimpleAnalyzer:
    def __init__(self, model_path=MODEL, output_dir="qwen_optimized"):
        self.model_path = Path(model_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

        if not self.model_path.exists():
            logger.error(f"❌ Model not found: {self.model_path}")
            return
        logger.info(f"✓ Model: {self.model_path.name}")

    def analyze(self):
        """Analyse le modèle et génère recommandations"""
        logger.info("\n" + "="*70)
        logger.info("QWEN3.5-9B QUANTISATION ANALYSIS")
        logger.info("="*70)

        try:
            import d2

            logger.info("\nCharging model (shapes only)...")
            layers, info = d2.load_gguf(str(self.model_path), dequantize=False)

            logger.info(f"✓ {len(layers)} tensors loaded")
            logger.info(f"  Architecture: {info.get('arch', '?')}")
            logger.info(f"  Blocks: {info.get('n_blocks', '?')}")
            logger.info(f"  KV heads: {info.get('n_kv_heads', '?')}")

            # Profiler les layers
            profiles = {}
            layer_types = defaultdict(list)
            total_size = 0

            for layer in layers:
                name = layer.name
                shape = layer.shape
                n_params = 1
                for d in shape:
                    n_params *= d

                # Format original (Q4_K_S estimated)
                bpe = 0.56  # Q4_K
                size_bytes = n_params * bpe
                size_mb = size_bytes / 1e6
                total_size += size_mb

                # Classifier
                if 'embed' in name:
                    ltype = 'embedding'
                elif 'attn' in name or 'self_attn' in name:
                    ltype = 'attention'
                elif 'mlp' in name or 'gate' in name or 'up_proj' in name or 'down_proj' in name:
                    ltype = 'mlp'
                elif 'norm' in name:
                    ltype = 'norm'
                elif 'lm_head' in name:
                    ltype = 'lm_head'
                else:
                    ltype = 'other'

                layer_types[ltype].append((name, size_mb, n_params))

                profiles[name] = {
                    'shape': shape,
                    'size_mb': round(size_mb, 3),
                    'n_params': n_params,
                    'type': ltype,
                }

            # Stats
            logger.info(f"\n📊 Layer distribution:")
            for ltype in sorted(layer_types.keys()):
                items = layer_types[ltype]
                count = len(items)
                size = sum(s for _, s, _ in items)
                logger.info(f"  {ltype:15s}: {count:3d} layers | {size:8.2f} MB")

            logger.info(f"\n📈 Total model size: {total_size:.2f} MB ({total_size/1024:.2f} GB)")

            # Stratégies
            logger.info(f"\n🎯 QUANTIZATION STRATEGIES:")

            strategies = {
                'conservative': {
                    'desc': 'Maximum compression, minimum RAM',
                    'budget_gb': 8,
                    'attention': 'q4_k',
                    'mlp': 'q4_k',
                    'embedding': 'q5_k',
                    'est_size_mb': total_size * 0.45,
                    'est_tps': 6.0,  # Conservative estimate
                },
                'balanced': {
                    'desc': 'Good quality/speed tradeoff',
                    'budget_gb': 12,
                    'attention': 'q5_k',
                    'mlp': 'q4_k',
                    'embedding': 'f16',
                    'est_size_mb': total_size * 0.55,
                    'est_tps': 7.0,
                },
                'quality': {
                    'desc': 'Prioritize quality over size',
                    'budget_gb': 16,
                    'attention': 'q6_k',
                    'mlp': 'q5_k',
                    'embedding': 'f16',
                    'est_size_mb': total_size * 0.65,
                    'est_tps': 6.5,
                },
                'maximum': {
                    'desc': 'Use all available RAM, best quality',
                    'budget_gb': 24,
                    'attention': 'f16',
                    'mlp': 'q6_k',
                    'embedding': 'f16',
                    'est_size_mb': total_size * 0.75,
                    'est_tps': 6.0,  # Bandwidth limited
                },
            }

            for name, strat in sorted(strategies.items()):
                logger.info(f"\n  {name.upper()}: {strat['desc']}")
                logger.info(f"    Budget: {strat['budget_gb']}GB")
                logger.info(f"    Attention: {strat['attention']} | MLP: {strat['mlp']} | Embedding: {strat['embedding']}")
                logger.info(f"    Est. size: {strat['est_size_mb']:.0f} MB | Est. TPS: {strat['est_tps']:.1f}")

            # Sauve profils et recommandations
            export = {
                'timestamp': datetime.now().isoformat(),
                'model': str(self.model_path),
                'architecture': {
                    'arch': info.get('arch'),
                    'n_blocks': info.get('n_blocks'),
                    'n_kv_heads': info.get('n_kv_heads'),
                    'head_dim': info.get('head_dim'),
                    'n_tensors': len(layers),
                    'total_size_mb': round(total_size, 2),
                    'total_size_gb': round(total_size / 1024, 2),
                },
                'layer_types': {
                    ltype: {
                        'count': len(items),
                        'size_mb': round(sum(s for _, s, _ in items), 2),
                        'avg_params': int(sum(p for _, _, p in items) / len(items)),
                    }
                    for ltype, items in layer_types.items()
                },
                'strategies': strategies,
                'recommendations': [
                    "Use 'balanced' (12GB) for general purpose — best quality/speed tradeoff",
                    "Use 'conservative' (8GB) for embedding in edge devices",
                    "Quality layers (norm, lm_head) should stay F16 or Q8_0",
                    "Attention layers are sensitive — use Q5_K minimum",
                    "MLP layers are robust — Q4_K is safe",
                    "For maximum throughput: enable KV cache quantization (INT8)",
                ],
            }

            # Export
            export_path = self.output_dir / "qwen_analysis.json"
            with open(export_path, 'w') as f:
                json.dump(export, f, indent=2)
            logger.info(f"\n✓ Analysis saved: {export_path}")

            # Rapport texte
            self._generate_report(export)

            return export

        except Exception as e:
            logger.error(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _generate_report(self, export):
        """Génère rapport texte"""
        lines = []
        lines.append("="*80)
        lines.append("QWEN3.5-9B QUANTIZATION ANALYSIS REPORT")
        lines.append(f"Generated: {export['timestamp']}")
        lines.append("="*80)
        lines.append("")

        arch = export['architecture']
        lines.append("ARCHITECTURE:")
        lines.append(f"  Model: {arch['arch']}")
        lines.append(f"  Layers: {arch['n_blocks']} ({arch['n_tensors']} tensors)")
        lines.append(f"  Total size: {arch['total_size_gb']:.2f} GB ({arch['total_size_mb']:.0f} MB)")
        lines.append("")

        lines.append("LAYER TYPES:")
        for ltype in sorted(export['layer_types'].keys()):
            lt = export['layer_types'][ltype]
            lines.append(f"  {ltype:15s}: {lt['count']:3d} layers | {lt['size_mb']:8.2f} MB | avg {lt['avg_params']:,d} params")
        lines.append("")

        lines.append("RECOMMENDED STRATEGIES:")
        lines.append("")
        for name, strat in sorted(export['strategies'].items()):
            lines.append(f"{name.upper()} Strategy")
            lines.append(f"  {strat['desc']}")
            lines.append(f"  • Budget: {strat['budget_gb']}GB")
            lines.append(f"  • Attention: {strat['attention']}")
            lines.append(f"  • MLP: {strat['mlp']}")
            lines.append(f"  • Embedding: {strat['embedding']}")
            lines.append(f"  • Estimated model size: {strat['est_size_mb']:.0f} MB")
            lines.append(f"  • Estimated throughput: {strat['est_tps']:.1f} tokens/sec")
            lines.append("")

        lines.append("KEY RECOMMENDATIONS:")
        for i, rec in enumerate(export['recommendations'], 1):
            lines.append(f"  {i}. {rec}")
        lines.append("")

        lines.append("NEXT STEPS:")
        lines.append("  1. Use this analysis to choose a quantization strategy")
        lines.append("  2. For detailed optimization: use d2-plan with your GPU target")
        lines.append("  3. Convert using: llama-quantize --tensor-type <fmt> model.gguf output.gguf <base>")
        lines.append("  4. Benchmark with: llama-perplexity -m model.gguf -f calibration.txt")
        lines.append("")

        lines.append("="*80)

        report_path = self.output_dir / "QWEN_ANALYSIS_REPORT.txt"
        report_path.write_text("\n".join(lines), encoding='utf-8')

        logger.info(f"✓ Report saved: {report_path}")
        logger.info("\n" + "="*70)
        for line in lines[-30:]:
            if line.strip():
                logger.info(line)


if __name__ == "__main__":
    analyzer = SimpleAnalyzer()
    analyzer.analyze()
