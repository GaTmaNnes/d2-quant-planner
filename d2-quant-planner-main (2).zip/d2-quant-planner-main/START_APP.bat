@echo off
REM Qwen3.5-9B Optimizer Launcher
REM ================================

cls
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║        Qwen3.5-9B Optimizer - Desktop Application          ║
echo ║                                                            ║
echo ║  - Auto download llama.cpp                                ║
echo ║  - Profile each layer                                     ║
echo ║  - Choose optimization strategy                           ║
echo ║  - Quantize automatically                                 ║
echo ║  - Run model interactively                                ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

REM Find Python
echo Installing dependencies...
python3 -m pip install PySide6 numpy scipy gguf -q

echo.
echo Starting application...
echo.

python3 qwen_optimizer_full.py

pause
