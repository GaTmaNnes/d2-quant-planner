#!/usr/bin/env python3
"""
Scanner spectral alpha_w
=========================

Produit un rapport `alpha_w_report.json` par tenseur.

Ce que le v1 faisait de faux
----------------------------
1. `AlphaScannerSM120.alpha_w(tensor.data)` appliquait un SVD aux **octets
   bruts** du GGUF. Pour un tenseur quantifié, ce sont des blocs compressés :
   échelles f16, nibbles empaquetés, masques. Le spectre analysé n'était pas
   celui des poids.
2. `except: return 1.5` masquait toute erreur derrière une valeur qui tombe
   exactement sur le seuil INT8 de la politique.
3. `max(-2.0 * slope, 1.0)` plaquait un plancher à 1.0. Dans le
   `alpha_w_report.json` livré, **202 des 274 tenseurs valent exactement
   1.0** : c'est le plancher, pas une mesure.
4. `alpha = 2 * pente` n'est pas l'exposant de Martin & Mahoney. La relation
   correcte est `alpha = 1 + 1/(2*pente)` (démonstration dans `d2/spectral.py`).
5. `sys.path.append("beellama.cpp-main/gguf-py")` : coquille et chemin relatif
   au répertoire courant.

Ce que fait cette version
-------------------------
Déquantification via `gguf.quants.dequantize` (implémentation de référence de
llama.cpp), estimateur de Hill avec balayage de x_min minimisant la distance
KS, et `null` explicite quand l'ajustement échoue.

**alpha est un diagnostic de qualité d'entraînement, pas un critère de
quantification.** Aucun travail publié n'établit de correspondance entre alpha
et la largeur de bits soutenable. Pour produire un plan, utilisez
`d2_rtx_gguf_profiler.py`, qui décide à partir de l'erreur de quantification
mesurée.

Usage :
    python alpha_spectral_scanner.py model.gguf
    python alpha_spectral_scanner.py model.gguf --out rapport.json --limit 50
"""

from __future__ import annotations

import argparse
import json
import time

import numpy as np

import d2
from d2 import console, spectral


def main() -> int:
    console.setup()
    p = argparse.ArgumentParser(description="Scanner spectral alpha_w")
    p.add_argument("model", help="fichier .gguf ou .safetensors")
    p.add_argument("--out", default="alpha_w_report.json")
    p.add_argument("--limit", type=int, default=0,
                   help="ne traiter que les N premiers tenseurs (0 = tous)")
    p.add_argument("--max-dim", type=int, default=4096,
                   help="sous-échantillonnage pour le SVD (défaut : 4096)")
    args = p.parse_args()

    print(f"  Lecture de {args.model}")
    try:
        if args.model.lower().endswith(".gguf"):
            layers, info = d2.load_gguf(args.model)
        else:
            layers, info = d2.load_safetensors(args.model)
    except (FileNotFoundError, ImportError) as exc:
        print(f"  [!] {exc}")
        return 2

    if args.limit:
        layers = layers[: args.limit]
    print(f"  {len(layers)} tenseurs a analyser\n")

    print(f"  {'#':>4}  {'Tenseur':<44} {'alpha':>8} {'KS':>7} "
          f"{'rang_st':>9} {'classe':>10} {'s':>6}")
    print("  " + "-" * 94)

    report = {}
    n_ok = 0
    t0 = time.time()
    for i, layer in enumerate(layers):
        if layer.weights is None:
            continue
        st = spectral.analyze(layer.weights, max_dim=args.max_dim)
        if st.alpha_ok:
            n_ok += 1
        report[layer.name] = {
            "alpha": None if not st.alpha_ok else round(st.alpha, 4),
            "alpha_ok": st.alpha_ok,
            "ks_distance": None if not np.isfinite(st.ks) else round(st.ks, 4),
            "n_tail": st.n_tail,
            "beta_index_slope": None if not np.isfinite(st.beta) else round(st.beta, 4),
            "stable_rank": None if not np.isfinite(st.stable_rank) else round(st.stable_rank, 3),
            "effective_rank": None if not np.isfinite(st.effective_rank) else round(st.effective_rank, 3),
            "spectral_entropy": None if not np.isfinite(st.entropy) else round(st.entropy, 4),
            "layer_class": layer.cls,
            "shape": list(layer.shape),
            "source_type": layer.extra.get("source_type"),
            "subsampled": st.sampled,
        }
        a = f"{st.alpha:8.3f}" if st.alpha_ok else "    null"
        ks = f"{st.ks:7.3f}" if np.isfinite(st.ks) else "      -"
        sr = f"{st.stable_rank:9.1f}" if np.isfinite(st.stable_rank) else "        -"
        print(f"  {i + 1:>4}  {layer.name[:44]:<44} {a} {ks} {sr} "
              f"{layer.cls:>10} {'oui' if st.sampled else 'non':>6}")

    payload = {
        "_meta": {
            "model": args.model,
            "estimator": "Hill 1975 + balayage x_min (Clauset et al. 2009)",
            "definition": "ESD rho(lambda) ~ lambda^-alpha, lambda = valeurs propres de W^T W",
            "reference": "Martin & Mahoney, JMLR 22(165), 2021",
            "interpretation": {
                "2 <= alpha <= 4": "couche bien entrainee",
                "alpha < 2": "queue tres lourde, fortement correlee",
                "alpha > 6": "proche d'une matrice aleatoire",
            },
            "avertissement": (
                "alpha mesure la qualite d'entrainement, pas la robustesse a "
                "la quantification. Ne pas l'utiliser seul pour choisir une "
                "precision : voir d2_rtx_gguf_profiler.py."
            ),
            "n_tensors": len(report),
            "n_alpha_ok": n_ok,
            "elapsed_s": round(time.time() - t0, 1),
        },
        "tensors": report,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    print(f"\n  {n_ok}/{len(report)} ajustements exploitables "
          f"({time.time() - t0:.1f} s)")
    if n_ok < len(report):
        print(f"  {len(report) - n_ok} tenseurs sans queue exploitable : "
              "champ `alpha` a null (le v1 aurait ecrit 1.0 ou 1.5).")
    print(f"  Rapport : {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
