#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
d2_qdf_bayesian_optimized - remplace par le package `d2`
========================================================

Ce module faisait doublon avec plusieurs autres implementations du meme calcul,
avec des conventions incompatibles. Sa logique a ete remplacee par le package
`d2`, qui ne definit chaque grandeur qu'une fois et est couvert par des tests.

Pourquoi il a ete retire
------------------------
* `compile()` ouvrait `precision_map.json` et `final_sm120_graph_plan.json`,
  absents du depot.
* `randomized_svd` projetait `W @ Q` et prenait les valeurs singulieres de la
  matrice projetee sans l'etape `B = Q.T @ W` du schema standard : le spectre
  obtenu n'approche pas celui de `W`.
* Meme « coherence bayesienne » non definie que dans la variante ci-dessus.
* `coherence = clip(1/alpha, 0.5, 0.9)` ecrasait toute l'information dans un
  intervalle de 0.4 de large.

Correspondance
--------------
* ``OptimizedSVD.randomized_svd`` -> ``d2.spectral.singular_values``
* ``QDFV5Engine`` -> ``d2.sensitivity.sensitivity_matrix``
* ``D2Compiler.compile`` -> ``d2.plan_layers``

Exemple equivalent
------------------
::

    import d2

    layers, info = d2.load_gguf("model-f16.gguf")
    plan = d2.plan_layers(layers, d2.get_profile("rtx4090"),
                          vram_budget_gb=16.0, ctx_len=8192,
                          **d2.kv_geometry(info))
    print(d2.summarize(plan))
    d2.export_llama_cpp(plan, json_path="plan.json")

Ce fichier peut etre supprime sans consequence : rien dans le depot ne
l'importe.
"""

from __future__ import annotations

_MODULE = 'd2_qdf_bayesian_optimized'

_MOVED = {'OptimizedSVD.randomized_svd': 'd2.spectral.singular_values', 'QDFV5Engine': 'd2.sensitivity.sensitivity_matrix', 'D2Compiler.compile': 'd2.plan_layers'}

_MESSAGE = (
    _MODULE + " a ete remplace par le package `d2`.\n"
    "Correspondance :\n"
    + "".join("  " + k + " -> " + v + "\n" for k, v in _MOVED.items())
    + "Voir le docstring de ce fichier pour le detail des defauts corriges."
)


def __getattr__(name: str):
    """Toute utilisation de l'ancienne API renvoie vers la nouvelle."""
    target = _MOVED.get(name)
    if target:
        raise AttributeError(
            name + " a ete remplace par " + target + ".\n" + _MESSAGE
        )
    raise AttributeError(
        "module " + _MODULE + " n'a pas d'attribut " + repr(name) + ".\n" + _MESSAGE
    )


if __name__ == "__main__":
    import sys

    try:
        from d2 import console

        console.setup()
    except ImportError:
        pass
    print(_MESSAGE)
    sys.exit(2)
