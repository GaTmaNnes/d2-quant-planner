#!/usr/bin/env python3
"""
Optimisation Qwen3.5-9B local — Profiling complet + plans D2
============================================================

Utilise le modèle GGUF Q4_K_S existant avec imatrix pour:
  1. Profiler tous les layers (taille, sensibilité, importance)
  2. Générer plans D2 optimisés pour RAM/perf
  3. Analyser trade-offs: précision vs performance vs tokens/s
  4. Créer GGUFs optimisés pour chaque stratégie

Usage:
  python optimize_qwen_local.py --model <path> --gpu-target rtx4090 --budget 12
  python optimize_qwen_local.py --model <path> --analyze-layers
  python optimize_qwen_local.py --model <path> --generate-all-plans
"""

import json
import subprocess
import sys
from pathlib import Path
from collections import Counter, defaultdict
import logging
from datetime import datetime
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(message)s'
)
logger = logging.getLogger(__name__)

# Modèle par défaut
DEFAULT_MODEL = r"C:\Users\videl\.lmstudio\models\DavidAU\Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF\Qwen3.5-9B-Claude-4.6-OS-AV-H-UNCENSORED-THINK-D_AU-Q4_K_S-imat.gguf"

class QwenOptimizer:
    def __init__(self, model_path=DEFAULT_MODEL, output_dir="qwen_optimized", gpu_target="rtx4090"):
        self.model_path = Path(model_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.gpu_target = gpu_target

        if not self.model_path.exists():
            logger.error(f"❌ Modèle non trouvé: {self.model_path}")
            sys.exit(1)
        logger.info(f"✓ Modèle: {self.model_path.name}")

    def profile_layers(self):
        """Profiler tous les layers du modèle"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 1: PROFILING DES LAYERS")
        logger.info("="*70)

        try:
            import d2

            logger.info(f"Chargement GGUF (shapes only, économie mémoire)...")
            # Charger layers via D2 SANS déquantifier (économie mémoire)
            layers, info = d2.load_gguf(str(self.model_path), dequantize=False, with_spectral=False)
            logger.info(f"✓ {len(layers)} tenseurs chargés (non-déquantifiés)")

            profiles = {}
            total_size_mb = 0
            layer_types = defaultdict(int)

            for layer_spec in layers:
                name = layer_spec.name
                shape = tuple(layer_spec.shape)

                # Estimer la taille (approximation Q4_K)
                n_params = np.prod(shape)
                bpe = 0.56  # Q4_K
                size_bytes = n_params * bpe
                size_mb = size_bytes / 1e6
                total_size_mb += size_mb

                # Classifier le layer
                if 'embed' in name:
                    layer_type = 'embedding'
                elif 'attn' in name:
                    layer_type = 'attention'
                elif 'mlp' in name or 'gate' in name or 'up_proj' in name or 'down_proj' in name:
                    layer_type = 'mlp'
                elif 'norm' in name:
                    layer_type = 'normalization'
                elif 'lm_head' in name:
                    layer_type = 'lm_head'
                else:
                    layer_type = 'other'

                layer_types[layer_type] += 1

                profiles[name] = {
                    'shape': list(shape),
                    'dtype': layer_spec.extra.get('source_type', 'unknown'),
                    'size_mb': round(size_mb, 3),
                    'size_bytes': int(size_bytes),
                    'n_params': int(n_params),
                    'layer_type': layer_type,
                    'is_critical': layer_type in ['lm_head', 'normalization', 'embedding'],
                    'alpha': float(layer_spec.alpha) if not np.isnan(layer_spec.alpha) else None,
                }

            # Stats par type
            logger.info("\n📊 Distribution par layer type:")
            for ltype, count in sorted(layer_types.items(), key=lambda x: -x[1]):
                total_this_type = sum(p['size_mb'] for p in profiles.values() if p['layer_type'] == ltype)
                logger.info(f"  {ltype:20s}: {count:3d} layers | {total_this_type:7.2f} MB")

            logger.info(f"\n📈 Total model size: {total_size_mb:.2f} MB")

            # Sauvegarder les profils
            profile_path = self.output_dir / "layer_profiles.json"
            with open(profile_path, 'w') as f:
                json.dump(profiles, f, indent=2)
            logger.info(f"✓ Profils sauvegardés: {profile_path}")

            return profiles, info

        except Exception as e:
            logger.error(f"❌ Erreur profiling: {e}")
            import traceback
            traceback.print_exc()
            return {}, {}

    def generate_optimization_plans(self, profiles):
        """Générer plans D2 pour différents budgets"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 2: GÉNÉRATION PLANS D2")
        logger.info("="*70)

        try:
            import d2

            # Charger layers
            layers, info = d2.load_gguf(str(self.model_path))
            caps = d2.get_profile(self.gpu_target)

            logger.info(f"GPU Target: {self.gpu_target}")
            logger.info(f"  Memory: {caps.vram_gb:.1f} GB")
            if hasattr(caps, 'tflops_fp16'):
                logger.info(f"  FP16 TFlops: {caps.tflops_fp16:.1f}")
            if hasattr(caps, 'tflops_int8'):
                logger.info(f"  INT8 TFlops: {caps.tflops_int8:.1f}")

            # Budgets à tester
            budgets = [
                (8, "conservative"),
                (12, "balanced"),
                (16, "quality"),
                (24, "maximum"),
            ]

            plans = {}
            logger.info(f"\nTesting {len(budgets)} budgets:")

            for budget_gb, strategy in budgets:
                logger.info(f"\n  🎯 Budget: {budget_gb}GB ({strategy})")

                try:
                    plan = d2.plan_layers(
                        layers, caps,
                        vram_budget_gb=float(budget_gb),
                        ctx_len=8192,
                        max_rel_error=0.05,
                    )

                    summary = d2.summarize(plan, caps)

                    # Compter formats (plan est un dict de LayerSpec -> fmt)
                    formats = Counter(v if isinstance(v, str) else str(v) for v in plan.values())

                    logger.info(f"    ✓ Plan valide")
                    logger.info(f"      - VRAM: {summary.get('vram_used', '?')} GB")
                    logger.info(f"      - Err max: {summary.get('max_error', '?')}")
                    logger.info(f"      - Formats: {dict(formats)}")

                    plans[strategy] = {
                        'budget_gb': budget_gb,
                        'strategy': strategy,
                        'plan': plan,
                        'summary': summary,
                        'format_distribution': dict(formats),
                    }

                except d2.InfeasibleBudget as e:
                    logger.warning(f"    ✗ Budget infaisable: {e}")
                except Exception as e:
                    logger.warning(f"    ✗ Erreur: {e}")

            if not plans:
                logger.error("❌ Aucun plan valide généré!")
                return {}

            # Sauvegarder
            plans_path = self.output_dir / "optimization_plans.json"
            summary_data = {
                k: {
                    'budget_gb': v['budget_gb'],
                    'strategy': v['strategy'],
                    'summary': v['summary'],
                    'format_distribution': v['format_distribution'],
                } for k, v in plans.items()
            }
            with open(plans_path, 'w') as f:
                json.dump(summary_data, f, indent=2)
            logger.info(f"\n✓ Plans sauvegardés: {plans_path}")

            return plans

        except Exception as e:
            logger.error(f"❌ Erreur génération plans: {e}")
            import traceback
            traceback.print_exc()
            return {}

    def analyze_tradeoffs(self, profiles, plans):
        """Analyser trade-offs: RAM vs perf vs précision"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 3: ANALYSE TRADE-OFFS")
        logger.info("="*70)

        analysis = {
            'timestamp': datetime.now().isoformat(),
            'model': str(self.model_path),
            'tradeoffs': []
        }

        for strategy, plan_data in plans.items():
            budget = plan_data['budget_gb']
            formats = plan_data.get('format_distribution', {})

            critical_count = sum(1 for p in profiles.values() if p.get('is_critical'))
            critical_size = sum(p['size_mb'] for p in profiles.values() if p.get('is_critical'))

            # Estimer performance (heuristique)
            total_formats = sum(formats.values()) if formats else 1
            int4_count = formats.get('q4_k', formats.get('q4_K', 0))
            int4_ratio = int4_count / max(total_formats, 1)
            estimated_tps = 7.45 * (0.8 + 0.2 * int4_ratio)  # Baseline FLM 7.45 TPS

            logger.info(f"\n  📊 Strategy: {strategy} ({budget}GB)")
            logger.info(f"    - Format dist: {formats}")
            logger.info(f"    - Critical layers: {critical_count} ({critical_size:.1f} MB)")
            logger.info(f"    - INT4 ratio: {int4_ratio*100:.0f}%")
            logger.info(f"    - Est. TPS: {estimated_tps:.2f} tok/s")

            analysis['tradeoffs'].append({
                'strategy': strategy,
                'budget_gb': budget,
                'format_distribution': formats,
                'critical_layers': critical_count,
                'critical_size_mb': round(critical_size, 2),
                'int4_ratio': round(int4_ratio, 3),
                'estimated_tps': round(estimated_tps, 2),
            })

        # Sauvegarder
        analysis_path = self.output_dir / "tradeoffs_analysis.json"
        with open(analysis_path, 'w') as f:
            json.dump(analysis, f, indent=2)
        logger.info(f"\n✓ Analyse sauvegardée: {analysis_path}")

        return analysis

    def generate_quantize_commands(self, plans):
        """Générer commandes llama-quantize pour chaque plan"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 4: COMMANDES QUANTISATION")
        logger.info("="*70)

        commands = {}

        try:
            import d2

            for strategy, plan_data in plans.items():
                plan = plan_data.get('plan', {})
                budget = plan_data['budget_gb']

                output_name = f"qwen-{strategy}-{budget}gb.gguf"
                output_path = self.output_dir / output_name
                json_path = self.output_dir / f"plan-{strategy}-{budget}gb.json"

                try:
                    # Générer commande via D2
                    cmd = d2.export_llama_cpp(
                        plan,
                        str(self.model_path),
                        str(output_path),
                        json_path=str(json_path)
                    )

                    logger.info(f"\n  📝 {strategy} ({budget}GB):")
                    logger.info(f"    Output: {output_name}")
                    logger.info(f"    Command: {cmd[:80]}...")

                    commands[strategy] = {
                        'budget_gb': budget,
                        'strategy': strategy,
                        'input_model': str(self.model_path),
                        'output_model': str(output_path),
                        'plan_json': str(json_path),
                        'llama_quantize_command': cmd,
                    }
                except Exception as e:
                    logger.warning(f"⚠️  {strategy}: {e}")

        except Exception as e:
            logger.warning(f"❌ Erreur génération commandes: {e}")
            return {}

        # Sauvegarder
        commands_path = self.output_dir / "quantize_commands.json"
        with open(commands_path, 'w') as f:
            json.dump(commands, f, indent=2)
        logger.info(f"\n✓ Commandes sauvegardées: {commands_path}")

        return commands

    def generate_report(self, profiles, plans, analysis, commands):
        """Générer rapport texte complet"""
        logger.info("\n" + "="*70)
        logger.info("PHASE 5: RAPPORT COMPLET")
        logger.info("="*70)

        lines = []
        lines.append("=" * 80)
        lines.append("OPTIMISATION QUANTISATION QWEN3.5-9B")
        lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 80)
        lines.append("")

        # Model info
        lines.append("MODÈLE:")
        lines.append(f"  Chemin: {self.model_path}")
        lines.append(f"  Layers: {len(profiles)}")
        lines.append(f"  Taille: {sum(p['size_mb'] for p in profiles.values()):.2f} MB")
        lines.append("")

        # Layer types
        layer_types = Counter(p['layer_type'] for p in profiles.values())
        lines.append("  Par type:")
        for ltype, count in sorted(layer_types.items()):
            size = sum(p['size_mb'] for p in profiles.values() if p['layer_type'] == ltype)
            lines.append(f"    {ltype:20s}: {count:3d} layers ({size:7.2f} MB)")
        lines.append("")

        # Plans summary
        lines.append("PLANS D'OPTIMISATION:")
        for strategy, plan_data in sorted(plans.items()):
            budget = plan_data['budget_gb']
            formats = plan_data['format_distribution']
            lines.append(f"\n  {strategy.upper()} ({budget}GB):")
            lines.append(f"    Formats: {formats}")
        lines.append("")

        # Tradeoffs
        if analysis and 'tradeoffs' in analysis:
            lines.append("ANALYSE TRADE-OFFS:")
            lines.append("  Strategy        Budget  INT4%  Est.TPS  Model MB  Critical MB")
            lines.append("  " + "-" * 60)
            for t in analysis['tradeoffs']:
                ratio = t['int4_ratio'] * 100
                lines.append(
                    f"  {t['strategy']:15s}  "
                    f"{t['budget_gb']:3d}GB  "
                    f"{ratio:5.0f}%  "
                    f"{t['estimated_tps']:7.2f}  "
                    f"{t['estimated_model_size_mb']:9.0f}  "
                    f"{t['critical_size_mb']:11.1f}"
                )
        lines.append("")

        # Recommendations
        lines.append("RECOMMANDATIONS:")
        lines.append("  1. Pour RAM minimum:  utiliser 'conservative' (8GB, Q4 partout)")
        lines.append("  2. Pour qualité max:  utiliser 'quality' (16GB, keep F16 critical)")
        lines.append("  3. Pour throughput:   utiliser 'balanced' (12GB, mixed INT4/INT8)")
        lines.append("  4. Exécuter: llama-quantize --tensor-type <format> <input> <output> <base>")
        lines.append("")

        # Commands
        lines.append("COMMANDES LLAMA-QUANTIZE:")
        for strategy, cmd_data in sorted(commands.items()):
            lines.append(f"\n  {strategy}:")
            lines.append(f"    {cmd_data['llama_quantize_command']}")
        lines.append("")

        lines.append("=" * 80)

        report_path = self.output_dir / "RAPPORT_OPTIMISATION.txt"
        report_path.write_text("\n".join(lines), encoding='utf-8')

        logger.info(f"✓ Rapport: {report_path}")

        # Afficher résumé
        for line in lines[-20:]:
            if line.strip():
                logger.info(line)

    def run_full_optimization(self):
        """Exécuter l'optimisation complète"""
        logger.info("\n" + "█" * 70)
        logger.info("OPTIMISATION COMPLÈTE QWEN3.5-9B")
        logger.info("█" * 70 + "\n")

        # 1. Profile
        profiles, info = self.profile_layers()
        if not profiles:
            return False

        # 2. Generate plans
        plans = self.generate_optimization_plans(profiles)
        if not plans:
            return False

        # 3. Analyze tradeoffs
        analysis = self.analyze_tradeoffs(profiles, plans)

        # 4. Generate commands
        commands = self.generate_quantize_commands(plans)

        # 5. Report
        self.generate_report(profiles, plans, analysis, commands)

        logger.info("\n" + "█" * 70)
        logger.info(f"✅ OPTIMISATION COMPLÉTÉE")
        logger.info(f"Résultats: {self.output_dir}")
        logger.info("█" * 70)

        return True


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Optimisation Qwen3.5-9B quantisation")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Chemin GGUF")
    parser.add_argument("--gpu-target", default="rtx4090", help="GPU cible")
    parser.add_argument("--output-dir", default="qwen_optimized", help="Répertoire sortie")
    args = parser.parse_args()

    optimizer = QwenOptimizer(
        model_path=args.model,
        output_dir=args.output_dir,
        gpu_target=args.gpu_target
    )

    success = optimizer.run_full_optimization()
    sys.exit(0 if success else 1)
