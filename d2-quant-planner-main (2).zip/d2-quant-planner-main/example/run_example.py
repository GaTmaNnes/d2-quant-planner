#!/usr/bin/env python3
"""
D2 — Exemple minimal, sans modèle à télécharger
================================================

Montre le trajet complet : couches → plan → export llama.cpp.

    python example/run_example.py
    python example/run_example.py --budget 2.0 --gpu rtx5070
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import d2
from d2 import console


def main() -> int:
    console.setup()
    parser = argparse.ArgumentParser(description="Exemple D2")
    parser.add_argument("--budget", type=float, default=3.0,
                        help="budget VRAM en Go (defaut: 3.0)")
    parser.add_argument("--gpu", default="rtx4090",
                        help=f"cible ({', '.join(sorted(d2.GPU_PROFILES))})")
    parser.add_argument("--ctx", type=int, default=4096, help="contexte en tokens")
    parser.add_argument("--max-rel-error", type=float, default=None,
                        help="plafond d'erreur relative par couche, ex. 0.05")
    parser.add_argument("--out", default="quant_plan_example.json")
    args = parser.parse_args()

    print("=== D2 — Exemple de planification ===\n")

    # Modèle de démonstration : 8 blocs, poids synthétiques à queue lourde.
    # Les formes sont celles d'un vrai modèle, donc la comptabilité mémoire
    # est réaliste ; les poids sont réduits pour que l'exemple soit instantané.
    layers, info = d2.synthetic_model(
        n_blocks=8, hidden=2048, intermediate=5632, vocab=32000,
        n_kv_heads=4, head_dim=128,
    )
    caps = d2.get_profile(args.gpu)

    print(f"Modele     : synthetique, {info['n_blocks']} blocs, "
          f"hidden={info['hidden_size']}, {len(layers)} tenseurs")
    print(f"Cible      : {caps.name} [{caps.sm_str}] {caps.vram_gb:.0f} Go")
    print(f"Formats    : {', '.join(d2.supported_formats(caps))}")
    print(f"Budget     : {args.budget} Go   contexte : {args.ctx} tokens\n")

    try:
        plan = d2.plan_layers(
            layers, caps,
            vram_budget_gb=args.budget,
            ctx_len=args.ctx,
            max_rel_error=args.max_rel_error,
            **d2.kv_geometry(info),
        )
    except d2.InfeasibleBudget as exc:
        print(f"Budget intenable : {exc}")
        return 1

    print(d2.summarize(plan, caps, ctx_len=args.ctx))
    print()
    print(d2.layer_table(plan, limit=15))

    payload = d2.export_llama_cpp(plan, json_path=args.out)
    print(f"\nPlan ecrit : {args.out}")
    print("\nCommande llama-quantize :")
    print(payload["command"])
    if payload["unmapped"]:
        print(f"\n[!] {len(payload['unmapped'])} tenseurs sans correspondance GGUF.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
