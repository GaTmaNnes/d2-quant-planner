# Build TensorRT-LLM pour Blackwell sm_120 — genere depuis un plan D2
# ====================================================================
#
# Remplace la version auto-generee du v1, dont le contenu posait trois
# problemes :
#
# 1. **Options inexistantes.** `--per_layer_precision`, `--quantization` et
#    `--use_gpt_attention_plugin` ne sont pas des options de `trtllm-build` ;
#    `--max_output_len` a ete remplace par `--max_seq_len`. La quantification
#    par couche se declare dans le quant_config du checkpoint.
#
# 2. **Le plan ne quantifiait presque rien.** Sur les 274 tenseurs figes dans
#    la variable $prec_args, tous etaient en `fp16` sauf une quinzaine de
#    `ssm_conv1d` en `int8` — alors que la ligne de commande demandait par
#    ailleurs `nvfp4` global. Ce plan venait d'un scan spectral invalide :
#    202 des 274 valeurs alpha_w valaient exactement 1.0, le plancher de
#    l'estimateur, ce qui poussait 82 % des couches en FP16_REQUIRED.
#    Voir MIGRATION.md section 3.
#
# 3. **Contradiction avec la politique annoncee.** Les rapports posaient
#    « alpha > 1.8 -> NVFP4 » et relevaient des alpha de 3.27 a 4.11 sur
#    `ssm_conv1d` — donc NVFP4 — tout en concluant qu'il fallait les verrouiller
#    en FP16. build_rtx_5070_blackwell.ps1 les mettait en fp16, celui-ci en
#    int8 pour la moitie. Les trois decisions sont incompatibles.
#
# Le plan n'est plus fige dans ce fichier : il est recalcule a chaque execution
# a partir des poids reels, ce qui evite qu'il se desynchronise du modele.

$ErrorActionPreference = "Stop"

$Model      = "qwen-f16.gguf"
$HfModel    = "./hf_model"
$Gpu        = "rtx5090"             # rtx5090 | rtx5080 | rtx5070 | b200
$Budget     = 32                    # Go de VRAM
$Ctx        = 32768                 # tokens
$Checkpoint = "./trt_checkpoint"
$Engine     = "./engine_blackwell_sm120"

if (-not (Test-Path $Model)) {
    throw "$Model introuvable. Convertissez d'abord le modele avec convert_hf_to_gguf.py"
}

Write-Host "=== Etape 1/3 : plan D2 ===" -ForegroundColor Cyan

$imatrixArg = @()
if (Test-Path "model.imatrix") {
    $imatrixArg = @("--imatrix", "model.imatrix")
    Write-Host "  imatrix trouvee : decision fondee sur des statistiques d'activation."
} else {
    Write-Host "  Pas d'imatrix : decision fondee sur des a priori de couche." -ForegroundColor Yellow
    Write-Host "  Pour un meilleur plan :" -ForegroundColor Yellow
    Write-Host "    llama-imatrix -m $Model -f calibration.txt -o model.imatrix"
}

python d2_rtx_gguf_profiler.py $Model `
    --gpu-target $Gpu `
    --budget $Budget `
    --ctx $Ctx `
    --target both `
    --out d2_plan.json `
    --tensorrt-out tensorrt_plan.json `
    @imatrixArg

if ($LASTEXITCODE -ne 0) { throw "Le plan D2 a echoue (code $LASTEXITCODE)" }

Write-Host "`n  Plan ecrit : d2_plan.json et tensorrt_plan.json" -ForegroundColor Green

Write-Host "`n=== Etape 2/3 : checkpoint quantifie ===" -ForegroundColor Cyan
Write-Host "  Reporter le quant_config de tensorrt_plan.json dans quantize.py :"
Write-Host ""
Write-Host "    python TensorRT-LLM/examples/quantization/quantize.py ``"
Write-Host "        --model_dir $HfModel ``"
Write-Host "        --dtype float16 ``"
Write-Host "        --qformat nvfp4 ``"
Write-Host "        --kv_cache_dtype fp8 ``"
Write-Host "        --output_dir $Checkpoint ``"
Write-Host "        --calib_size 512"
Write-Host ""
Write-Host "  NVFP4 exige sm_100 (B200) ou sm_120 (RTX 50xx)."

if (-not (Test-Path $Checkpoint)) {
    Write-Host "`n  $Checkpoint absent : arret avant la construction." -ForegroundColor Yellow
    exit 0
}

Write-Host "`n=== Etape 3/3 : construction du moteur ===" -ForegroundColor Cyan

trtllm-build `
    --checkpoint_dir $Checkpoint `
    --output_dir $Engine `
    --gemm_plugin auto `
    --max_batch_size 4 `
    --max_input_len 4096 `
    --max_seq_len $Ctx

if ($LASTEXITCODE -ne 0) { throw "trtllm-build a echoue (code $LASTEXITCODE)" }

Write-Host "`nMoteur construit dans $Engine" -ForegroundColor Green
Write-Host "`nValidation avant mise en service :" -ForegroundColor Yellow
Write-Host "  python TensorRT-LLM/examples/summarize.py --engine_dir $Engine --test_trt_llm"
Write-Host "  Comparer a un preglage uniforme de MEME TAILLE, pas au FP16 :"
Write-Host "  c'est la seule comparaison qui dit si la repartition par couche apporte quelque chose."
