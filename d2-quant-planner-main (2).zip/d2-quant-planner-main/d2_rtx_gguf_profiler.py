#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
D2 — Scanner GGUF et planificateur de quantification (ligne de commande)
=========================================================================

L'implémentation est dans `d2/cli.py` ; ce fichier n'est qu'un point d'entrée,
conservé parce que le README le documente. Le v1 avait quatre pipelines
parallèles (`d2_rtx_gguf_profiler`, `d2_compile_pipeline`, `d2_compiler`,
`d2_compiler_v2`) aux conventions incompatibles ; il n'y en a plus qu'un.

Corrections principales par rapport au v1
------------------------------------------
* **Déquantification réelle.** Le v1 appliquait un SVD à `tensor.data` brut,
  c'est-à-dire aux octets de blocs compressés (échelles f16, nibbles, masques).
  On utilise `gguf.quants.dequantize`, l'implémentation de référence de
  llama.cpp.
* **Capacités GPU.** `sm[0] >= 7 and sm[1] >= 5` déclarait A100 (8,0),
  H100 (9,0) et Blackwell (12,0) dépourvus d'INT8 et d'INT4. Corrigé, et les
  profils Blackwell manquants ont été ajoutés.
* **Plus de faux benchmark.** `--benchmark` mesurait un GEMM FP16 quelle que
  soit la précision demandée (la branche INT8 faisait
  `F.linear(x, Wq.to(float16) * scale)`), et le rapport présentait ces valeurs
  comme des mesures INT8. Les bornes roofline sont désormais étiquetées comme
  telles, et les vraies mesures GPU sont dans `d2_profiler.py --measure`.
* **Ordre des dimensions.** Les formes GGUF sont en convention `ne`
  (dimension rapide en premier) ; le v1 les lisait comme du row-major, ce qui
  transposait implicitement toutes les matrices non carrées.
* **Comptabilité mémoire exacte.** `bpe` valait 0.5 pour l'INT4 ; un Q4_K
  occupe 0.5625 octet par poids une fois les échelles comptées.

Exemples
--------
::

    python d2_rtx_gguf_profiler.py model.gguf --gpu-target rtx4090 --budget 16
    python d2_rtx_gguf_profiler.py --demo --gpu-target rtx5070
    python d2_rtx_gguf_profiler.py model.gguf --imatrix model.imatrix --spectral
    python d2_rtx_gguf_profiler.py model.gguf --target tensorrt

Une fois le paquet installé (`pip install -e .`), la commande `d2-plan` est
équivalente.
"""

from __future__ import annotations

from d2.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
