#!/usr/bin/env python3
"""
Pipeline d'optimisation quantique Qwen3.5-9B
Profiling complet des layers → optimisation D2 → GGUF final
"""

import os
import sys
import json
import subprocess
from pathlib import Path
import logging
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class QwenOptimizationPipeline:
    def __init__(self, output_dir="qwen_optimized", gpu_target="rtx4090"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.gpu_target = gpu_target
        self.model_name = "DavidAU/Qwen3.5-9B-Claude-4.6-OS-Auto-Variable-HERETIC-UNCENSORED-THINKING-MAX-NEOCODE-Imatrix-GGUF"
        self.work_dir = self.output_dir / "work"
        self.work_dir.mkdir(exist_ok=True)

    def step_download_model(self):
        """Télécharger le modèle HF et convertir en F16 GGUF"""
        logger.info("=" * 70)
        logger.info("STEP 1: Téléchargement & conversion du modèle")
        logger.info("=" * 70)

        gguf_path = self.work_dir / "qwen-f16.gguf"

        if gguf_path.exists():
            logger.info(f"✓ Modèle trouvé: {gguf_path}")
            return gguf_path

        logger.info(f"Téléchargement de {self.model_name}...")
        try:
            # Utiliser huggingface_hub pour télécharger
            from huggingface_hub import hf_hub_download

            downloaded = hf_hub_download(
                repo_id=self.model_name,
                filename="model.gguf",
                cache_dir=str(self.work_dir / "hf_cache")
            )
            logger.info(f"✓ Modèle téléchargé: {downloaded}")
            return Path(downloaded)

        except ImportError:
            logger.error("huggingface_hub requis. Installez: pip install huggingface_hub")
            sys.exit(1)

    def step_profile_layers(self, model_path):
        """Profiler les layers avec D2 (analysis spectrale + roofline)"""
        logger.info("=" * 70)
        logger.info("STEP 2: Profiling des layers")
        logger.info("=" * 70)

        profile_path = self.output_dir / "profile.json"

        logger.info(f"Analyse spectrale et roofline...")
        try:
            import d2

            # Charger le modèle
            layers, info = d2.load_gguf(str(model_path))
            logger.info(f"✓ Modèle chargé: {len(layers)} tenseurs, {info.get('n_params', 'N/A')} params")

            # Profil matériel
            caps = d2.get_profile(self.gpu_target)
            logger.info(f"✓ GPU: {self.gpu_target}")
            logger.info(f"  - Memory: {caps.vram_gb:.1f} GB")
            logger.info(f"  - Peak FP16: {caps.tflops_fp16:.1f} TFLOPS")
            logger.info(f"  - Peak INT8: {caps.tflops_int8:.1f} TFLOPS")

            # Profil par layer: erreur, taille, importance
            profiles = {}
            for name, tensor in layers.items():
                shape = tensor.shape
                dtype = tensor.dtype
                size_mb = tensor.nbytes / 1e6

                profiles[name] = {
                    "shape": shape,
                    "dtype": str(dtype),
                    "size_mb": size_mb,
                    "n_params": int(np.prod(shape) if hasattr(shape, '__len__') else shape)
                }

            logger.info(f"✓ {len(profiles)} tenseurs profilés")

            with open(profile_path, 'w') as f:
                json.dump(profiles, f, indent=2)

            return profiles

        except Exception as e:
            logger.error(f"Erreur profiling: {e}")
            return {}

    def step_generate_imatrix(self, model_path):
        """Générer l'imatrix llama.cpp (importance par activation)"""
        logger.info("=" * 70)
        logger.info("STEP 3: Génération imatrix")
        logger.info("=" * 70)

        imatrix_path = self.work_dir / "model.imatrix"

        if imatrix_path.exists():
            logger.info(f"✓ imatrix trouvé: {imatrix_path}")
            return imatrix_path

        # Préparer données de calibration (texte Python/ML)
        calib_text = self.work_dir / "calibration.txt"
        if not calib_text.exists():
            logger.info("Préparation données de calibration...")
            sample_text = """
            import numpy as np
            import torch
            from transformers import AutoModel

            def optimize_quantization(layers, budget, strategy='mixed'):
                '''Optimiser la quantisation par layer selon le budget mémoire'''
                allocations = {}
                remaining = budget

                for layer_name, tensor in layers.items():
                    if tensor.is_critical:
                        allocations[layer_name] = 'q8_0'
                    elif tensor.is_mlp:
                        allocations[layer_name] = 'q4_k'
                    else:
                        allocations[layer_name] = 'q5_k'

                return allocations

            class SpecializedQuantizer:
                def __init__(self, model_path, target_vram_gb=12):
                    self.model_path = model_path
                    self.target_vram = target_vram_gb * 1e9

                def profile_layer_sensitivity(self, layer):
                    '''Mesurer la sensibilité de chaque layer à la quantisation'''
                    errors = {}
                    for fmt in ['q8_0', 'q6_k', 'q5_k', 'q4_k']:
                        quantized = self.quantize(layer, fmt)
                        error = np.linalg.norm(layer - quantized) / np.linalg.norm(layer)
                        errors[fmt] = error
                    return errors

                def optimize_precision_per_layer(self):
                    '''Allocation optimale bits/layer minimisant erreur globale'''
                    plan = {}
                    for layer_name, sensitivity in self.sensitivities.items():
                        best_fmt = min(sensitivity, key=sensitivity.get)
                        plan[layer_name] = best_fmt
                    return plan
            """ * 10  # Répéter pour avoir suffisamment de tokens

            with open(calib_text, 'w') as f:
                f.write(sample_text)
            logger.info(f"✓ Données calibration: {len(sample_text)} chars")

        logger.info("Génération imatrix via llama-imatrix...")
        try:
            # Vérifier si llama-imatrix est disponible
            result = subprocess.run(
                ["llama-imatrix", "-m", str(model_path), "-f", str(calib_text),
                 "-o", str(imatrix_path), "-n", "256"],
                capture_output=True, timeout=3600
            )

            if result.returncode == 0:
                logger.info(f"✓ imatrix généré: {imatrix_path}")
                return imatrix_path
            else:
                logger.warning(f"llama-imatrix échec: {result.stderr.decode()}")
                logger.warning("Continuant sans imatrix (utiliser activation defaults)")
                return None

        except FileNotFoundError:
            logger.warning("llama-imatrix non installé. Voir: https://github.com/ggerganov/llama.cpp")
            logger.warning("Continuant avec importance par défaut...")
            return None

    def step_plan_quantization(self, model_path, imatrix_path=None):
        """D2: Optimiser allocation bits sous contrainte VRAM"""
        logger.info("=" * 70)
        logger.info("STEP 4: Planification quantisation D2")
        logger.info("=" * 70)

        try:
            import d2

            # Charger modèle
            layers, info = d2.load_gguf(str(model_path))
            caps = d2.get_profile(self.gpu_target)

            # Budgets à explorer
            vram_budgets = [8, 10, 12, 16]  # Go
            ctx_lengths = [8192]  # tokens

            best_plans = {}

            for budget_gb in vram_budgets:
                for ctx_len in ctx_lengths:
                    logger.info(f"\nOptimisation: {budget_gb}GB VRAM, {ctx_len}k context")

                    try:
                        plan = d2.plan_layers(
                            layers, caps,
                            vram_budget_gb=float(budget_gb),
                            ctx_len=ctx_len,
                            max_rel_error=0.05,  # 5% erreur max par layer
                            imatrix_path=imatrix_path,
                        )

                        summary = d2.summarize(plan, caps)

                        logger.info(f"  ✓ Plan valide")
                        logger.info(f"    - VRAM utilisée: {summary['vram_used']:.2f} GB")
                        logger.info(f"    - Débit estimé: {summary['tokens_per_sec']:.1f} tok/s")
                        logger.info(f"    - Erreur max: {summary['max_error']:.4f}")

                        key = (budget_gb, ctx_len)
                        best_plans[key] = {
                            "plan": plan,
                            "summary": summary,
                            "command": d2.export_llama_cpp(plan, str(model_path),
                                                          str(self.output_dir / f"qwen-q-{budget_gb}gb.gguf"),
                                                          json_path=str(self.output_dir / f"plan-{budget_gb}gb.json"))
                        }

                    except d2.InfeasibleBudget as e:
                        logger.warning(f"  ✗ Budget {budget_gb}GB infaisable")

            # Exporter le meilleur plan
            if best_plans:
                # Préférer 12GB pour balance qualité/perfo
                best_key = (12, 8192) if (12, 8192) in best_plans else list(best_plans.keys())[0]
                best = best_plans[best_key]

                logger.info(f"\n✓ Plan sélectionné: {best_key[0]}GB, {best_key[1]} ctx")
                logger.info(f"\nCommande llama-quantize:")
                logger.info(best["command"])

                # Sauvegarder les plans
                with open(self.output_dir / "plans.json", 'w') as f:
                    json.dump({
                        str(k): v["summary"] for k, v in best_plans.items()
                    }, f, indent=2)

                return best
            else:
                logger.error("Aucun plan valide trouvé!")
                return None

        except ImportError:
            logger.error("d2 module requis. Installez: pip install -e .")
            sys.exit(1)

    def step_quantize_model(self, model_path, plan):
        """Exécuter llama-quantize avec le plan optimisé"""
        logger.info("=" * 70)
        logger.info("STEP 5: Quantisation du modèle")
        logger.info("=" * 70)

        output_path = self.output_dir / "qwen-optimized.gguf"

        if output_path.exists():
            logger.info(f"✓ Modèle déjà quantisé: {output_path}")
            return output_path

        logger.info("Exécution llama-quantize...")
        logger.info(plan["command"])

        try:
            result = subprocess.run(plan["command"], shell=True, timeout=14400)

            if result.returncode == 0:
                logger.info(f"✓ Quantisation réussie: {output_path}")
                return output_path
            else:
                logger.error(f"llama-quantize échec (code {result.returncode})")
                return None

        except subprocess.TimeoutExpired:
            logger.error("Quantisation timeout (>4h)")
            return None

    def step_benchmark(self, model_path):
        """Benchmark de latence et throughput"""
        logger.info("=" * 70)
        logger.info("STEP 6: Benchmark")
        logger.info("=" * 70)

        try:
            import d2
            result = subprocess.run(
                ["python", "d2_profiler.py", str(model_path), "--measure", "--gpu-target", self.gpu_target],
                capture_output=True, timeout=600
            )

            if result.returncode == 0:
                logger.info("Résultats benchmark:")
                logger.info(result.stdout.decode())
                return True
            else:
                logger.warning("Benchmark non disponible")
                return False
        except Exception as e:
            logger.warning(f"Benchmark échec: {e}")
            return False

    def run_full_pipeline(self):
        """Exécuter le pipeline complet"""
        logger.info("\n" + "="*70)
        logger.info("PIPELINE D'OPTIMISATION QUANTIQUE QWEN3.5-9B")
        logger.info("="*70)
        logger.info(f"Output: {self.output_dir}")
        logger.info(f"GPU Target: {self.gpu_target}")
        logger.info(f"Timestamp: {datetime.now().isoformat()}")
        logger.info("="*70 + "\n")

        # 1. Télécharger modèle
        model_path = self.step_download_model()
        if not model_path:
            return False

        # 2. Profiler layers
        self.step_profile_layers(model_path)

        # 3. Générer imatrix
        imatrix_path = self.step_generate_imatrix(model_path)

        # 4. Planifier quantisation
        plan = self.step_plan_quantization(model_path, imatrix_path)
        if not plan:
            return False

        # 5. Quantiser
        quantized = self.step_quantize_model(model_path, plan)
        if not quantized:
            logger.warning("Quantisation échouée, mais plan généré")

        # 6. Benchmark
        self.step_benchmark(quantized or model_path)

        logger.info("\n" + "="*70)
        logger.info("PIPELINE COMPLÉTÉ")
        logger.info(f"Résultats: {self.output_dir}")
        logger.info("="*70)

        return True


if __name__ == "__main__":
    import numpy as np

    pipeline = QwenOptimizationPipeline(
        output_dir="qwen_optimized",
        gpu_target="rtx4090"  # Adapter selon votre GPU
    )

    success = pipeline.run_full_pipeline()
    sys.exit(0 if success else 1)
