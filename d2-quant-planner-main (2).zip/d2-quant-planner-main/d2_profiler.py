#!/usr/bin/env python3
"""
Profileur de latence par couche
================================

Le v1 titrait « Mesures reelles vs Predictions D2-V12 » au-dessus de chiffres
produits par ::

    lat = m * n * bpe / 1000        # micro-secondes
    bw  = (m*n*bpe) / (lat * 1e-6) / 1e9

La seconde ligne se simplifie en `bw = 1.0` **pour toute entrée** : la
« bande passante mesurée » valait 1 Go/s sur chaque ligne du tableau, ce qui
révèle que la première ligne suppose implicitement une mémoire à 1 Go/s. Les
valeurs `D2_PREDICTIONS` auxquelles ces chiffres étaient comparés portaient par
ailleurs le commentaire `# Dummy model metadata`. Aucune mesure n'avait lieu,
et le README décrivait ce fichier comme un « Profiler GPU torch.profiler »
alors que torch n'y était pas importé.

Cette version distingue explicitement deux régimes :

* **estimation roofline** (toujours disponible) — bornes calculées à partir de
  la bande passante constructeur, préfixées `~` ;
* **mesure GPU** (`--measure`, nécessite torch + CUDA) — vraies latences via
  CUDA events, sur des GEMM réellement exécutés.

Elles ne sont jamais affichées dans la même colonne sans mention.

Usage :
    python d2_profiler.py --gpu rtx4090
    python d2_profiler.py --gpu rtx4090 --measure      # si CUDA disponible
"""

from __future__ import annotations

import argparse
from typing import Dict, List, Optional

import numpy as np

import d2
from d2 import console, formats as fmts, hardware as hw

#: Couches représentatives d'un Llama-3-8B (sortie, entrée).
LAYER_SHAPES = [
    ("attn_q      [4096, 4096]", (4096, 4096)),
    ("attn_kv     [1024, 4096]", (1024, 4096)),
    ("attn_output [4096, 4096]", (4096, 4096)),
    ("ffn_up     [14336, 4096]", (14336, 4096)),
    ("ffn_down   [4096, 14336]", (4096, 14336)),
    ("output    [128256, 4096]", (128256, 4096)),
]

FORMATS = ["F16", "Q8_0", "Q6_K", "Q4_K"]


def roofline_row(shape, fmt: str, caps: hw.GPUCaps, batch: int = 1) -> Dict:
    """Borne roofline pour une couche. Aucune exécution."""
    n = shape[0] * shape[1]
    nbytes = fmts.format_bytes(n, fmt)
    lat_s = hw.decode_latency_s(nbytes, caps, n_elements=n, batch=batch)
    return {
        "format": fmt,
        "bytes_mb": nbytes / 1e6,
        "lat_ms": lat_s * 1e3,
        "regime": hw.roofline_regime(nbytes, n, caps, batch),
        "source": "roofline",
    }


def measure_row(shape, fmt: str, batch: int = 1, n_runs: int = 20) -> Optional[Dict]:
    """Mesure réelle d'une GEMM sur GPU, via CUDA events.

    On mesure une GEMM **FP16** alimentée par des poids déquantifiés depuis
    `fmt`. C'est ce que font réellement les kernels weight-only (Marlin,
    k-quants de llama.cpp) : ils déquantifient vers FP16 avant le produit. La
    latence rend donc compte du trafic mémoire des poids compressés seulement
    si le kernel lit bien la forme compressée — ce qui n'est pas le cas ici,
    puisque torch ne dispose pas de ces kernels.

    On le dit explicitement plutôt que d'étiqueter le résultat « INT8 » comme
    le faisait le v1 : cette mesure ne vaut que pour F16.
    """
    try:
        import torch
    except ImportError:
        return None
    if not torch.cuda.is_available():
        return None

    m, n = shape
    W = torch.randn(m, n, dtype=torch.float16, device="cuda")
    x = torch.randn(batch, n, dtype=torch.float16, device="cuda")
    for _ in range(5):
        torch.nn.functional.linear(x, W)
    torch.cuda.synchronize()

    start, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
    start.record()
    for _ in range(n_runs):
        torch.nn.functional.linear(x, W)
    end.record()
    torch.cuda.synchronize()
    lat_ms = start.elapsed_time(end) / n_runs
    del W, x
    torch.cuda.empty_cache()
    return {
        "format": "F16 (kernel torch)",
        "bytes_mb": m * n * 2 / 1e6,
        "lat_ms": lat_ms,
        "regime": "-",
        "source": "CUDA events",
    }


def main() -> int:
    console.setup()
    p = argparse.ArgumentParser(description="Profileur de latence D2")
    p.add_argument("--gpu", default="rtx4090",
                   help=f"cible ({', '.join(sorted(d2.GPU_PROFILES))})")
    p.add_argument("--batch", type=int, default=1,
                   help="1 = decodage (limite memoire), >512 = prefill")
    p.add_argument("--measure", action="store_true",
                   help="mesure GPU reelle en plus des bornes (torch + CUDA)")
    args = p.parse_args()

    caps = d2.get_profile(args.gpu)
    print("=" * 84)
    print(f"  Latence par couche — {caps.name} [{caps.sm_str}]")
    print(f"  Bande passante {caps.bw_gbs:.0f} Go/s "
          f"(efficacite {caps.bw_efficiency:.0%})   "
          f"pic {caps.peak_tflops:.0f} TFLOPS FP16   batch={args.batch}")
    print("=" * 84)
    print("  Toutes les valeurs prefixees '~' sont des BORNES calculees,")
    print("  pas des mesures. Colonne 'source' explicite pour chaque ligne.")
    print()

    header = (f"  {'Couche':<26} {'Format':<20} {'Mo':>9} {'~lat (ms)':>11} "
              f"{'regime':>9}  source")
    print(header)
    print("  " + "-" * (len(header) - 2))

    measured_any = False
    for label, shape in LAYER_SHAPES:
        for fmt in FORMATS:
            r = roofline_row(shape, fmt, caps, args.batch)
            print(f"  {label:<26} {r['format']:<20} {r['bytes_mb']:>9.1f} "
                  f"{r['lat_ms']:>11.4f} {r['regime']:>9}  {r['source']}")
        if args.measure:
            m = measure_row(shape, "F16", args.batch)
            if m:
                measured_any = True
                print(f"  {label:<26} {m['format']:<20} {m['bytes_mb']:>9.1f} "
                      f"{m['lat_ms']:>11.4f} {m['regime']:>9}  {m['source']}")
        print()

    if args.measure and not measured_any:
        print("  [!] --measure demande mais torch/CUDA indisponible : "
              "aucune mesure reelle effectuee.")

    # Débit agrégé, en s'appuyant sur le vrai planificateur.
    print("=" * 84)
    print("  Debit de decodage agrege (borne bande passante, modele complet)")
    print("=" * 84)
    layers, info = d2.synthetic_model()
    total_f16 = sum(fmts.format_bytes(l.n_elements, "F16") for l in layers)
    print(f"  {'Format uniforme':<22} {'Taille':>10} {'~tok/s':>10}")
    print("  " + "-" * 46)
    for fmt in FORMATS:
        size = sum(fmts.format_bytes(l.n_elements, fmt) for l in layers)
        t = hw.decode_latency_s(size, caps)
        print(f"  {fmt:<22} {size / 1e9:>9.2f}G {1.0 / t:>10.1f}")
    print()
    print("  Un plan mixte D2 se situe entre ces bornes ; voir "
          "d2_rtx_gguf_profiler.py.")
    print(f"  Reference F16 : {total_f16 / 1e9:.2f} Go")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
