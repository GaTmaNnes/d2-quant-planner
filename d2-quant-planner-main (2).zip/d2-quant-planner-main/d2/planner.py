"""
d2.planner — Allocation de précision sous contrainte mémoire
=============================================================

Formulation (HAWQ-V3, Yao et al., ICML 2021)
--------------------------------------------

    min  Σ_i Σ_q  x[i,q] · Ω(i,q)
    s.c. Σ_q x[i,q] = 1                       ∀ i        (une précision par couche)
         Σ_i Σ_q x[i,q] · octets(i,q) ≤ B_w               (budget mémoire poids)
         x[i,q] = 1                           ∀ i forcée, q = haute précision
         x[i,q] ∈ {0,1}

Ω est le coût qualité **mesuré** de `d2.sensitivity` (erreur de quantification
pondérée par l'importance), pas un score spectral heuristique.

Il n'y a pas de terme de vitesse dans l'objectif, et c'est délibéré : en
décodage auto-régressif la latence est proportionnelle aux octets lus
(cf. `d2.hardware`), donc la contrainte mémoire **est** la contrainte de
vitesse. Ajouter un second terme λ·vitesse comme le faisait le v1 revenait à
compter deux fois la même grandeur — et dans `v18.py` ce terme était 10⁵ fois
trop petit pour peser quoi que ce soit.

Trois solveurs, du plus fort au plus faible :

1. `scipy.optimize.milp` (HiGHS) — MIP exact. Défaut.
2. OR-Tools CBC/SCIP — si installé.
3. Glouton lagrangien — repli exact-en-pratique pour ce problème (voir plus bas).

Le glouton du v1 partait de l'assignation la plus compacte puis « relâchait
vers une précision plus haute » quand le budget était dépassé, ce qui
**augmentait** la mémoire : la boucle ne pouvait jamais converger. Ici on part
de la plus haute précision et on dégrade par meilleur ratio octets-gagnés /
qualité-perdue, ce qui est la relaxation lagrangienne classique du sac à dos
multi-choix et donne l'optimum à un item près.

Références
----------
- Yao et al., "HAWQ-V3: Dyadic Neural Network Quantization", ICML 2021.
- Hoffman & Padberg, "Solving airline crew-scheduling problems by branch-and-cut",
  Management Science 39(6), 1993 — pour le multiple-choice knapsack.
- Hooper et al., "KVQuant", NeurIPS 2024 ; Liu et al., "KIVI", ICML 2024 —
  dimensionnement du cache KV.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import formats as fmts
from . import hardware as hw
from .sensitivity import LayerSpec, sensitivity_matrix

__all__ = [
    "PlanEntry",
    "Plan",
    "MemoryBudget",
    "kv_cache_bytes",
    "solve",
    "plan_layers",
    "InfeasibleBudget",
]


class InfeasibleBudget(ValueError):
    """Le budget ne peut être tenu, même au format le plus compact.

    Le v1 ne signalait jamais ce cas : le glouton bouclait dans le mauvais sens
    et retournait un plan hors budget présenté comme valide.
    """


# ─────────────────────────────────────────────────────────────────────────────
# Budget mémoire
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class MemoryBudget:
    """Décomposition du budget VRAM.

    Toutes les valeurs sont en **octets**, et toutes les conversions en Go
    utilisent la base 10 (1 Go = 1e9 o), comme les constructeurs de GPU. Le v1
    mélangeait 1024³ pour le budget et 1e9 pour l'affichage, si bien que le
    détail affiché ne totalisait pas le total affiché.
    """

    total: float
    kv_cache: float = 0.0
    activations: float = 0.0
    overhead: float = 0.0

    @property
    def weights(self) -> float:
        """Octets réellement disponibles pour les poids."""
        return self.total - self.kv_cache - self.activations - self.overhead

    def to_dict(self) -> Dict:
        return {
            "total_gb": self.total / 1e9,
            "kv_cache_gb": self.kv_cache / 1e9,
            "activations_gb": self.activations / 1e9,
            "overhead_gb": self.overhead / 1e9,
            "weights_gb": self.weights / 1e9,
        }


def kv_cache_bytes(
    n_layers: int,
    n_kv_heads: int,
    head_dim: int,
    ctx_len: int,
    kv_format: str = "F16",
    sink_tokens: int = 4,
) -> float:
    """Taille du cache KV en octets.

        2 (K et V) × n_layers × ctx × n_kv_heads × head_dim × octets_par_élément

    `n_layers` est le nombre de **blocs transformer**, pas le nombre de
    tenseurs d'attention : le v1 comptait les tenseurs de classe `attn`, ce qui
    doublait le résultat (q_proj et o_proj comptaient tous les deux).

    Les `sink_tokens` premiers tokens sont conservés en F16 : StreamingLLM
    (Xiao et al., ICLR 2024) montre que les tout premiers tokens concentrent
    une masse d'attention disproportionnée et que les quantifier dégrade
    fortement la génération longue. La littérature valide 1 à 4 tokens ; le v1
    en protégeait 128, soit un surcoût inutile de deux ordres de grandeur.

    Args:
        n_layers:   nombre de blocs transformer.
        n_kv_heads: têtes KV (GQA : < têtes d'attention).
        head_dim:   dimension par tête.
        ctx_len:    longueur de contexte en tokens.
        kv_format:  format du cache quantifié.
        sink_tokens: tokens conservés en F16.

    Returns:
        Octets.
    """
    bpe_kv = fmts.bytes_per_weight(kv_format)
    bpe_f16 = fmts.bytes_per_weight("F16")
    n_sink = min(max(sink_tokens, 0), ctx_len)
    n_quant = max(ctx_len - n_sink, 0)
    per_tok = 2.0 * n_layers * n_kv_heads * head_dim
    return per_tok * (n_quant * bpe_kv + n_sink * bpe_f16)


# ─────────────────────────────────────────────────────────────────────────────
# Résultat
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class PlanEntry:
    """Décision pour une couche."""

    name: str
    shape: List[int]
    cls: str
    format: str
    bytes: float
    omega: float
    rel_error: float
    forced: bool
    measured: bool
    alpha: float = float("nan")

    def to_dict(self) -> Dict:
        d = dict(self.__dict__)
        d["size_gb"] = self.bytes / 1e9
        return d


@dataclass
class Plan:
    """Plan complet."""

    entries: List[PlanEntry]
    budget: MemoryBudget
    solver: str
    optimal: bool
    total_bytes: float
    total_omega: float
    gpu: str = "unknown"
    notes: List[str] = field(default_factory=list)

    @property
    def n_switches(self) -> int:
        """Nombre de changements de format entre couches consécutives."""
        f = [e.format for e in self.entries]
        return sum(1 for a, b in zip(f, f[1:]) if a != b)

    def distribution(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for e in self.entries:
            out[e.format] = out.get(e.format, 0) + 1
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    def size_by_format(self) -> Dict[str, float]:
        out: Dict[str, float] = {}
        for e in self.entries:
            out[e.format] = out.get(e.format, 0.0) + e.bytes
        return out

    def to_dict(self) -> Dict:
        return {
            "gpu": self.gpu,
            "solver": self.solver,
            "optimal": self.optimal,
            "budget": self.budget.to_dict(),
            "total_gb": self.total_bytes / 1e9,
            "total_omega": self.total_omega,
            "n_switches": self.n_switches,
            "distribution": self.distribution(),
            "notes": self.notes,
            "layers": [e.to_dict() for e in self.entries],
        }


# ─────────────────────────────────────────────────────────────────────────────
# Solveurs
# ─────────────────────────────────────────────────────────────────────────────


def _feasibility_check(size: np.ndarray, forced: np.ndarray, hp_index: int,
                       budget: float, omega: Optional[np.ndarray] = None) -> None:
    """Vérifie qu'une solution existe. Lève `InfeasibleBudget` sinon.

    Ne considère que les formats **admissibles** (Ω fini) : un plafond de
    qualité peut interdire les formats les plus compacts.
    """
    n, P = size.shape
    if hp_index >= P or hp_index < 0:
        raise ValueError(f"hp_index={hp_index} invalide pour P={P} formats")
    best = np.empty(n)
    for i in range(n):
        if forced[i]:
            best[i] = size[i, hp_index]
            continue
        allowed = np.isfinite(omega[i]) if omega is not None else np.ones(P, bool)
        if not allowed.any():
            allowed = np.zeros(P, bool)
            allowed[hp_index] = True
        best[i] = size[i][allowed].min()
    need = float(best.sum())
    if need > budget:
        raise InfeasibleBudget(
            f"budget poids {budget / 1e9:.3f} Go insuffisant : le plan le plus "
            f"compact possible occupe {need / 1e9:.3f} Go "
            f"(dont {sum(size[i, hp_index] for i in range(n) if forced[i]) / 1e9:.3f} Go "
            f"de couches contraintes en haute précision). "
            f"Augmentez le budget, réduisez le contexte, ou passez "
            f"`allow_force_relax=True`."
        )


def _solve_scipy(omega: np.ndarray, size: np.ndarray, budget: float,
                 forced: np.ndarray, hp_index: int):
    """MIP exact via scipy.optimize.milp (HiGHS)."""
    from scipy.optimize import Bounds, LinearConstraint, milp

    n, P = omega.shape
    nv = n * P
    c = np.where(np.isfinite(omega), omega, 1e12).ravel()

    rows, lb, ub = [], [], []

    # Une précision par couche.
    A_one = np.zeros((n, nv))
    for i in range(n):
        A_one[i, i * P:(i + 1) * P] = 1.0
    rows.append(A_one)
    lb.append(np.ones(n))
    ub.append(np.ones(n))

    # Couches contraintes.
    idx = np.flatnonzero(forced)
    if idx.size:
        A_f = np.zeros((idx.size, nv))
        for r, i in enumerate(idx):
            A_f[r, i * P + hp_index] = 1.0
        rows.append(A_f)
        lb.append(np.ones(idx.size))
        ub.append(np.ones(idx.size))

    # Budget mémoire.
    rows.append(size.ravel()[None, :])
    lb.append(np.array([-np.inf]))
    ub.append(np.array([budget]))

    res = milp(
        c,
        constraints=LinearConstraint(np.vstack(rows), np.concatenate(lb),
                                     np.concatenate(ub)),
        integrality=np.ones(nv),
        bounds=Bounds(lb=np.zeros(nv), ub=np.ones(nv)),
    )
    if res.status != 0 or res.x is None:
        return None, False
    x = np.asarray(res.x).reshape(n, P)
    return np.argmax(x, axis=1).astype(int), True


def _solve_ortools(omega: np.ndarray, size: np.ndarray, budget: float,
                   forced: np.ndarray, hp_index: int):
    """MIP via OR-Tools, si le paquet est disponible."""
    try:
        from ortools.linear_solver import pywraplp
    except ImportError:
        return None, False

    n, P = omega.shape
    solver = pywraplp.Solver.CreateSolver("SCIP") or pywraplp.Solver.CreateSolver("CBC")
    if solver is None:
        return None, False

    x = [[solver.BoolVar(f"x_{i}_{q}") for q in range(P)] for i in range(n)]
    for i in range(n):
        solver.Add(sum(x[i]) == 1)
        if forced[i]:
            solver.Add(x[i][hp_index] == 1)
    solver.Add(
        sum(x[i][q] * float(size[i, q]) for i in range(n) for q in range(P)) <= budget
    )
    obj = solver.Objective()
    for i in range(n):
        for q in range(P):
            w = omega[i, q]
            obj.SetCoefficient(x[i][q], float(w) if np.isfinite(w) else 1e12)
    obj.SetMinimization()

    status = solver.Solve()
    if status not in (pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE):
        return None, False
    asg = np.array(
        [max(range(P), key=lambda q: x[i][q].solution_value()) for i in range(n)],
        dtype=int,
    )
    return asg, status == pywraplp.Solver.OPTIMAL


def _solve_greedy(omega: np.ndarray, size: np.ndarray, budget: float,
                  forced: np.ndarray, hp_index: int):
    """Glouton lagrangien : dégrade par meilleur ratio octets/qualité.

    Sens **inverse** de celui du v1 : on part de la meilleure qualité
    admissible et on descend tant que le budget est dépassé, ce qui garantit la
    terminaison et la faisabilité (la faisabilité ayant été vérifiée en amont).
    """
    n, P = omega.shape

    # Départ : meilleure qualité par couche (Ω minimal), soit en pratique le
    # format le plus large.
    asg = np.array(
        [hp_index if forced[i] else int(np.argmin(np.where(np.isfinite(omega[i]),
                                                           omega[i], np.inf)))
         for i in range(n)],
        dtype=int,
    )
    total = float(sum(size[i, asg[i]] for i in range(n)))

    if total <= budget:
        return asg, False

    # Chaque étape choisit la dégradation d'un cran maximisant
    # (octets libérés) / (qualité perdue) — le ratio du sac à dos fractionnaire.
    import heapq

    def candidates(i):
        cur = asg[i]
        out = []
        for q in range(P):
            d_bytes = size[i, cur] - size[i, q]
            d_omega = omega[i, q] - omega[i, cur]
            if d_bytes > 0 and np.isfinite(d_omega):
                # d_omega ≥ 0 attendu ; on garde ratio = gain / coût
                # Epsilon robuste pour éviter instabilités numériques
                ratio = d_bytes / max(d_omega, 1e-15)
                out.append((-ratio, i, q))
        return out

    heap: List = []
    for i in range(n):
        if not forced[i]:
            for c in candidates(i):
                heapq.heappush(heap, c)

    while total > budget and heap:
        _, i, q = heapq.heappop(heap)
        if forced[i] or size[i, q] >= size[i, asg[i]]:
            continue  # entrée périmée
        total -= size[i, asg[i]] - size[i, q]
        asg[i] = q
        for c in candidates(i):
            heapq.heappush(heap, c)

    if total > budget:
        raise InfeasibleBudget(
            f"glouton bloqué à {total / 1e9:.3f} Go pour un budget de "
            f"{budget / 1e9:.3f} Go"
        )
    return asg, False


def solve(
    omega: np.ndarray,
    size: np.ndarray,
    budget: float,
    forced: np.ndarray,
    hp_index: int,
    solver: str = "auto",
):
    """Résout l'allocation de précision.

    Args:
        omega:  (n, P) coût qualité.
        size:   (n, P) octets.
        budget: octets disponibles pour les poids.
        forced: (n,) booléens — couches contraintes en haute précision.
        hp_index: colonne du format haute précision pour les couches forcées.
        solver: 'auto' | 'scipy' | 'ortools' | 'greedy'.

    Returns:
        (assignation (n,), nom_du_solveur, optimal: bool)

    Raises:
        InfeasibleBudget: si aucune assignation ne tient dans le budget.
    """
    _feasibility_check(size, forced, hp_index, budget, omega)

    chain = {
        "auto": ["scipy", "ortools", "greedy"],
        "scipy": ["scipy", "greedy"],
        "ortools": ["ortools", "scipy", "greedy"],
        "greedy": ["greedy"],
    }[solver]

    for name in chain:
        if name == "scipy":
            try:
                asg, opt = _solve_scipy(omega, size, budget, forced, hp_index)
            except (ImportError, MemoryError):
                # HiGHS peut échouer par manque de mémoire sur de très gros
                # problèmes (des milliers de tenseurs × formats) sans que ce
                # soit un signe d'infaisabilité : on tente le solveur suivant
                # au lieu de laisser planter tout l'appelant.
                continue
        elif name == "ortools":
            try:
                asg, opt = _solve_ortools(omega, size, budget, forced, hp_index)
            except MemoryError:
                continue
        else:
            asg, opt = _solve_greedy(omega, size, budget, forced, hp_index)
        if asg is not None:
            return asg, name, opt

    raise InfeasibleBudget("aucun solveur n'a produit de solution")


# ─────────────────────────────────────────────────────────────────────────────
# API de haut niveau
# ─────────────────────────────────────────────────────────────────────────────


def plan_layers(
    layers: Sequence[LayerSpec],
    caps: hw.GPUCaps,
    vram_budget_gb: Optional[float] = None,
    candidate_formats: Optional[Sequence[str]] = None,
    imatrix: Optional[Dict[str, np.ndarray]] = None,
    ctx_len: int = 4096,
    n_blocks: Optional[int] = None,
    n_kv_heads: Optional[int] = None,
    head_dim: Optional[int] = None,
    kv_format: str = "F16",
    overhead_fraction: float = 0.05,
    solver: str = "auto",
    measure: bool = True,
    max_rel_error: Optional[float] = None,
) -> Plan:
    """Construit un plan de quantification complet.

    Args:
        layers:            couches à planifier.
        caps:              cible matérielle.
        vram_budget_gb:    budget total ; par défaut la VRAM de `caps`.
        candidate_formats: formats envisagés ; par défaut ceux que `caps`
                           exécute efficacement.
        imatrix:           statistiques d'activation (llama.cpp `--imatrix`).
        ctx_len:           contexte pour dimensionner le cache KV.
        n_blocks:          nombre de blocs transformer (déduit des noms sinon).
        n_kv_heads, head_dim: géométrie KV ; si absents, le cache KV est
                           ignoré et une note le signale.
        kv_format:         format du cache KV.
        overhead_fraction: marge pour la fragmentation et les tampons CUDA.
        solver:            voir `solve`.
        measure:           False pour planifier sans les poids (démo).
        max_rel_error:     plafond d'erreur relative par couche. Interdit tout
                           format dépassant ce seuil, ce qui garantit une borne
                           de qualité *par couche* que la seule minimisation de
                           la somme ne donne pas (une somme faible peut cacher
                           une couche massacrée). Passer 0.05 pour « aucune
                           couche au-delà de 5 % d'erreur ». Sans effet si les
                           poids ne sont pas chargés.

    Returns:
        `Plan`.

    Raises:
        InfeasibleBudget: budget intenable, ou plafond de qualité
            incompatible avec le budget.
    """
    layers = list(layers)
    if not layers:
        raise ValueError("aucune couche à planifier")

    if candidate_formats is None:
        candidate_formats = hw.supported_formats(caps)
    candidate_formats = [fmts.canonical(f) for f in candidate_formats]

    # Colonne « haute précision » pour les couches contraintes.
    hp_index = next(
        (i for i, f in enumerate(candidate_formats) if f in ("F16", "BF16", "F32")),
        0,
    )

    omega, size, measured = sensitivity_matrix(
        layers, candidate_formats, imatrix=imatrix, measure=measure
    )
    forced = np.array([l.forced for l in layers], dtype=bool)

    notes: List[str] = []

    # Plafond de qualité par couche : on rend inadmissibles les formats trop
    # dégradants, en gardant toujours au moins le format le plus large.
    if max_rel_error is not None:
        if not measure:
            notes.append(
                "max_rel_error ignoré : les poids ne sont pas chargés, "
                "l'erreur ne peut pas être mesurée."
            )
        else:
            n_blocked = 0
            for i, spec in enumerate(layers):
                if forced[i] or spec.weights is None or not spec.weights.size:
                    continue
                for q, fname in enumerate(candidate_formats):
                    if q == hp_index or not np.isfinite(omega[i, q]):
                        continue
                    if fmts.relative_error(spec.weights, fname) > max_rel_error:
                        omega[i, q] = np.inf
                        n_blocked += 1
            if n_blocked:
                notes.append(
                    f"plafond qualité {max_rel_error:.1%} : {n_blocked} "
                    f"combinaisons (couche, format) écartées."
                )
    total_gb = vram_budget_gb if vram_budget_gb is not None else caps.vram_gb
    if not total_gb or total_gb <= 0:
        raise ValueError(
            "budget VRAM inconnu : passez `vram_budget_gb` explicitement "
            f"(la cible {caps.name!r} déclare {caps.vram_gb} Go)"
        )
    total_bytes = float(total_gb) * 1e9

    # ── Cache KV ─────────────────────────────────────────────────────────────
    if n_blocks is None:
        from .sensitivity import block_index

        seen = [block_index(l.name) for l in layers]
        seen = [b for b in seen if b is not None]
        n_blocks = (max(seen) + 1) if seen else None

    kv = 0.0
    if n_blocks and n_kv_heads and head_dim:
        kv = kv_cache_bytes(n_blocks, n_kv_heads, head_dim, ctx_len, kv_format)
    else:
        notes.append(
            "cache KV non compté : géométrie inconnue (n_blocks/n_kv_heads/"
            "head_dim). Le budget poids est donc optimiste."
        )

    # Activations en décodage batch 1 : dominées par le plus grand tenseur
    # intermédiaire, plus les tampons de calcul de ggml. Ordre de grandeur
    # quelques dizaines de Mo, sans commune mesure avec les poids.
    max_row = max((max(l.shape) if len(l.shape) else 0) for l in layers)
    act = 4.0 * float(max_row) * 4.0

    budget = MemoryBudget(
        total=total_bytes,
        kv_cache=kv,
        activations=act,
        overhead=total_bytes * overhead_fraction,
    )
    if budget.weights <= 0:
        raise InfeasibleBudget(
            f"le cache KV ({kv / 1e9:.2f} Go à ctx={ctx_len}) et la marge "
            f"consomment déjà tout le budget de {total_gb:.1f} Go"
        )

    asg, solver_used, optimal = solve(
        omega, size, budget.weights, forced, hp_index, solver=solver
    )

    entries: List[PlanEntry] = []
    for i, spec in enumerate(layers):
        q = int(asg[i])
        fname = candidate_formats[q]
        rel = (
            fmts.relative_error(spec.weights, fname)
            if (measure and spec.weights is not None and spec.weights.size)
            else float("nan")
        )
        entries.append(
            PlanEntry(
                name=spec.name,
                shape=list(spec.shape),
                cls=spec.cls,
                format=fname,
                bytes=float(size[i, q]),
                omega=float(omega[i, q]),
                rel_error=float(rel),
                forced=bool(forced[i]),
                measured=bool(measured[i]),
                alpha=float(spec.alpha),
            )
        )

    if not measured.all():
        notes.append(
            f"{int((~measured).sum())}/{len(layers)} couches planifiées sans "
            "leurs poids : Ω vient d'un modèle analytique, pas d'une mesure."
        )
    if not optimal:
        notes.append(
            f"solveur '{solver_used}' : solution admissible non prouvée optimale."
        )

    total_bytes_used = float(sum(e.bytes for e in entries))
    if budget.weights > 0 and total_bytes_used < 0.85 * budget.weights:
        slack_gb = (budget.weights - total_bytes_used) / 1e9
        notes.append(
            f"budget poids sous-utilisé : {total_bytes_used / 1e9:.2f} Go utilisés sur "
            f"{budget.weights / 1e9:.2f} Go disponibles ({slack_gb:.2f} Go de marge). "
            "Ce plan minimise la perte de qualité, pas la taille du fichier : si un "
            "format plus large (voire non quantifié) tient déjà dans le budget, il est "
            "choisi tel quel, même s'il reste de la marge. En décodage, la latence est "
            "proportionnelle aux octets lus (cf. d2.hardware) : pour gagner en tokens/s, "
            "réduisez vram_budget_gb (ou --budget) pour forcer une compression plus "
            "agressive, quitte à accepter un peu plus d'erreur de quantification."
        )

    return Plan(
        entries=entries,
        budget=budget,
        solver=solver_used,
        optimal=optimal,
        total_bytes=float(sum(e.bytes for e in entries)),
        total_omega=float(sum(e.omega for e in entries)),
        gpu=caps.name,
        notes=notes,
    )
