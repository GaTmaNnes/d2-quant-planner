"""
d2.cli — Interface en ligne de commande
========================================

Implementation unique du CLI. `d2_rtx_gguf_profiler.py` a la racine delegue
ici, ce qui evite la duplication qui avait produit quatre pipelines
divergents dans le v1.

Point d'entree installe : `d2-plan` (voir pyproject.toml).
"""

from __future__ import annotations

import argparse
import sys
import time
from typing import Optional

import d2
from d2 import console


def _progress(i: int, total: int, name: str) -> None:
    if total and (i % 25 == 0 or i == total - 1):
        pct = (i + 1) / total * 100
        sys.stdout.write(f"\r  Lecture {i + 1}/{total} ({pct:5.1f} %)  {name[:44]:<44}")
        sys.stdout.flush()
        if i == total - 1:
            sys.stdout.write("\n")


def _spectral_report(layers, limit: int = 15) -> str:
    """Diagnostic spectral. Explicitement non décisionnel."""
    rows = [l for l in layers if l.alpha == l.alpha]  # non-NaN
    if not rows:
        return (
            "  Aucun exposant spectral exploitable.\n"
            "  (Le v1 aurait renvoyé 1.0 ou 1.5 dans ce cas — 202 des 274\n"
            "   valeurs de alpha_w_report.json sont ce plancher.)"
        )
    rows.sort(key=lambda l: l.alpha)
    out = [
        "  Diagnostic spectral (Martin & Mahoney 2021) — indicatif, "
        "n'entre pas dans la decision :",
        "    alpha in [2, 4] : couche bien entrainee",
        "    alpha < 2       : queue tres lourde, fortement correlee",
        "    alpha > 6       : proche d'une matrice aleatoire",
        "",
        f"  {'Tenseur':<46} {'alpha':>8} {'classe':>10}",
        "  " + "-" * 66,
    ]
    for l in rows[:limit]:
        out.append(f"  {l.name[:46]:<46} {l.alpha:>8.3f} {l.cls:>10}")
    if len(rows) > limit:
        out.append(f"  ... {len(rows) - limit} autres")
    n_ok = len(rows)
    out.append(f"  {n_ok}/{len(layers)} couches avec un ajustement exploitable.")
    return "\n".join(out)


def main() -> int:
    console.setup()
    p = argparse.ArgumentParser(
        description="Scanner GGUF et planificateur de quantification D2",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("model", nargs="?", help="fichier .gguf ou .safetensors")
    p.add_argument("--demo", action="store_true",
                   help="modèle synthétique, sans fichier")
    p.add_argument("--gpu-target", default=None, metavar="GPU",
                   help=f"cible ({', '.join(sorted(d2.GPU_PROFILES))}) ; "
                        "détection automatique si omis")
    p.add_argument("--budget", type=float, default=None,
                   help="budget VRAM en Go (défaut : celui de la cible)")
    p.add_argument("--ctx", type=int, default=4096,
                   help="contexte en tokens, pour le cache KV (défaut : 4096)")
    p.add_argument("--kv-format", default="F16",
                   help="format du cache KV (F16, Q8_0, ...)")
    p.add_argument("--max-rel-error", type=float, default=None,
                   help="plafond d'erreur relative par couche, ex. 0.05")
    p.add_argument("--imatrix", default=None,
                   help="matrice d'importance llama.cpp (pondère l'erreur "
                        "par les statistiques d'activation)")
    p.add_argument("--formats", default=None,
                   help="liste de formats séparés par des virgules "
                        "(défaut : ceux supportés par la cible)")
    p.add_argument("--spectral", action="store_true",
                   help="calcule le diagnostic spectral alpha (coûteux)")
    p.add_argument("--solver", default="auto",
                   choices=["auto", "scipy", "ortools", "greedy"])
    p.add_argument("--target", default="llamacpp",
                   choices=["llamacpp", "tensorrt", "both"],
                   help="format d'export (défaut : llamacpp)")
    p.add_argument("--out", default="rtx_quant_plan.json",
                   help="fichier JSON de sortie")
    p.add_argument("--llamacpp-out", default=None,
                   help="écrit aussi le plan au format llama.cpp")
    p.add_argument("--tensorrt-out", default="tensorrt_plan.json",
                   help="fichier de sortie TensorRT-LLM (avec --target tensorrt)")
    p.add_argument("--quiet", action="store_true",
                   help="pas de tableau couche par couche")
    p.add_argument("--limit", type=int, default=25,
                   help="lignes du tableau (0 = toutes)")
    args = p.parse_args()

    # ── Cible ────────────────────────────────────────────────────────────────
    try:
        caps = d2.get_profile(args.gpu_target) if args.gpu_target else d2.detect_gpu()
    except KeyError as exc:
        print(f"  [!] {exc}")
        return 2

    print("=" * 72)
    print("  D2 — Scanner GGUF / planificateur de quantification")
    print(f"  Cible : {caps.name} [{caps.sm_str}]  {caps.vram_gb:.0f} Go  "
          f"{caps.bw_gbs:.0f} Go/s")
    print(f"  Caps  : BF16={caps.bf16}  INT8={caps.int8_tc}  FP8={caps.fp8}  "
          f"FP4={caps.fp4}")
    print("=" * 72)

    # ── Chargement ───────────────────────────────────────────────────────────
    t0 = time.time()
    if args.demo or not args.model:
        print("\n  [DEMO] modèle synthétique type Llama-3-8B")
        layers, info = d2.synthetic_model()
    else:
        src = args.model
        try:
            if src.lower().endswith(".gguf"):
                print(f"\n  Lecture de {src}")
                layers, info = d2.load_gguf(
                    src, with_spectral=args.spectral,
                    progress=None if args.quiet else _progress)
            else:
                layers, info = d2.load_safetensors(
                    src, with_spectral=args.spectral)
        except (FileNotFoundError, ImportError) as exc:
            print(f"  [!] {exc}")
            return 2

    print(f"  {len(layers)} tenseurs planifiables"
          f"  ({time.time() - t0:.1f} s)")
    if info.get("skipped"):
        print(f"  {len(info['skipped'])} tenseurs ignorés (1-D, trop petits "
              f"ou type non décodable)")
    for key in ("arch", "n_blocks", "n_kv_heads", "head_dim"):
        if info.get(key):
            print(f"  {key:<12}: {info[key]}")

    # ── imatrix ──────────────────────────────────────────────────────────────
    imatrix = None
    if args.imatrix:
        try:
            imatrix = d2.load_imatrix(args.imatrix)
            print(f"  imatrix     : {len(imatrix)} tenseurs pondérés "
                  f"(objectif GPTQ/AWQ)")
        except (OSError, ValueError) as exc:
            print(f"  [!] imatrix ignorée : {exc}")

    # ── Planification ────────────────────────────────────────────────────────
    formats = args.formats.split(",") if args.formats else None
    measure = any(l.weights is not None for l in layers)
    try:
        plan = d2.plan_layers(
            layers, caps,
            vram_budget_gb=args.budget,
            candidate_formats=formats,
            imatrix=imatrix,
            ctx_len=args.ctx,
            kv_format=args.kv_format,
            solver=args.solver,
            measure=measure,
            max_rel_error=args.max_rel_error,
            **d2.kv_geometry(info),
        )
    except d2.InfeasibleBudget as exc:
        print(f"\n  [!] Budget intenable\n      {exc}")
        return 1
    except (ValueError, KeyError) as exc:
        print(f"\n  [!] {exc}")
        return 2

    print()
    print(d2.summarize(plan, caps, ctx_len=args.ctx))

    if not args.quiet:
        print()
        print(d2.layer_table(plan, limit=args.limit or None))

        bottlenecks = d2.detect_bottlenecks(plan.entries, caps, ctx_len=args.ctx)
        print()
        print("  Goulots d'etranglement (roofline par bloc) :")
        for h in d2.optimization_hints(bottlenecks):
            print(f"    {h}")

    if args.spectral:
        print()
        print(_spectral_report(layers))

    # ── Exports ──────────────────────────────────────────────────────────────
    d2.export_json(plan, args.out)
    print(f"\n  Plan JSON        : {args.out}")

    if args.target in ("tensorrt", "both"):
        trt = d2.export_tensorrt_llm(plan, out_path=args.tensorrt_out)
        print(f"  Plan TensorRT-LLM: {args.tensorrt_out}")
        print(f"    quant_algo     : {trt['quant_config']['quant_algo']}")
        print(f"    exclusions     : {len(trt['quant_config']['exclude_modules'])} modules")
        if trt["unsupported_by_trt"]:
            print(f"    [!] {len(trt['unsupported_by_trt'])} tenseurs sans "
                  "equivalent TensorRT")
        print("    Note : la quantification par couche se declare dans le "
              "quant_config du checkpoint,")
        print("           pas en option de trtllm-build "
              "(--per_layer_precision n'existe pas).")
        if args.target == "tensorrt":
            return 0

    payload = d2.export_llama_cpp(
        plan,
        input_gguf=args.model or "model-f16.gguf",
        output_gguf="model-d2.gguf",
        json_path=args.llamacpp_out,
    )
    if args.llamacpp_out:
        print(f"  Plan llama.cpp   : {args.llamacpp_out}")
    print(f"\n  Commande llama-quantize (type de base : {payload['base_type']}) :")
    lines = payload["command"].split("\n")
    for line in lines[:14]:
        print(f"    {line}")
    if len(lines) > 14:
        print(f"    ... ({len(lines) - 14} lignes supplémentaires, "
              f"voir {args.llamacpp_out or args.out})")
    if payload["unmapped"]:
        print(f"\n  [!] {len(payload['unmapped'])} tenseurs sans correspondance "
              "GGUF connue : ils ne sont pas couverts par la commande.")
    if payload["unsupported"]:
        print(f"  [!] {len(payload['unsupported'])} tenseurs dans un format sans "
              "équivalent ggml (NVFP4) : passez par TensorRT-LLM.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
