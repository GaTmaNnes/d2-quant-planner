"""
d2.hardware — Capacités GPU et modèle roofline
===============================================

Corrige trois défauts du v1 :

1. **Comparaison de compute capability.** Le v1 testait
   ``sm[0] >= 7 and sm[1] >= 5`` pour INT8, ce qui appliquait la condition sur
   le *minor* indépendamment du *major* : A100 (8,0), H100 (9,0) et Blackwell
   (12,0) étaient tous déclarés sans INT8 ni INT4. On compare désormais les
   tuples, comme il se doit.

2. **Blackwell absent.** Le README annonçait « SM61 à SM120 » et deux scripts
   de build ciblaient une RTX 5070, mais aucun profil sm_120 n'existait.

3. **Roofline sans bande passante réelle.** Le v1 utilisait des constantes
   arbitraires (`BW = 50e9`, « peak Watt ~ 200 TFLOPS »), et sa latence
   « mesurée » était `m*n*bpe/1000`, soit une bande passante implicite de
   1 Go/s. Les profils portent maintenant la bande passante mémoire et le
   pic FLOPS constructeur.

Sur le décodage auto-régressif (batch 1, une passe par token), une couche
linéaire est **toujours** limitée par la mémoire : elle lit m·n poids pour
2·m·n FLOP, soit une intensité arithmétique de ~1 FLOP/octet, très en deçà du
point d'inflexion (~200 sur une RTX 4090). C'est ce qui justifie que réduire
les octets lus est le levier de vitesse dominant — et pourquoi la contrainte
mémoire du planificateur capture déjà l'essentiel du gain de débit.

Références
----------
- Williams, Waterman & Patterson, "Roofline: an insightful visual performance
  model", CACM 52(4), 2009.
- NVIDIA CUDA C Programming Guide, tableau des compute capabilities.
- NVIDIA Blackwell Architecture Whitepaper (2024) pour NVFP4 / sm_100 / sm_120.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Tuple

__all__ = [
    "GPUCaps",
    "GPU_PROFILES",
    "detect_gpu",
    "get_profile",
    "supported_formats",
    "decode_latency_s",
    "roofline_regime",
]


@dataclass
class GPUCaps:
    """Capacités d'une cible d'exécution.

    Attributes:
        name:        libellé lisible.
        sm:          compute capability (major, minor). (0, 0) pour un CPU.
        vram_gb:     mémoire disponible en Go (base 10, comme les constructeurs).
        bw_gbs:      bande passante mémoire crête en Go/s.
        peak_tflops: pic FP16/BF16 dense en TFLOPS (tensor cores).
        available:   True si c'est un vrai GPU détecté ou un profil GPU.
        bw_efficiency: fraction de la bande passante crête réellement atteinte
                     en décodage. 0.75–0.85 est la plage mesurée usuelle sur
                     les GEMV de llama.cpp ; par défaut 0.80.
    """

    name: str
    sm: Tuple[int, int]
    vram_gb: float
    bw_gbs: float
    peak_tflops: float
    available: bool = True
    bw_efficiency: float = 0.80

    # ── Capacités dérivées de la compute capability ──────────────────────────
    @property
    def sm_str(self) -> str:
        return "cpu" if self.sm == (0, 0) else f"sm_{self.sm[0]}{self.sm[1]}"

    @property
    def fp16_tc(self) -> bool:
        """Tensor cores FP16 : Volta et au-delà."""
        return self.sm >= (7, 0)

    @property
    def bf16(self) -> bool:
        """BF16 natif : Ampere et au-delà."""
        return self.sm >= (8, 0)

    @property
    def int8_tc(self) -> bool:
        """Tensor cores INT8 : Turing et au-delà."""
        return self.sm >= (7, 5)

    @property
    def fp8(self) -> bool:
        """Tensor cores FP8 (E4M3/E5M2) : Ada (8.9), Hopper (9.0), Blackwell."""
        return self.sm >= (8, 9)

    @property
    def fp4(self) -> bool:
        """Tensor cores FP4/NVFP4 : Blackwell uniquement (10.0, 12.0)."""
        return self.sm >= (10, 0)

    @property
    def int4_tc(self) -> bool:
        """Tensor cores INT4 natifs (`mma.s4`) : Turing → Ada seulement.

        L'instruction a été retirée à partir de Hopper (9.0). Ne pas confondre
        avec l'INT4 *weight-only* (AWQ, Marlin, k-quants), qui n'en a pas besoin.
        """
        return (7, 5) <= self.sm < (9, 0)

    @property
    def dp4a(self) -> bool:
        """DP4A (produit scalaire entier 4×int8) : Pascal (6.1) et au-delà.

        C'est l'instruction qu'utilisent les kernels MMQ de llama.cpp pour les
        k-quants (Q4_K, Q5_K, Q6_K, Q8_0, ...) — pas des tensor cores. Les GPU
        Pascal (GTX 10xx) n'ont aucun tensor core mais exécutent ces formats
        couramment et efficacement en pratique ; les exclure sous prétexte
        qu'ils manquent de tensor cores FP16 (`fp16_tc`, Volta+) est une
        confusion entre deux mécanismes matériels différents.
        """
        return self.sm >= (6, 1)

    @property
    def marlin(self) -> bool:
        """Kernel Marlin (INT4 AWQ/GPTQ haute performance) : Ampere (8.0) et au-delà.

        Marlin (IST-DASLab) exploite intensivement les tensor cores FP16 en
        pipeline profond et exige explicitement compute capability ≥ 8.0.
        Turing/Volta (7.x) ont des tensor cores FP16 (`fp16_tc`) mais pas les
        capacités qu'exige Marlin spécifiquement.
        """
        return self.sm >= (8, 0)

    @property
    def int4_weight_only(self) -> bool:
        """INT4 weight-only générique (k-quants, MMQ) : DP4A suffit (Pascal+).

        Pour le kernel Marlin spécifiquement (format `INT4_AWQ`), voir
        `marlin`, qui a une exigence plus stricte (Ampere+).
        """
        return self.dp4a

    def to_dict(self) -> Dict:
        d = asdict(self)
        d.update(
            sm_str=self.sm_str, bf16=self.bf16, int8_tc=self.int8_tc,
            fp8=self.fp8, fp4=self.fp4, int4_tc=self.int4_tc,
            dp4a=self.dp4a, marlin=self.marlin,
            int4_weight_only=self.int4_weight_only,
        )
        return d


def _p(name, sm, vram, bw, tf):
    return GPUCaps(name=name, sm=sm, vram_gb=vram, bw_gbs=bw, peak_tflops=tf)


#: Profils permettant de planifier sans le matériel cible.
#: Bande passante et VRAM : spécifications constructeur. `peak_tflops` = FP16
#: dense avec accumulation FP32, sans le facteur ×2 « sparsity » marketing.
GPU_PROFILES: Dict[str, GPUCaps] = {
    # ── Blackwell (sm_120 GeForce, sm_100 datacenter) ────────────────────────
    "rtx5090": _p("RTX 5090",     (12, 0),  32.0, 1792.0, 209.0),
    "rtx5080": _p("RTX 5080",     (12, 0),  16.0,  960.0, 112.0),
    "rtx5070ti": _p("RTX 5070 Ti", (12, 0), 16.0,  896.0,  88.0),
    "rtx5070": _p("RTX 5070",     (12, 0),   8.0,  672.0,  61.0),
    "b200":    _p("B200",         (10, 0), 192.0, 8000.0, 2250.0),
    # ── Ada (sm_89) ──────────────────────────────────────────────────────────
    "rtx4090": _p("RTX 4090",     (8, 9),   24.0, 1008.0, 165.0),
    "rtx4080": _p("RTX 4080",     (8, 9),   16.0,  717.0, 195.0),
    "rtx4070": _p("RTX 4070",     (8, 9),   12.0,  504.0,  59.0),
    "l40s":    _p("L40S",         (8, 9),   48.0,  864.0, 181.0),
    # ── Hopper (sm_90) ───────────────────────────────────────────────────────
    "h100":    _p("H100 SXM",     (9, 0),   80.0, 3350.0, 989.0),
    # ── Ampere (sm_80 datacenter, sm_86 GeForce) ─────────────────────────────
    "a100":    _p("A100 80GB",    (8, 0),   80.0, 2039.0, 312.0),
    "rtx3090": _p("RTX 3090",     (8, 6),   24.0,  936.0,  71.0),
    "rtx3080": _p("RTX 3080 10GB", (8, 6),  10.0,  760.0,  59.0),
    "a6000":   _p("RTX A6000",    (8, 6),   48.0,  768.0,  77.0),
    # ── Turing (sm_75) ───────────────────────────────────────────────────────
    "rtx2080": _p("RTX 2080",     (7, 5),    8.0,  448.0,  40.0),
    # ── Pascal (sm_61) : pas de tensor core ──────────────────────────────────
    "gtx1080": _p("GTX 1080",     (6, 1),    8.0,  320.0,   0.0),
    "gtx1050ti": _p("GTX 1050 Ti", (6, 1),   4.0,  112.0,   0.0),
    "gtx1050": _p("GTX 1050",     (6, 1),    2.0,  112.0,   0.0),
    # ── CPU ──────────────────────────────────────────────────────────────────
    "cpu":     GPUCaps("CPU", (0, 0), 0.0, 50.0, 0.0, available=False,
                       bw_efficiency=0.60),
}


def detect_gpu(index: int = 0) -> GPUCaps:
    """Détecte le GPU présent via torch, sinon retourne le profil CPU.

    Args:
        index: indice du device CUDA.

    Returns:
        `GPUCaps`. Les capacités sont dérivées de la compute capability réelle
        par comparaison de tuples (le bug principal du v1).
    """
    try:
        import torch
    except ImportError:
        return GPU_PROFILES["cpu"]
    if not torch.cuda.is_available():
        return GPU_PROFILES["cpu"]

    props = torch.cuda.get_device_properties(index)
    sm = (props.major, props.minor)
    # Bande passante non exposée par torch : on reprend celle d'un profil de
    # même compute capability, à défaut une valeur prudente.
    same_sm = [p for p in GPU_PROFILES.values() if p.sm == sm and p.available]
    bw = max((p.bw_gbs for p in same_sm), default=500.0)
    tf = max((p.peak_tflops for p in same_sm), default=50.0)
    return GPUCaps(
        name=props.name,
        sm=sm,
        vram_gb=props.total_memory / 1e9,
        bw_gbs=bw,
        peak_tflops=tf,
        available=True,
    )


def get_profile(name: str) -> GPUCaps:
    """Récupère un profil par nom.

    Raises:
        KeyError: si le profil est inconnu — le v1 affichait un avertissement
            et poursuivait silencieusement avec la mauvaise cible.
    """
    key = name.lower().replace(" ", "").replace("-", "")
    if key not in GPU_PROFILES:
        raise KeyError(
            f"profil GPU inconnu : {name!r}. Disponibles : {sorted(GPU_PROFILES)}"
        )
    return GPU_PROFILES[key]


def supported_formats(caps: GPUCaps) -> List[str]:
    """Formats exécutables efficacement sur cette cible, du plus large au plus compact.

    Les k-quants (kernel MMQ) sont retenus dès DP4A (Pascal, 6.1+) : ce sont
    des kernels à produit scalaire entier, pas des tensor cores. INT4_AWQ
    (kernel Marlin) est plus exigeant et requiert Ampere (8.0+). Confondre
    les deux exclurait à tort Pascal (GTX 10xx, cible très courante pour
    l'inférence quantifiée locale) des k-quants. NVFP4 exige du vrai
    matériel Blackwell.
    """
    out = ["F16"]
    if caps.bf16:
        out.append("BF16")
    out.append("Q8_0")
    if caps.int8_tc:
        out.append("INT8")
    if caps.int4_weight_only or not caps.available:
        out += ["Q6_K", "Q5_K", "Q4_K"]
    if caps.marlin or not caps.available:
        out.append("INT4_AWQ")
    if caps.fp4:
        out.append("NVFP4")
    # Q3_K/Q2_K : disponibles partout, mais très dégradants ; on les laisse
    # au planificateur, qui ne les choisira que sous forte pression mémoire.
    out += ["Q3_K", "Q2_K"]
    seen, uniq = set(), []
    for f in out:
        if f not in seen:
            seen.add(f)
            uniq.append(f)
    return uniq


def decode_latency_s(n_bytes: float, caps: GPUCaps, n_elements: int = 0,
                     batch: int = 1) -> float:
    """Latence roofline d'une couche linéaire, en secondes.

    t = max(octets_lus / BW_effective, FLOP / FLOPS_crête)

    Contrairement au v1, `batch` est bien propagé : c'est la seule variable qui
    fait basculer du régime mémoire au régime compute. À batch 1 le terme
    mémoire domine toujours, ce qui rendait le mode « prefill » du v1 rigoureusement
    identique au mode « decode ».
    """
    bw = caps.bw_gbs * 1e9 * caps.bw_efficiency
    t_mem = n_bytes / max(bw, 1.0)
    if caps.peak_tflops <= 0 or n_elements <= 0:
        return t_mem
    flops = 2.0 * n_elements * max(batch, 1)
    t_cmp = flops / (caps.peak_tflops * 1e12)
    return max(t_mem, t_cmp)


def roofline_regime(n_bytes: float, n_elements: int, caps: GPUCaps,
                    batch: int = 1) -> str:
    """'memory' ou 'compute' selon le terme dominant."""
    bw = caps.bw_gbs * 1e9 * caps.bw_efficiency
    t_mem = n_bytes / max(bw, 1.0)
    if caps.peak_tflops <= 0:
        return "memory"
    t_cmp = 2.0 * n_elements * max(batch, 1) / (caps.peak_tflops * 1e12)
    return "memory" if t_mem >= t_cmp else "compute"
