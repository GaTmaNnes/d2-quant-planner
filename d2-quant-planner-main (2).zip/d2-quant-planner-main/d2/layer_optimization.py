"""
d2.layer_optimization — Optimisation per-couche basée sur les activations réelles

Utilise les statistiques d'activation (imatrix) pour :
1. Quantifier les canaux peu activés de façon plus agressive
2. Protéger les canaux saillants
3. Ajuster la précision par bloc de sous-groupe
4. Minimiser la dégradation qualité par couche
"""

from __future__ import annotations

from typing import Optional, Tuple
import numpy as np

__all__ = ["saliency_aware_precision", "suggest_group_precision"]


def saliency_aware_precision(
    weights: np.ndarray,
    activation_stats: Optional[np.ndarray] = None,
    target_bits: float = 4.0,
    saliency_threshold: float = 0.1,
) -> np.ndarray:
    """Suggère la précision per-groupe basée sur la saillance des canaux.

    Args:
        weights: matrice de poids (out_features, in_features).
        activation_stats: E[x²] par canal d'entrée (optionnel).
        target_bits: bits cible (4 = Q4_K, 8 = Q8_0, etc).
        saliency_threshold: fraction du top K canaux à protéger.

    Returns:
        Tableau (out_features,) des bits recommandés par ligne.
    """
    if weights.ndim != 2:
        return np.full(weights.shape[0], target_bits, dtype=np.float32)

    out_features, in_features = weights.shape

    # Saillance = norme L2 pondérée par importance d'activation
    if activation_stats is not None:
        activation_stats = np.asarray(activation_stats, dtype=np.float32)
        if activation_stats.size == in_features:
            # Pondérer par √(E[x²])
            scale = np.sqrt(np.maximum(activation_stats, 0.0))
            saillance = np.linalg.norm(weights * scale[None, :], axis=1)
        else:
            saillance = np.linalg.norm(weights, axis=1)
    else:
        saillance = np.linalg.norm(weights, axis=1)

    # Seuil : top 10% des canaux
    threshold_percentile = (1 - saliency_threshold) * 100
    threshold_val = np.percentile(saillance, threshold_percentile)

    # Bits : +2 pour les saillants, baseline pour les autres
    bits = np.full(out_features, target_bits, dtype=np.float32)
    bits[saillance > threshold_val] = min(8.0, target_bits + 2.0)

    return bits


def suggest_group_precision(
    weights: np.ndarray,
    activation_stats: Optional[np.ndarray] = None,
    group_size: int = 128,
) -> Tuple[np.ndarray, float]:
    """Suggère la meilleure précision par groupe asymétrique.

    Args:
        weights: matrice de poids.
        activation_stats: E[x²] par canal d'entrée.
        group_size: taille du groupe (défaut AWQ/GPTQ).

    Returns:
        (precision_scores, average_bits) où precision_scores[g] ∈ {2,4,6,8}.
    """
    if weights.ndim != 2:
        return np.full(1, 4.0), 4.0

    out_features, in_features = weights.shape
    n_groups = (in_features + group_size - 1) // group_size

    # Heuristique : norme (saillance) de chaque groupe
    scores = np.zeros(n_groups, dtype=np.float32)

    for g in range(n_groups):
        start = g * group_size
        end = min((g + 1) * group_size, in_features)
        group_weights = weights[:, start:end]

        # Saillance (norme L2)
        if activation_stats is not None and activation_stats.size == in_features:
            scale = np.sqrt(np.maximum(activation_stats[start:end], 0.0))
            norms = np.linalg.norm(group_weights * scale[None, :], axis=1)
        else:
            norms = np.linalg.norm(group_weights, axis=1)

        # Score : norme moyenne normalisée
        scores[g] = norms.mean()

    # Mapper score → bits : normalisé par percentile
    norm_scores = (scores - scores.min()) / (scores.max() - scores.min() + 1e-10)
    bit_map = np.array([2.0, 4.0, 6.0, 8.0])
    precisions = bit_map[np.clip(np.round(norm_scores * 3).astype(int), 0, 3)]

    avg_bits = precisions.mean()
    return precisions, float(avg_bits)
