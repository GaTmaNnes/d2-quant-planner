"""
d2.spectral — Analyse spectrale correcte (Martin & Mahoney)
===========================================================

Ce module remplace les quatre implémentations divergentes de `alpha_w` du repo
v1. Trois corrections de fond :

1. **α n'est pas ``2 × pente``.**
   L'exposant α de Martin & Mahoney est celui de la *densité spectrale
   empirique* (ESD) des valeurs propres de X = WᵀW :

       ρ(λ) ∝ λ^(−α)   pour λ ∈ [λ_min, λ_max]

   Le repo v1 ajustait `log σ_i = −β log i + c` (décroissance en fonction du
   *rang*) puis posait `α = 2β`. Ces deux quantités ne sont pas égales. Si
   λ_i = C·i^(−γ) avec γ = 2β, alors le nombre de valeurs propres au-dessus de
   λ vaut N(λ) = (C/λ)^(1/γ), donc la queue de la CDF est en λ^(−1/γ) et

       ρ(λ) ∝ λ^(−(1 + 1/γ))     ⟹     α = 1 + 1/(2β)

   La fonction `alpha_from_index_slope` implémente cette conversion, et
   `test_spectral.py::test_alpha_conversion_matches_hill` la vérifie
   numériquement sur des spectres synthétiques.

2. **Estimateur de Hill + balayage de x_min** au lieu d'une régression
   linéaire sur tout le spectre. Une régression log-log sur *toutes* les
   valeurs propres mélange la partie « bulk » (Marchenko–Pastur, bruit) et la
   queue, ce qui biaise fortement α. On suit Clauset–Shalizi–Newman : on
   balaie x_min et on retient celui qui minimise la distance de Kolmogorov–
   Smirnov entre la queue empirique et la loi de puissance ajustée.

3. **Pas de plancher `max(α, 1.0)`.** Le clamp du v1 renvoyait exactement 1.0
   pour 202 des 274 tenseurs de `alpha_w_report.json`, c'est-à-dire qu'il
   masquait l'absence de signal derrière une valeur d'apparence plausible.
   Ici, un ajustement qui échoue renvoie `alpha=nan` et `ok=False` : l'appelant
   *doit* traiter le cas.

Interprétation (Martin & Mahoney 2021)
--------------------------------------
α ∈ [2, 4]  : couche bien entraînée, auto-régularisation à queue lourde.
α < 2       : queue très lourde, couche fortement corrélée / sur-entraînée.
α > 6       : proche d'une matrice aléatoire, couche sous-entraînée.

**Attention** : α mesure la *qualité d'entraînement*, pas la robustesse à la
quantification. Aucun travail publié n'établit de correspondance α → largeur de
bits. Le v1 utilisait α comme critère principal, dans deux directions opposées
selon le fichier. Ici α est exporté comme **diagnostic** et ne pèse par défaut
que marginalement dans le plan (cf. `d2.sensitivity`), qui s'appuie sur
l'erreur de quantification mesurée.

Références
----------
- Martin & Mahoney, "Implicit Self-Regularization in Deep Neural Networks",
  JMLR 22(165), 2021.
- Martin, Peng & Mahoney, "Predicting trends in the quality of state-of-the-art
  neural networks without access to training or testing data",
  Nature Communications 12, 4122 (2021).
- Hill, "A simple general approach to inference about the tail of a
  distribution", Annals of Statistics 3(5), 1975.
- Clauset, Shalizi & Newman, "Power-law distributions in empirical data",
  SIAM Review 51(4), 2009.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Optional

import numpy as np

__all__ = [
    "SpectralStats",
    "singular_values",
    "analyze",
    "alpha_hill",
    "alpha_from_index_slope",
    "index_slope",
    "stable_rank",
    "effective_rank",
    "spectral_entropy",
]


@dataclass
class SpectralStats:
    """Résultat d'une analyse spectrale.

    Attributes:
        alpha:      exposant ESD (Martin & Mahoney). `nan` si non estimable.
        alpha_ok:   True si l'ajustement a convergé sur assez de points.
        ks:         distance KS de l'ajustement loi de puissance (plus bas =
                    meilleur). `nan` si `alpha_ok` est False.
        xmin:       seuil de queue retenu (valeur propre).
        n_tail:     nombre de valeurs propres dans la queue ajustée.
        beta:       pente log-log σ_i vs i (grandeur du v1, conservée pour
                    comparaison et rétrocompatibilité).
        stable_rank:    ‖W‖_F² / ‖W‖₂².
        effective_rank: exp(entropie de Shannon des p_i = σ_i²/Σσ²).
        entropy:        entropie spectrale normalisée ∈ [0, 1].
        n_sv:       nombre de valeurs singulières utilisées.
        sampled:    True si la matrice a été sous-échantillonnée.
    """

    alpha: float
    alpha_ok: bool
    ks: float
    xmin: float
    n_tail: int
    beta: float
    stable_rank: float
    effective_rank: float
    entropy: float
    n_sv: int
    sampled: bool

    def to_dict(self) -> Dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# Valeurs singulières
# ─────────────────────────────────────────────────────────────────────────────


def singular_values(
    W: np.ndarray,
    max_dim: int = 4096,
    rng: Optional[np.random.Generator] = None,
):
    """Valeurs singulières de `W`, décroissantes.

    Pour les très grandes matrices on sous-échantillonne les **lignes**
    (canaux de sortie), ce qui préserve la loi de la queue spectrale tout en
    bornant le coût. Le v1 tentait un SVD randomisé dont les dimensions étaient
    incohérentes dès que la matrice était carrée, et rattrapait l'exception par
    un `return 1.5` silencieux.

    Args:
        W:       matrice 2-D (une matrice n-D est repliée en 2-D).
        max_dim: au-delà, sous-échantillonnage aléatoire des lignes.
        rng:     générateur (par défaut : graine fixe, résultat reproductible).

    Returns:
        (valeurs_singulières décroissantes, sampled: bool)
    """
    A = np.asarray(W, dtype=np.float32)
    if A.ndim == 1:
        A = A[None, :]
    elif A.ndim > 2:
        A = A.reshape(A.shape[0], -1)

    sampled = False
    if A.shape[0] > max_dim:
        g = rng or np.random.default_rng(0)
        idx = g.choice(A.shape[0], max_dim, replace=False)
        A = A[np.sort(idx)]
        sampled = True
    if A.shape[1] > max_dim:
        g = rng or np.random.default_rng(1)
        idx = g.choice(A.shape[1], max_dim, replace=False)
        A = A[:, np.sort(idx)]
        sampled = True

    s = np.linalg.svd(A, compute_uv=False)
    return np.sort(s)[::-1], sampled


# ─────────────────────────────────────────────────────────────────────────────
# Exposant α
# ─────────────────────────────────────────────────────────────────────────────


def alpha_hill(eigenvalues: np.ndarray, min_tail: int = 20):
    """Estime α par Hill + balayage de x_min minimisant la distance KS.

    Pour une queue λ_(1) ≥ … ≥ λ_(k) au-dessus de x_min = λ_(k+1) :

        α_Hill = 1 + k / Σ_{i=1..k} ln(λ_(i) / x_min)

    Args:
        eigenvalues: valeurs propres λ = σ² (ordre quelconque, > 0 filtrées).
        min_tail:    taille minimale de queue acceptée.

    Returns:
        (alpha, ks, xmin, n_tail). `alpha` vaut `nan` si le spectre est trop
        court ou dégénéré — aucun repli sur une constante.
    """
    lam = np.asarray(eigenvalues, dtype=np.float64)
    lam = np.sort(lam[np.isfinite(lam) & (lam > 0)])[::-1]
    n = lam.size
    if n < min_tail + 1:
        return float("nan"), float("nan"), float("nan"), 0

    best = (float("nan"), np.inf, float("nan"), 0)
    # On teste au plus 64 seuils, répartis log-uniformément sur les rangs.
    max_k = n - 1
    candidates = np.unique(
        np.geomspace(min_tail, max_k, num=min(64, max_k - min_tail + 1)).astype(int)
    )
    for k in candidates:
        xmin = lam[k]
        if xmin <= 0:
            continue
        tail = lam[:k]
        logs = np.log(tail / xmin)
        denom = float(logs.sum())
        if denom <= 0:
            continue
        alpha = 1.0 + k / denom

        # Distance KS entre la CDF empirique de la queue et la CDF théorique
        # P(X ≤ x) = 1 − (x/xmin)^(1−α)  (Clauset et al. 2009, éq. 3.9).
        x = np.sort(tail)
        cdf_emp = np.arange(1, k + 1, dtype=np.float64) / k
        cdf_fit = 1.0 - (x / xmin) ** (1.0 - alpha)
        ks = float(np.max(np.abs(cdf_emp - cdf_fit)))
        if ks < best[1]:
            best = (float(alpha), ks, float(xmin), int(k))

    if not np.isfinite(best[1]):
        return float("nan"), float("nan"), float("nan"), 0
    return best


def index_slope(sv: np.ndarray, cutoff: float = 0.01) -> float:
    """Pente β de log σ_i = −β log i + c (grandeur historique du repo v1).

    Conservée pour comparaison et pour les plans anciens. Ce n'est **pas** α.
    """
    s = np.asarray(sv, dtype=np.float64)
    s = s[s > 0]
    if s.size < 3:
        return float("nan")
    s = s[s > cutoff * s[0]]
    if s.size < 3:
        return float("nan")
    x = np.log(np.arange(1, s.size + 1, dtype=np.float64))
    y = np.log(s)
    return float(-np.polyfit(x, y, 1)[0])


def alpha_from_index_slope(beta: float) -> float:
    """Convertit la pente rang/valeur singulière β en exposant ESD α.

        λ_i ∝ i^(−2β)  ⟹  ρ(λ) ∝ λ^(−(1 + 1/(2β)))  ⟹  α = 1 + 1/(2β)

    Le v1 utilisait `α = 2β`, ce qui n'a pas de justification. Pour β = 0.5
    (spectre en 1/√i) la formule correcte donne α = 2.0 — le bas de la plage
    « bien entraîné » — là où `2β` donnait 1.0.
    """
    if not np.isfinite(beta) or beta <= 0:
        return float("nan")
    return 1.0 + 1.0 / (2.0 * beta)


# ─────────────────────────────────────────────────────────────────────────────
# Autres descripteurs spectraux
# ─────────────────────────────────────────────────────────────────────────────


def stable_rank(sv: np.ndarray) -> float:
    """Rang stable ‖W‖_F² / ‖W‖₂² ∈ [1, rang]."""
    s = np.asarray(sv, dtype=np.float64)
    s = s[s > 0]
    if s.size == 0 or s[0] == 0:
        return float("nan")
    return float(np.sum(s**2) / (s[0] ** 2))


def effective_rank(sv: np.ndarray) -> float:
    """Rang effectif exp(H) avec H l'entropie de p_i = σ_i²/Σσ².

    Roy & Vetterli, "The effective rank: a measure of effective
    dimensionality", EUSIPCO 2007. Le v1 utilisait (Σσ)²/Σσ², qui est le
    *participation ratio*, une grandeur différente (et le documentait comme
    « rang effectif »).
    """
    s = np.asarray(sv, dtype=np.float64)
    s = s[s > 0]
    if s.size == 0:
        return float("nan")
    p = s**2 / np.sum(s**2)
    p = p[p > 0]
    return float(np.exp(-np.sum(p * np.log(p))))


def spectral_entropy(sv: np.ndarray) -> float:
    """Entropie spectrale normalisée ∈ [0, 1] (1 = spectre plat)."""
    s = np.asarray(sv, dtype=np.float64)
    s = s[s > 0]
    if s.size < 2:
        return float("nan")
    p = s**2 / np.sum(s**2)
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)) / np.log(s.size))


def analyze(
    W: np.ndarray,
    max_dim: int = 4096,
    rng: Optional[np.random.Generator] = None,
) -> SpectralStats:
    """Analyse spectrale complète d'une matrice de poids.

    Un seul SVD est calculé, contre quatre dans `spectral_theory.SpectralIR`
    du v1.

    Args:
        W:       matrice de poids déquantifiée (float).
        max_dim: seuil de sous-échantillonnage.
        rng:     générateur pour le sous-échantillonnage.

    Returns:
        `SpectralStats`. Les champs non estimables valent `nan` (jamais une
        constante de repli).
    """
    sv, sampled = singular_values(W, max_dim=max_dim, rng=rng)
    sv = sv[np.isfinite(sv)]
    lam = sv**2

    alpha, ks, xmin, n_tail = alpha_hill(lam)
    return SpectralStats(
        alpha=alpha,
        alpha_ok=bool(np.isfinite(alpha)),
        ks=ks,
        xmin=xmin,
        n_tail=n_tail,
        beta=index_slope(sv),
        stable_rank=stable_rank(sv),
        effective_rank=effective_rank(sv),
        entropy=spectral_entropy(sv),
        n_sv=int(sv.size),
        sampled=sampled,
    )
