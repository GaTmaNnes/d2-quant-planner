"""
d2.report — Restitution textuelle des plans
============================================

Règle appliquée partout : **une valeur mesurée et une valeur estimée ne sont
jamais présentées de la même façon.** Le v1 titrait « Mesures reelles vs
Predictions » au-dessus de chiffres issus d'une formule fermée
(`lat = m*n*bpe/1000`), et son mode démo produisait des benchmarks synthétiques
sans le dire. Ici, toute grandeur non mesurée porte la mention `~` et les notes
du plan sont imprimées.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from . import formats as fmts
from . import hardware as hw
from .planner import Plan

__all__ = ["summarize", "layer_table", "distribution_bars"]


def _gb(x: float) -> str:
    return f"{x / 1e9:.3f} Go"


def distribution_bars(plan: Plan, width: int = 28) -> str:
    """Barres de répartition des formats, pondérées par la taille."""
    sizes = plan.size_by_format()
    counts = plan.distribution()
    total = sum(sizes.values()) or 1.0
    lines = [f"  {'Format':<10} {'Couches':>8} {'Taille':>11} {'%':>6}  "]
    lines.append("  " + "-" * (37 + width))
    for f in sorted(sizes, key=lambda k: -sizes[k]):
        pct = sizes[f] / total * 100
        bar = "#" * max(1, int(pct / 100 * width))
        lines.append(
            f"  {f:<10} {counts[f]:>8} {_gb(sizes[f]):>11} {pct:>5.1f}%  {bar}"
        )
    return "\n".join(lines)


def layer_table(plan: Plan, limit: Optional[int] = 20) -> str:
    """Tableau détaillé par couche."""
    rows = plan.entries[:limit] if limit else plan.entries
    out = [
        f"  {'#':>4}  {'Tenseur':<40} {'Classe':<10} {'Format':<9} "
        f"{'Taille':>10} {'err_rel':>9} {'Ω':>10}"
    ]
    out.append("  " + "-" * 98)
    for i, e in enumerate(rows):
        err = f"{e.rel_error:.4f}" if np.isfinite(e.rel_error) else "   ~n/a"
        flag = "*" if e.forced else (" " if e.measured else "~")
        out.append(
            f"  {i + 1:>4}{flag} {e.name[:40]:<40} {e.cls:<10} {e.format:<9} "
            f"{e.bytes / 1e9:>9.4f}G {err:>9} {e.omega:>10.3e}"
        )
    if limit and len(plan.entries) > limit:
        out.append(f"  ... {len(plan.entries) - limit} couches supplémentaires")
    out.append("  * = contrainte haute précision   ~ = estimé, non mesuré")
    return "\n".join(out)


def summarize(plan: Plan, caps: Optional[hw.GPUCaps] = None,
              ctx_len: Optional[int] = None) -> str:
    """Résumé textuel complet d'un plan."""
    b = plan.budget
    used_pct = plan.total_bytes / b.weights * 100 if b.weights > 0 else float("nan")
    n_measured = sum(1 for e in plan.entries if e.measured)

    lines = [
        "=" * 72,
        f"  D2 — Plan de quantification  ({plan.gpu})",
        "=" * 72,
        f"  Couches        : {len(plan.entries)}  "
        f"({n_measured} mesurées, {len(plan.entries) - n_measured} estimées)",
        f"  Solveur        : {plan.solver}"
        f"{' (optimum prouvé)' if plan.optimal else ' (admissible)'}",
        "",
        f"  Budget total   : {_gb(b.total)}",
        f"    cache KV     : {_gb(b.kv_cache)}"
        + (f"   ctx={ctx_len}" if ctx_len else ""),
        f"    activations  : {_gb(b.activations)}",
        f"    marge/frag   : {_gb(b.overhead)}",
        f"    -> poids     : {_gb(b.weights)}",
        "",
        f"  Poids utilises : {_gb(plan.total_bytes)}  ({used_pct:.1f} % du budget poids)",
        f"  Cout qualite   : {plan.total_omega:.4e}   (somme c_i*err_rel^2, plus bas = mieux)",
        f"  Transitions    : {plan.n_switches} changements de format",
        "",
        distribution_bars(plan),
    ]

    if caps is not None and caps.bw_gbs > 0:
        t_fp16 = hw.decode_latency_s(
            sum(e.bytes / fmts.bytes_per_weight(e.format) * 2.0 for e in plan.entries),
            caps,
        )
        t_plan = hw.decode_latency_s(plan.total_bytes, caps)
        lines += [
            "",
            "  Débit décodage (roofline, batch 1, limité par la mémoire) :",
            f"    F16 intégral : ~{1.0 / t_fp16:7.1f} tok/s",
            f"    ce plan      : ~{1.0 / t_plan:7.1f} tok/s   "
            f"(×{t_fp16 / t_plan:.2f})",
            "    ~ = borne théorique bande passante, pas une mesure.",
        ]

    if plan.notes:
        lines += ["", "  Notes :"]
        lines += [f"    - {n}" for n in plan.notes]

    return "\n".join(lines)
