"""
d2.validation — Validation et vérification de cohérence des plans

Valide que :
1. Les allocations de précision sont cohérentes
2. Les budgets mémoire sont respectés
3. Pas de dégradation qualité excessive
4. Les décisions de quantification minimisent vraiment l'erreur
"""

from __future__ import annotations

from typing import List, Optional, Tuple
import numpy as np

from . import formats as fmts
from . import hardware as hw

__all__ = [
    "validate_plan", "check_memory_budget", "check_quality_degradation",
    "suggest_improvements",
]


def validate_plan(entries: List, budget: float, soft_warn: bool = True) -> Tuple[bool, List[str]]:
    """Valide la cohérence d'un plan de quantification.

    Args:
        entries: liste de PlanEntry.
        budget: budget mémoire en octets.
        soft_warn: si True, retourne warning et continue ; sinon lève.

    Returns:
        (is_valid: bool, messages: List[str])
    """
    messages = []
    total = sum(e.bytes for e in entries)

    # Budget
    if total > budget:
        msg = f"Budget dépassé : {total / 1e9:.2f} Go > {budget / 1e9:.2f} Go"
        if soft_warn:
            messages.append(f"[!] {msg}")
        else:
            return False, [msg]

    # Formats invalides
    for e in entries:
        try:
            fmts.get(e.format)
        except KeyError:
            msg = f"{e.name}: format invalide {e.format!r}"
            messages.append(f"[x] {msg}")
            if not soft_warn:
                return False, [msg]

    # Pas de précision forcée sur les couches "libres"
    for e in entries:
        if e.forced:
            if e.format not in ("F16", "BF16", "F32"):
                messages.append(
                    f"[!] {e.name}: couche forcée en haute précision "
                    f"mais format {e.format} n'est pas flottant"
                )

    return True, messages


def check_memory_budget(
    entries: List,
    caps: hw.GPUCaps,
    budget_gb: float,
    kv_cache_gb: float = 0.0,
    activations_gb: float = 0.1,
    overhead_fraction: float = 0.05,
) -> Tuple[bool, str]:
    """Vérifie que le plan tient dans le budget VRAM réaliste.

    Args:
        entries: liste de PlanEntry.
        caps: capacités GPU.
        budget_gb: budget VRAM en Go (base 10).
        kv_cache_gb: cache KV réservé.
        activations_gb: activations et tampons.
        overhead_fraction: marge de fragmentation.

    Returns:
        (fits: bool, summary: str)
    """
    total_bytes = sum(e.bytes for e in entries)
    total_gb = total_bytes / 1e9

    kv_bytes = kv_cache_gb * 1e9
    act_bytes = activations_gb * 1e9
    budget_bytes = budget_gb * 1e9
    overhead_bytes = budget_bytes * overhead_fraction

    available_weights = budget_bytes - kv_bytes - act_bytes - overhead_bytes

    fits = total_bytes <= available_weights
    summary = (
        f"Mémoire : {total_gb:.2f} Go (poids) + {kv_cache_gb:.2f} Go (KV) "
        f"+ {activations_gb:.2f} Go (act) + {overhead_bytes / 1e9:.2f} Go (overhead) "
        f"= {(total_bytes + kv_bytes + act_bytes + overhead_bytes) / 1e9:.2f} Go / "
        f"{budget_gb:.2f} Go ({'OK' if fits else 'DEPASSE'})"
    )
    return fits, summary


def check_quality_degradation(
    entries: List,
    max_rel_error_threshold: float = 0.05,
) -> Tuple[float, List[str]]:
    """Analyse la dégradation qualité cumulée par couche.

    Args:
        entries: liste de PlanEntry.
        max_rel_error_threshold: seuil d'erreur relative acceptable.

    Returns:
        (max_error: float, issues: List[str])
    """
    issues = []
    max_error = 0.0

    for e in entries:
        if np.isfinite(e.rel_error):
            if e.rel_error > max_rel_error_threshold:
                issues.append(
                    f"[!] {e.name}: erreur {e.rel_error:.1%} > seuil {max_rel_error_threshold:.1%}"
                )
            max_error = max(max_error, e.rel_error)

    if not issues and max_error > 0:
        issues.append(f"[ok] Qualité : erreur max {max_error:.2%}, sous seuil {max_rel_error_threshold:.1%}")

    return max_error, issues


def suggest_improvements(entries: List) -> List[str]:
    """Suggère des améliorations basées sur le plan actuel.

    Returns:
        Liste de recommandations.
    """
    suggestions = []

    # Densité de formats
    format_dist = {}
    for e in entries:
        format_dist[e.format] = format_dist.get(e.format, 0) + 1

    # Nombreux changements de format = pénalité de cache
    n_switches = sum(1 for a, b in zip(
        [e.format for e in entries],
        [e.format for e in entries[1:]] + [None]
    ) if a != b)
    if n_switches > len(entries) / 3:
        suggestions.append(
            f"[tip] Nombreux changements de format ({n_switches}). "
            f"Envisagez regrouper les formats similaires."
        )

    # Trop de formats différents
    if len(format_dist) > 4:
        formats_by_count = sorted(format_dist.items(), key=lambda x: -x[1])
        suggestions.append(
            f"[tip] {len(format_dist)} formats utilisés (idéalement <= 4). "
            f"Formats : {', '.join(f'{fmt}({cnt})' for fmt, cnt in formats_by_count[:4])}"
        )

    # Petites couches en format compact (overhead de déquantification pour
    # un gain mémoire négligeable) — on plafonne le nombre de suggestions
    # pour ne pas noyer l'utilisateur sur un modèle à centaines de couches.
    small_quantized = [
        e for e in entries
        if e.bytes < 10e6 and fmts.get(e.format).bytes_per_weight < 1.0
    ]
    for e in small_quantized[:5]:
        suggestions.append(
            f"[tip] {e.name}: petite couche ({e.bytes / 1e6:.1f} MB) "
            f"mais très quantifiée. Envisagez F16 pour éviter la décompression."
        )
    if len(small_quantized) > 5:
        suggestions.append(f"[tip] ... et {len(small_quantized) - 5} autres petites couches quantifiées.")

    return suggestions
