"""
d2.loaders — Chargement des poids (GGUF, safetensors, HuggingFace)
===================================================================

Le v1 lisait `tensor.data` brut d'un GGUF et lui appliquait directement un SVD.
Pour un tenseur quantifié, `data` est une suite de blocs compressés : échelles
f16, nibbles empaquetés, masques. Le « spectre » obtenu était celui d'une
structure d'octets, pas de la matrice de poids. C'est ce qui explique les
202 valeurs α_w = 1.0 sur 274 dans `alpha_w_report.json` : le clamp
`max(α, 1.0)` du v1 absorbait un résultat sans signification.

On utilise ici `gguf.quants.dequantize`, l'implémentation de référence du
projet llama.cpp, qui couvre F32/F16/BF16, tous les Q*_0 / Q*_1, tous les
K-quants et les IQ*. Aucun « proxy octets ».

Note sur l'ordre des dimensions
-------------------------------
GGUF stocke `ne` avec la dimension la plus rapide en premier (convention
column-major de ggml). numpy est row-major : la forme numpy est donc
`tuple(reversed(tensor.shape))`. Le v1 utilisait `shape[0], shape[1]` sans
inversion, ce qui transposait implicitement toutes les matrices non carrées.
"""

from __future__ import annotations

import os
from typing import Dict, Iterator, List, Optional, Sequence

import numpy as np

from .sensitivity import LayerSpec, classify

__all__ = [
    "load_gguf",
    "load_safetensors",
    "load_huggingface",
    "iter_gguf_tensors",
    "synthetic_model",
    "ModelInfo",
]


class ModelInfo(dict):
    """Métadonnées d'architecture (n_blocks, n_kv_heads, head_dim, ...)."""


# ─────────────────────────────────────────────────────────────────────────────
# GGUF
# ─────────────────────────────────────────────────────────────────────────────


def iter_gguf_tensors(path: str, dequantize: bool = True) -> Iterator[tuple]:
    """Itère sur les tenseurs d'un fichier GGUF.

    Yields:
        (nom, matrice float32 ou None, forme numpy, nom du type ggml)

    Raises:
        ImportError: si le paquet `gguf` n'est pas installé.
    """
    try:
        from gguf import GGUFReader
        from gguf.constants import GGMLQuantizationType
        from gguf.quants import dequantize as _dequant
    except ImportError as exc:  # pragma: no cover - dépend de l'environnement
        raise ImportError(
            "lecture GGUF : `pip install gguf`. "
            "Le paquet fournit la déquantification de référence de llama.cpp."
        ) from exc

    reader = GGUFReader(path)
    for t in reader.tensors:
        shape = tuple(int(v) for v in reversed(t.shape))  # ne → row-major
        qname = GGMLQuantizationType(t.tensor_type).name
        W = None
        if dequantize:
            try:
                flat = _dequant(t.data, t.tensor_type)
                W = np.asarray(flat, dtype=np.float32).reshape(shape)
            except Exception as exc:
                # Type exotique non pris en charge : on le signale au lieu de
                # fabriquer un tableau bidon (le v1 renvoyait `fallback-zero`).
                W = None
                yield (t.name, None, shape, f"{qname}!undecodable:{type(exc).__name__}")
                continue
        yield (t.name, W, shape, qname)


def load_gguf(
    path: str,
    dequantize: bool = True,
    min_dim: int = 8,
    max_dim_for_svd: int = 4096,
    with_spectral: bool = False,
    progress: Optional[callable] = None,
):
    """Charge un modèle GGUF en `LayerSpec`.

    Args:
        path:        chemin du .gguf
        dequantize:  False pour ne récupérer que les formes (planification
                     rapide, `measure=False` côté planificateur).
        min_dim:     ignore les tenseurs dont une dimension est plus petite.
        max_dim_for_svd: sous-échantillonnage pour l'analyse spectrale.
        with_spectral: calcule α et les descripteurs spectraux (coûteux).
        progress:    callback(i, total, nom) pour l'affichage.

    Returns:
        (layers, info)
    """
    from . import spectral

    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    tensors = list(iter_gguf_tensors(path, dequantize=dequantize))
    layers: List[LayerSpec] = []
    skipped: List[str] = []

    for i, (name, W, shape, qname) in enumerate(tensors):
        if progress:
            progress(i, len(tensors), name)
        if len(shape) < 2 or min(shape) < min_dim:
            skipped.append(name)
            continue
        if "!undecodable" in qname:
            skipped.append(f"{name} ({qname})")
            continue
        alpha = float("nan")
        if with_spectral and W is not None:
            alpha = spectral.analyze(W, max_dim=max_dim_for_svd).alpha
        layers.append(
            LayerSpec(
                name=name,
                shape=list(shape),
                weights=W,
                alpha=alpha,
                extra={"source_type": qname},
            )
        )

    info = ModelInfo(
        path=path,
        n_tensors=len(tensors),
        n_planned=len(layers),
        skipped=skipped,
        source="gguf",
    )
    info.update(_infer_geometry([l.name for l in layers], layers))
    _read_gguf_metadata(path, info)
    return layers, info


def _read_gguf_metadata(path: str, info: ModelInfo) -> None:
    """Complète `info` avec les métadonnées d'architecture du GGUF.

    Ces champs (`*.attention.head_count_kv`, `*.block_count`) donnent la
    géométrie exacte du cache KV, ce que le v1 devinait par une heuristique
    `hidden // 128` fausse dès qu'un modèle n'était pas un Llama.
    """
    try:
        from gguf import GGUFReader
    except ImportError:  # pragma: no cover
        return
    try:
        reader = GGUFReader(path)
    except Exception:  # pragma: no cover
        return

    def _field(suffix):
        for key, fld in reader.fields.items():
            if key.endswith(suffix):
                try:
                    return int(fld.parts[fld.data[0]][0])
                except Exception:
                    return None
        return None

    arch = None
    for key, fld in reader.fields.items():
        if key == "general.architecture":
            try:
                arch = bytes(fld.parts[fld.data[0]]).decode("utf-8")
            except Exception:
                arch = None
            break

    n_blocks = _field(".block_count")
    n_heads = _field(".attention.head_count")
    n_kv = _field(".attention.head_count_kv")
    n_embd = _field(".embedding_length")

    if arch:
        info["arch"] = arch
    if n_blocks:
        info["n_blocks"] = n_blocks
    if n_kv:
        info["n_kv_heads"] = n_kv
    if n_heads and n_embd:
        info["head_dim"] = n_embd // n_heads
    elif n_heads:
        info["n_heads"] = n_heads


# ─────────────────────────────────────────────────────────────────────────────
# safetensors / HuggingFace
# ─────────────────────────────────────────────────────────────────────────────


def load_safetensors(
    path: str,
    min_dim: int = 8,
    with_spectral: bool = False,
    max_tensors: Optional[int] = None,
):
    """Charge un fichier .safetensors local en `LayerSpec`."""
    from . import spectral

    try:
        from safetensors.numpy import load_file
    except ImportError as exc:
        raise ImportError("`pip install safetensors`") from exc

    tensors = load_file(path)
    layers: List[LayerSpec] = []
    for name, arr in tensors.items():
        if max_tensors and len(layers) >= max_tensors:
            break
        a = np.asarray(arr)
        if a.ndim < 2:
            continue
        if a.ndim > 2:
            a = a.reshape(a.shape[0], -1)
        if min(a.shape) < min_dim:
            continue
        W = a.astype(np.float32)
        alpha = spectral.analyze(W).alpha if with_spectral else float("nan")
        layers.append(
            LayerSpec(name=name, shape=list(W.shape), weights=W, alpha=alpha)
        )

    info = ModelInfo(path=path, source="safetensors", n_planned=len(layers))
    info.update(_infer_geometry([l.name for l in layers], layers))
    return layers, info


def load_huggingface(
    model_id: str,
    cache_dir: Optional[str] = None,
    with_spectral: bool = False,
    max_tensors: Optional[int] = None,
    max_shards: int = 1,
):
    """Télécharge un modèle HuggingFace et le charge en `LayerSpec`.

    Args:
        model_id:   identifiant HF ou chemin local.
        cache_dir:  cache ; par défaut celui de `huggingface_hub` (le v1
                    codait `/tmp/hf_cache` en dur, inutilisable sous Windows).
        max_shards: nombre de fichiers safetensors à charger.

    Raises:
        FileNotFoundError: si aucun safetensors n'est publié pour ce dépôt.
    """
    try:
        from huggingface_hub import hf_hub_download, list_repo_files
    except ImportError as exc:
        raise ImportError("`pip install huggingface_hub`") from exc

    if os.path.isfile(model_id):
        return load_safetensors(model_id, with_spectral=with_spectral,
                                max_tensors=max_tensors)

    files = [
        f for f in list_repo_files(model_id)
        if f.endswith(".safetensors") and "onnx" not in f.lower()
    ]
    if not files:
        raise FileNotFoundError(
            f"aucun .safetensors dans {model_id!r} "
            "(les dépôts en .bin/pickle ne sont pas chargés pour raison de sécurité)"
        )

    layers: List[LayerSpec] = []
    info = ModelInfo(source="huggingface", model_id=model_id)
    for shard in sorted(files)[:max_shards]:
        local = hf_hub_download(model_id, shard, cache_dir=cache_dir)
        part, _ = load_safetensors(local, with_spectral=with_spectral,
                                   max_tensors=max_tensors)
        layers.extend(part)

    # Configuration : géométrie exacte du cache KV.
    try:
        import json

        cfg_path = hf_hub_download(model_id, "config.json", cache_dir=cache_dir)
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        n_heads = cfg.get("num_attention_heads") or cfg.get("n_head")
        hidden = cfg.get("hidden_size") or cfg.get("n_embd")
        info["arch"] = (cfg.get("architectures") or ["unknown"])[0]
        info["n_blocks"] = cfg.get("num_hidden_layers") or cfg.get("n_layer")
        info["n_kv_heads"] = cfg.get("num_key_value_heads") or n_heads
        if n_heads and hidden:
            info["head_dim"] = cfg.get("head_dim") or hidden // n_heads
    except Exception:
        info.update(_infer_geometry([l.name for l in layers], layers))

    info["n_planned"] = len(layers)
    return layers, info


# ─────────────────────────────────────────────────────────────────────────────
# Géométrie déduite (repli quand les métadonnées manquent)
# ─────────────────────────────────────────────────────────────────────────────


def _infer_geometry(names: Sequence[str], layers: Sequence[LayerSpec]) -> Dict:
    """Déduit n_blocks / n_kv_heads / head_dim des formes des tenseurs.

    On mesure `n_kv_heads` sur la forme réelle de la projection K ou V, au lieu
    de supposer `n_heads // 4` comme le faisait le v1 (faux pour tout modèle
    sans GQA 4:1, dont GPT-2, Mistral et Qwen).
    """
    from .sensitivity import block_index

    out: Dict = {}
    blocks = [block_index(n) for n in names]
    blocks = [b for b in blocks if b is not None]
    if blocks:
        out["n_blocks"] = max(blocks) + 1

    hidden = None
    kv_out = None
    for l in layers:
        if l.cls == "attn_q" and len(l.shape) >= 2:
            hidden = hidden or max(l.shape)
        if l.cls in ("attn_k", "attn_v") and len(l.shape) >= 2:
            kv_out = kv_out or min(l.shape)

    if hidden:
        out["hidden_size"] = hidden
        head_dim = 128 if hidden % 128 == 0 else 64
        out["head_dim"] = head_dim
        if kv_out:
            out["n_kv_heads"] = max(1, kv_out // head_dim)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Modèle synthétique (démo)
# ─────────────────────────────────────────────────────────────────────────────


def synthetic_model(
    n_blocks: int = 32,
    hidden: int = 4096,
    intermediate: int = 14336,
    vocab: int = 128256,
    n_kv_heads: int = 8,
    head_dim: int = 128,
    seed: int = 0,
    with_weights: bool = True,
    weight_dim_cap: int = 512,
):
    """Génère un modèle de démonstration façon Llama-3-8B.

    Les poids synthétiques suivent une loi à queue lourde (produit de deux
    gaussiennes), qui reproduit qualitativement le spectre d'une couche
    entraînée — contrairement à `np.random.randn` du v1, dont le spectre est
    celui de Marchenko–Pastur et ne ressemble à aucune couche réelle.

    Les matrices sont générées en taille réduite (`weight_dim_cap`) mais la
    comptabilité mémoire utilise les vraies formes : on obtient une erreur de
    quantification représentative sans allouer 16 Go.

    Args:
        with_weights: False pour ne produire que les formes.

    Returns:
        (layers, info)
    """
    rng = np.random.default_rng(seed)

    def make(shape):
        if not with_weights:
            return None
        m = min(shape[0], weight_dim_cap)
        n = min(shape[1], weight_dim_cap)
        a = rng.standard_normal((m, n)).astype(np.float32)
        b = rng.standard_normal((m, n)).astype(np.float32)
        return (a * b * 0.05).astype(np.float32)  # queue lourde

    specs = [
        ("token_embd.weight", [vocab, hidden]),
        ("output_norm.weight", [hidden, 1]),
        ("output.weight", [vocab, hidden]),
    ]
    for b in range(n_blocks):
        specs += [
            (f"blk.{b}.attn_norm.weight", [hidden, 1]),
            (f"blk.{b}.attn_q.weight", [hidden, hidden]),
            (f"blk.{b}.attn_k.weight", [n_kv_heads * head_dim, hidden]),
            (f"blk.{b}.attn_v.weight", [n_kv_heads * head_dim, hidden]),
            (f"blk.{b}.attn_output.weight", [hidden, hidden]),
            (f"blk.{b}.ffn_norm.weight", [hidden, 1]),
            (f"blk.{b}.ffn_gate.weight", [intermediate, hidden]),
            (f"blk.{b}.ffn_up.weight", [intermediate, hidden]),
            (f"blk.{b}.ffn_down.weight", [hidden, intermediate]),
        ]

    layers = [
        LayerSpec(name=n, shape=s, weights=make(s), n_elements=s[0] * s[1])
        for n, s in specs
    ]
    info = ModelInfo(
        source="synthetic",
        arch="llama",
        n_blocks=n_blocks,
        n_kv_heads=n_kv_heads,
        head_dim=head_dim,
        hidden_size=hidden,
        n_planned=len(layers),
        synthetic=True,
    )
    return layers, info
