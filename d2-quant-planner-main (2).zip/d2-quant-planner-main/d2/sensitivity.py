"""
d2.sensitivity — Sensibilité d'une couche à la quantification
==============================================================

Le v1 décidait la précision à partir de seuils sur `alpha_w`, dans **deux
directions opposées** selon le fichier (α élevé → INT4 dans le scanner RTX,
α élevé → FP16 dans `spectral_theory`). Aucune des deux n'est étayée : la
littérature sur α (Martin & Mahoney) porte sur la qualité d'entraînement, pas
sur la robustesse à la quantification.

Ce module remplace ce critère par une grandeur **mesurée** :

    Ω(i, q) = c_i · ‖W_i − Q_q(W_i)‖²_F(s_i) / ‖W_i‖²_F(s_i)

où `Q_q` est le vrai aller-retour de quantification (`d2.formats.roundtrip`),
`s_i` l'importance par canal d'entrée (imatrix, optionnelle) et `c_i` un
préfacteur d'importance de couche.

Pourquoi c'est la bonne grandeur
--------------------------------
La perturbation de sortie d'une couche linéaire vaut ΔY = ΔW·X. Sous
l'hypothèse d'un Hessien bloc-diagonal — hypothèse standard de HAWQ, GPTQ et
SqueezeLLM — la dégradation totale du modèle est additive sur les couches et
proportionnelle à E[‖ΔW·x‖²]. Pour des activations isotropes cela vaut
‖ΔW‖²_F ; avec les statistiques d'activation réelles cela devient
‖ΔW·diag(√s)‖²_F avec s = E[x²], qui est **exactement** l'objectif que
minimisent GPTQ et l'`imatrix` de llama.cpp.

Le problème d'allocation de bits qui en découle — minimiser Σ Ω sous
contrainte de taille — est la formulation ILP de HAWQ-V3.

Préfacteurs d'importance `c_i`
------------------------------
Issus de deux sources convergentes :

1. Le mélange k-quant de llama.cpp (`llama_tensor_get_type`), calibré
   empiriquement sur la perplexité : `attn_v` et `ffn_down` sont systématiquement
   remontés d'un cran par rapport au type nominal ; `token_embd` et
   `output.weight` sont traités à part ; les normes restent en F32.
2. AWQ (Lin et al., MLSys 2024) : la saillance est très concentrée
   (~1 % des canaux), et les projections de valeur et de sortie FFN sont les
   plus sensibles. LLM.int8() (Dettmers et al., NeurIPS 2022) identifie les
   mêmes couches comme porteuses des canaux aberrants.

Ces préfacteurs sont des **a priori**, remplacés dès qu'une imatrix est
fournie : `sensitivity_matrix(..., imatrix=...)` fait alors reposer la décision
sur des statistiques mesurées plutôt que sur la nomenclature des tenseurs.

Références
----------
- Dong et al., "HAWQ-V2", NeurIPS 2020 ; Yao et al., "HAWQ-V3", ICML 2021.
- Frantar et al., "GPTQ", ICLR 2023.
- Lin et al., "AWQ", MLSys 2024.
- Kim et al., "SqueezeLLM", ICML 2024.
- Dettmers et al., "LLM.int8()", NeurIPS 2022.
- Xiao et al., "SmoothQuant", ICML 2023.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np

from . import formats as fmts

__all__ = [
    "LayerClass",
    "classify",
    "CLASS_IMPORTANCE",
    "FORCE_HIGH_PRECISION",
    "LayerSpec",
    "sensitivity_matrix",
    "load_imatrix",
]


# ─────────────────────────────────────────────────────────────────────────────
# Classification des couches
# ─────────────────────────────────────────────────────────────────────────────

#: Classes de couches reconnues.
LayerClass = str

#: Motifs (regex, classe), évalués dans l'ordre. Couvre les nomenclatures
#: HuggingFace (`model.layers.N.self_attn.v_proj`), GGUF (`blk.N.attn_v`),
#: GPT-2 (`h.N.attn.c_attn`) et les architectures hybrides SSM/Mamba.
_PATTERNS: List[tuple] = [
    (r"(^|\.)(rope|rotary|inv_freq|alibi)", "meta"),
    (r"(norm|layernorm|ln_\d|ln_f|rms_?norm)", "norm"),
    (r"(bias)$", "bias"),
    (r"(token_embd|embed_tokens|tok_embeddings|\bwte\b|\bwpe\b|position_embd|embedding)", "embed"),
    (r"(lm_head|^output\.weight|\boutput\b(?!_norm)|cls\.)", "head"),
    (r"(ssm_conv|conv1d)", "ssm_conv"),
    (r"(ssm_|mamba|\bA_log\b|\bdt_proj\b)", "ssm"),
    # `attn_qkv` doit precéder `attn_q`, sinon le motif `attn_q` capture
    # `attn_qkv` (GPT-2, Qwen fusionné) et la couche est mal pondérée.
    (r"(attn_qkv|c_attn|qkv_proj)", "attn_qkv"),
    (r"(attn_v|v_proj|\bwv\b|value)", "attn_v"),
    (r"(attn_k|k_proj|\bwk\b|\bkey\b)", "attn_k"),
    (r"(attn_output|attn_out|o_proj|\bwo\b)", "attn_o"),
    (r"(attn_q|q_proj|\bwq\b|query)", "attn_q"),
    (r"(attn_gate|attn)", "attn_q"),
    (r"(ffn_down|down_proj|\bw2\b|mlp\.c_proj)", "ffn_down"),
    (r"(ffn_gate|gate_proj|\bw1\b)", "ffn_gate"),
    (r"(ffn_up|up_proj|\bw3\b|mlp\.c_fc|fc\d)", "ffn_up"),
    (r"(expert|moe)", "ffn_up"),
    (r"(mlp|ffn|dense)", "ffn_up"),
]

_COMPILED = [(re.compile(p, re.IGNORECASE), c) for p, c in _PATTERNS]


def classify(name: str) -> LayerClass:
    """Classe un tenseur d'après son nom.

    L'ordre des motifs compte : `attn_v` est testé avant `attn`, et `norm`
    avant tout le reste (le v1 classait `output_norm.weight` en « head » et
    `token_embd` en « mlp » selon le module).

    Args:
        name: nom du tenseur (HF, GGUF ou GPT-2).

    Returns:
        Nom de classe ; « other » si aucun motif ne correspond.
    """
    n = name.lower()
    for rx, cls in _COMPILED:
        if rx.search(n):
            return cls
    return "other"


#: Préfacteur d'importance par classe. 1.0 = référence (ffn_up/gate).
#: `inf` signifie « jamais quantifié » : la couche est contrainte en dur.
CLASS_IMPORTANCE: Dict[LayerClass, float] = {
    "norm": float("inf"),     # F32 dans tous les mélanges llama.cpp
    "meta": float("inf"),     # tables RoPE, fréquences : non quantifiables
    "bias": float("inf"),     # taille négligeable, gain nul
    "embed": 4.0,             # table d'embedding : erreur non amortie
    "head": 6.0,              # projection logits : impact direct sur la sortie
    "ssm_conv": 5.0,          # récurrence : l'erreur s'accumule dans le temps
    "ssm": 3.0,
    "attn_v": 2.5,            # remonté d'un cran par llama.cpp ; saillant AWQ
    "attn_o": 1.6,
    "attn_k": 1.3,            # sensible via le produit QKᵀ (KVQuant)
    "attn_q": 1.0,
    "attn_qkv": 1.4,          # fusionné : moyenne pondérée q/k/v
    "ffn_down": 2.5,          # remonté d'un cran par llama.cpp ; canaux aberrants
    "ffn_gate": 1.0,
    "ffn_up": 1.0,
    "other": 1.5,             # inconnu → prudence
}

#: Classes maintenues en haute précision quelles que soient les contraintes.
FORCE_HIGH_PRECISION = {c for c, v in CLASS_IMPORTANCE.items() if not np.isfinite(v)}

#: Bonus d'importance pour les premiers et derniers blocs. Les mélanges
#: k-quant de llama.cpp remontent la précision sur les blocs de bord, et
#: l'étude d'ablation de LLM.int8() y localise les canaux aberrants.
EDGE_BLOCK_BONUS = 1.5
EDGE_BLOCK_COUNT = 2

_BLOCK_RX = re.compile(r"(?:blk|layers|h)\.(\d+)\.")


def block_index(name: str) -> Optional[int]:
    """Indice du bloc transformer contenant ce tenseur, ou None."""
    m = _BLOCK_RX.search(name)
    return int(m.group(1)) if m else None


# ─────────────────────────────────────────────────────────────────────────────
# Spécification d'une couche
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class LayerSpec:
    """Une couche candidate à la quantification.

    Attributes:
        name:     nom du tenseur.
        shape:    (lignes, colonnes) — canaux de sortie, canaux d'entrée.
        weights:  matrice déquantifiée, ou None si seule la forme est connue.
                  Sans matrice on ne peut pas mesurer l'erreur : le
                  planificateur bascule alors sur les a priori de classe et le
                  signale (`measured=False`).
        cls:      classe (déduite du nom si absente).
        importance: dict optionnel {canal_entrée: E[x²]} issu d'une imatrix.
        alpha:    exposant spectral, diagnostic uniquement.
        n_elements: nombre de poids (déduit de `shape` si absent).
    """

    name: str
    shape: Sequence[int]
    weights: Optional[np.ndarray] = None
    cls: Optional[LayerClass] = None
    importance: Optional[np.ndarray] = None
    alpha: float = float("nan")
    n_elements: Optional[int] = None
    extra: Dict = field(default_factory=dict)

    def __post_init__(self):
        if self.cls is None:
            self.cls = classify(self.name)
        if self.n_elements is None:
            self.n_elements = int(np.prod(self.shape)) if len(self.shape) else 0

    @property
    def importance_factor(self) -> float:
        """Préfacteur `c_i` de classe (bonus de bloc appliqué séparément dans sensitivity_matrix)."""
        return CLASS_IMPORTANCE.get(self.cls, 1.5)

    @property
    def forced(self) -> bool:
        """True si la couche ne doit jamais être quantifiée."""
        return not np.isfinite(CLASS_IMPORTANCE.get(self.cls, 1.5))


# ─────────────────────────────────────────────────────────────────────────────
# Matrice de sensibilité
# ─────────────────────────────────────────────────────────────────────────────


def _edge_bonus(spec: LayerSpec, n_blocks: Optional[int]) -> float:
    """Bonus multiplicatif pour les blocs de bord."""
    if n_blocks is None or n_blocks <= 2 * EDGE_BLOCK_COUNT:
        return 1.0
    b = block_index(spec.name)
    if b is None:
        return 1.0
    if b < EDGE_BLOCK_COUNT or b >= n_blocks - EDGE_BLOCK_COUNT:
        return EDGE_BLOCK_BONUS
    return 1.0


def sensitivity_matrix(
    layers: Sequence[LayerSpec],
    candidate_formats: Sequence[str],
    imatrix: Optional[Dict[str, np.ndarray]] = None,
    measure: bool = True,
):
    """Construit la matrice de coût qualité Ω et la matrice de taille.

    Args:
        layers:            couches à planifier.
        candidate_formats: formats envisagés, du plus compact au plus large
                           (l'ordre n'a pas d'importance pour le solveur).
        imatrix:           {nom_tenseur: E[x²] par canal d'entrée}. Active la
                           pondération façon GPTQ/AWQ.
        measure:           si False, on n'effectue aucun aller-retour et on se
                           rabat sur un modèle d'erreur analytique (bruit
                           uniforme). Utile pour planifier à partir des seules
                           formes (mode démo, pas de poids en mémoire).

    Returns:
        (omega, size_bytes, measured) où
          - `omega[i, q]`      : coût qualité ≥ 0 de la couche i en format q ;
          - `size_bytes[i, q]` : octets occupés ;
          - `measured[i]`      : True si Ω vient d'une mesure réelle.
    """
    n, P = len(layers), len(candidate_formats)
    omega = np.zeros((n, P), dtype=np.float64)
    size = np.zeros((n, P), dtype=np.float64)
    measured = np.zeros(n, dtype=bool)

    blocks = [block_index(l.name) for l in layers]
    known = [b for b in blocks if b is not None]
    n_blocks = (max(known) + 1) if known else None

    for i, spec in enumerate(layers):
        c_i = spec.importance_factor * _edge_bonus(spec, n_blocks)
        imp = None
        if imatrix is not None and spec.name in imatrix:
            imp = np.asarray(imatrix[spec.name], dtype=np.float32)
            if spec.weights is not None and spec.weights.ndim == 2:
                if imp.size != spec.weights.shape[1]:
                    imp = None

        can_measure = measure and spec.weights is not None and spec.weights.size > 0
        measured[i] = bool(can_measure)

        for q, fname in enumerate(candidate_formats):
            size[i, q] = fmts.format_bytes(spec.n_elements, fname)

            if not np.isfinite(c_i):
                omega[i, q] = 0.0 if fmts.get(fname).family == "float" else np.inf
                continue

            if can_measure:
                rel = fmts.relative_error(spec.weights, fname, weights=imp)
            else:
                rel = _analytic_relative_error(fname)
            # Clipping pour éviter les valeurs infinies/NaN dues à instabilités numériques
            omega[i, q] = np.clip(c_i * float(rel) ** 2, 0.0, 1e6)

    return omega, size, measured


def _analytic_relative_error(fname: str) -> float:
    """Erreur relative attendue en l'absence de poids.

    Modèle : quantification uniforme sur `b` bits d'une variable centrée, bruit
    uniforme de variance Δ²/12 avec Δ = 2·k·σ/2^b. En prenant k ≈ 3 écarts-types
    de dynamique utile, l'erreur relative vaut ≈ (k/√3)·2^(−b).

    C'est une approximation grossière, utilisée uniquement en mode démo ; le
    champ `measured` du plan indique quand elle a servi, ce que le v1 ne
    faisait jamais (il présentait des chiffres synthétiques comme mesurés).
    """
    fmt = fmts.get(fname)
    if fmt.family == "float":
        # F16 : ~11 bits de mantisse ; BF16 : ~8.
        return {"F32": 0.0, "F16": 5e-4, "BF16": 4e-3}.get(fmt.name, 1e-3)
    eff_bits = {
        "Q8_0": 8.0, "INT8": 8.0, "Q6_K": 6.0, "Q5_K": 5.0, "Q5_0": 5.0,
        "Q4_K": 4.0, "Q4_0": 4.0, "INT4_AWQ": 4.0, "Q3_K": 3.0, "Q2_K": 2.0,
        "NVFP4": 4.0, "MXFP4": 4.0,
    }.get(fmt.name, 4.0)
    # Clipping pour éviter les valeurs extrêmes
    rel_err = float((3.0 / np.sqrt(3.0)) * 2.0 ** (-eff_bits))
    return np.clip(rel_err, 1e-8, 1.0)


def load_imatrix(path: str) -> Dict[str, np.ndarray]:
    """Charge une matrice d'importance llama.cpp (`llama-imatrix`).

    Format binaire natif : n_entries (i32), puis pour chaque entrée
    len (i32), nom (bytes), ncall (i32), nval (i32), valeurs (f32 × nval).
    Un JSON {nom: [valeurs]} est également accepté.

    Args:
        path: chemin du fichier `.imatrix` ou `.json`.

    Returns:
        {nom_tenseur: vecteur E[x²] par canal d'entrée}.

    Raises:
        ValueError: si le fichier n'est pas lisible dans l'un des deux formats.
    """
    import json
    import struct

    if path.lower().endswith(".json"):
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return {k: np.asarray(v, dtype=np.float32) for k, v in raw.items()}

    out: Dict[str, np.ndarray] = {}
    with open(path, "rb") as f:
        blob = f.read()
    pos = 0

    def _i32():
        nonlocal pos
        (v,) = struct.unpack_from("<i", blob, pos)
        pos += 4
        return v

    try:
        n_entries = _i32()
        if not (0 < n_entries < 1_000_000):
            raise ValueError(f"n_entries invalide : {n_entries}")
        for _ in range(n_entries):
            name_len = _i32()
            name = blob[pos : pos + name_len].decode("utf-8", "replace")
            pos += name_len
            _ncall = _i32()
            nval = _i32()
            vals = np.frombuffer(blob, dtype=np.float32, count=nval, offset=pos)
            pos += 4 * nval
            # llama.cpp stocke la somme des x² sur `ncall` appels
            out[name] = np.array(vals, dtype=np.float32)
    except (struct.error, UnicodeDecodeError, ValueError) as exc:
        raise ValueError(
            f"{path} n'est ni une imatrix binaire llama.cpp ni un JSON : {exc}"
        ) from exc
    return out
