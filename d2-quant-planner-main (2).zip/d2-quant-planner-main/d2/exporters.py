"""
d2.exporters — Export des plans vers llama.cpp et TensorRT-LLM
===============================================================

Correction majeure par rapport au v1
------------------------------------
`d2_production.export_gguf` produisait des lignes ::

    --override-tensor blk.0.attn_q.weight=q8_0

`--override-tensor` (`-ot`) de llama.cpp **n'est pas** un sélecteur de
quantification : il associe un motif de nom de tenseur à un *type de buffer*
(placement mémoire), par exemple ``-ot "\\.ffn_.*_exps\\.=CPU"`` pour laisser
les experts MoE sur le CPU. Lui passer un nom de type ggml ne quantifie rien.

Le bon outil est ``llama-quantize --tensor-type``, qui applique un type ggml
aux tenseurs dont le nom correspond, au moment de la conversion du modèle ::

    llama-quantize --tensor-type "attn_v=q6_K" --tensor-type "ffn_down=q6_K" \\
        model-f16.gguf model-mixed.gguf q4_K_M

Le v1 documentait par ailleurs son propre export comme utilisable avec
``llama-cli --model … $(cat plan_cmd.txt)`` : ces options n'existent pas côté
inférence, la quantification se fait à la conversion.

Nommage des tenseurs
--------------------
Les noms HuggingFace et GGUF diffèrent. La table de correspondance couvre
Llama/Mistral/Qwen, GPT-2, Falcon et MPT. Un nom non reconnu est **signalé**
(champ `unmapped`) au lieu d'être laissé tel quel silencieusement : un nom
inconnu passé à `--tensor-type` ne correspondra à aucun tenseur et l'option
sera ignorée sans erreur, ce qui donne un modèle qui n'est pas celui prévu.
"""

from __future__ import annotations

import json
import re
from typing import Dict, List, Optional, Tuple

from . import formats as fmts
from .planner import Plan

__all__ = [
    "detect_arch",
    "hf_to_gguf_name",
    "export_llama_cpp",
    "export_tensorrt_llm",
    "export_json",
]


# ─────────────────────────────────────────────────────────────────────────────
# Correspondance des noms
# ─────────────────────────────────────────────────────────────────────────────

_LLAMA_MAP = {
    "self_attn.q_proj.weight": "attn_q.weight",
    "self_attn.k_proj.weight": "attn_k.weight",
    "self_attn.v_proj.weight": "attn_v.weight",
    "self_attn.o_proj.weight": "attn_output.weight",
    "mlp.gate_proj.weight": "ffn_gate.weight",
    "mlp.up_proj.weight": "ffn_up.weight",
    "mlp.down_proj.weight": "ffn_down.weight",
    "input_layernorm.weight": "attn_norm.weight",
    "post_attention_layernorm.weight": "ffn_norm.weight",
}

_GPT2_ATTN = {
    "c_attn.weight": "attn_qkv.weight",
    "c_attn.bias": "attn_qkv.bias",
    "c_proj.weight": "attn_output.weight",
    "c_proj.bias": "attn_output.bias",
}
_GPT2_MLP = {
    "c_fc.weight": "ffn_up.weight",
    "c_fc.bias": "ffn_up.bias",
    "c_proj.weight": "ffn_down.weight",
    "c_proj.bias": "ffn_down.bias",
}


def detect_arch(names: List[str]) -> str:
    """Devine l'architecture d'après les noms de tenseurs."""
    joined = " ".join(names[:64])
    if "blk." in joined and "attn_" in joined:
        return "gguf"  # déjà en nomenclature GGUF
    if "model.layers." in joined and "self_attn" in joined:
        return "llama"
    if "transformer.h." in joined or re.search(r"(^|\s)h\.\d+\.attn", joined):
        return "gpt2"
    if "self_attention" in joined:
        return "falcon"
    if "transformer.blocks." in joined:
        return "mpt"
    return "unknown"


def hf_to_gguf_name(name: str, arch: str) -> Optional[str]:
    """Traduit un nom HuggingFace en nom GGUF.

    Returns:
        Le nom GGUF, ou **None** si aucune correspondance n'est connue. Le v1
        renvoyait le nom HF d'origine en se justifiant par « llama.cpp
        l'ignorera sans erreur » — c'est précisément le problème : la couche
        n'était alors pas quantifiée comme prévu, sans que rien ne le signale.
    """
    if arch == "gguf":
        return name

    if arch == "llama":
        direct = {
            "model.embed_tokens.weight": "token_embd.weight",
            "model.norm.weight": "output_norm.weight",
            "lm_head.weight": "output.weight",
        }
        if name in direct:
            return direct[name]
        m = re.match(r"model\.layers\.(\d+)\.(.+)", name)
        if m and m.group(2) in _LLAMA_MAP:
            return f"blk.{m.group(1)}.{_LLAMA_MAP[m.group(2)]}"
        return None

    if arch == "gpt2":
        direct = {
            "wte.weight": "token_embd.weight",
            "transformer.wte.weight": "token_embd.weight",
            "wpe.weight": "position_embd.weight",
            "transformer.wpe.weight": "position_embd.weight",
            "ln_f.weight": "output_norm.weight",
            "transformer.ln_f.weight": "output_norm.weight",
            "ln_f.bias": "output_norm.bias",
            "transformer.ln_f.bias": "output_norm.bias",
        }
        if name in direct:
            return direct[name]
        m = re.match(r"(?:transformer\.)?h\.(\d+)\.(attn|mlp|ln_1|ln_2)\.(.+)", name)
        if not m:
            return None
        idx, block, rest = m.groups()
        if block == "attn" and rest in _GPT2_ATTN:
            return f"blk.{idx}.{_GPT2_ATTN[rest]}"
        if block == "mlp" and rest in _GPT2_MLP:
            return f"blk.{idx}.{_GPT2_MLP[rest]}"
        if block == "ln_1":
            return f"blk.{idx}.attn_norm.{rest}"
        if block == "ln_2":
            return f"blk.{idx}.ffn_norm.{rest}"
        return None

    return None


# ─────────────────────────────────────────────────────────────────────────────
# llama.cpp
# ─────────────────────────────────────────────────────────────────────────────


#: Types de base acceptés par `llama-quantize` (dernier argument positionnel).
_BASE_TYPE_OF = {
    "f16": "F16", "bf16": "BF16", "q8_0": "Q8_0", "q6_K": "Q6_K",
    "q5_K": "Q5_K_M", "q4_K": "Q4_K_M", "q3_K": "Q3_K_M", "q2_K": "Q2_K",
    "q4_0": "Q4_0", "q5_0": "Q5_0",
}


def export_llama_cpp(
    plan: Plan,
    input_gguf: str = "model-f16.gguf",
    output_gguf: str = "model-d2.gguf",
    base_type: Optional[str] = None,
    json_path: Optional[str] = None,
    collapse: bool = True,
) -> Dict:
    """Génère la commande `llama-quantize` et le JSON de correspondance.

    La commande n'énumère que les tenseurs qui **s'écartent** du type de base :
    lister les 300 tenseurs d'un modèle produit une ligne de commande
    illisible et masque justement les décisions intéressantes. Les normes sont
    omises — llama.cpp les conserve en F32 quel que soit le type demandé, les
    lister n'aurait aucun effet.

    Args:
        plan:        plan à exporter.
        input_gguf:  GGUF source (typiquement converti en F16).
        output_gguf: fichier de sortie.
        base_type:   type de base ; déduit du format dominant du plan si omis.
        json_path:   si fourni, écrit le plan détaillé à ce chemin.
        collapse:    regroupe par classe de tenseur (`attn_v=q6_K`) quand tous
                     les tenseurs de la classe partagent le même type.

    Returns:
        {'command', 'tensor_types', 'overrides', 'base_type', 'unmapped',
         'unsupported'}
    """
    from .sensitivity import classify

    arch = detect_arch([e.name for e in plan.entries])

    mapping: Dict[str, str] = {}
    unmapped: List[str] = []
    unsupported: List[Tuple[str, str]] = []

    for e in plan.entries:
        if e.cls in ("norm", "bias", "meta"):
            continue  # conservés en F32 par llama.cpp, non pilotables
        ggml_type = fmts.get(e.format).gguf
        if ggml_type is None:
            unsupported.append((e.name, e.format))
            continue
        gguf_name = hf_to_gguf_name(e.name, arch)
        if gguf_name is None:
            unmapped.append(e.name)
            continue
        mapping[gguf_name] = ggml_type

    # Type de base = type le plus fréquent, pondéré par la taille : c'est lui
    # qui dicte la taille finale du fichier.
    if base_type is None:
        weight: Dict[str, float] = {}
        for e in plan.entries:
            t = fmts.get(e.format).gguf
            if t:
                weight[t] = weight.get(t, 0.0) + e.bytes
        dominant = max(weight, key=weight.get) if weight else "q4_K"
        base_type = _BASE_TYPE_OF.get(dominant, "Q4_K_M")
    base_ggml = {v: k for k, v in _BASE_TYPE_OF.items()}.get(base_type, "q4_K")

    overrides = {n: t for n, t in mapping.items() if t != base_ggml}

    args: List[str] = []
    if collapse:
        groups: Dict[Tuple[str, str], List[str]] = {}
        for gguf_name, t in overrides.items():
            groups.setdefault((classify(gguf_name), t), []).append(gguf_name)

        suffix_of = {
            "attn_q": "attn_q", "attn_k": "attn_k", "attn_v": "attn_v",
            "attn_o": "attn_output", "attn_qkv": "attn_qkv",
            "ffn_down": "ffn_down", "ffn_up": "ffn_up", "ffn_gate": "ffn_gate",
            "embed": "token_embd", "head": "output", "ssm_conv": "ssm_conv1d",
        }
        # Toutes les classes présentes dans le plan (pas seulement les écarts) :
        # on ne peut regrouper une classe que si aucun de ses membres ne reste
        # au type de base, sinon le motif toucherait aussi ceux-là.
        cls_types: Dict[str, set] = {}
        for gguf_name, t in mapping.items():
            cls_types.setdefault(classify(gguf_name), set()).add(t)

        used = set()
        for (cls, t), names in sorted(groups.items()):
            pattern = suffix_of.get(cls)
            if pattern and cls_types.get(cls) == {t}:
                args.append(f'--tensor-type "{pattern}={t}"')
                used.update(names)
        for gguf_name, t in sorted(overrides.items()):
            if gguf_name not in used:
                args.append(f'--tensor-type "{gguf_name}={t}"')
    else:
        args = [f'--tensor-type "{n}={t}"' for n, t in sorted(overrides.items())]

    parts = ["llama-quantize"] + args + [input_gguf, output_gguf, base_type]
    command = " \\\n  ".join(parts)

    payload = {
        "format": "llama_cpp_tensor_type",
        "version": "3.0",
        "arch": arch,
        "input": input_gguf,
        "output": output_gguf,
        "base_type": base_type,
        "command": command,
        "tensor_types": mapping,
        "overrides": overrides,
        "unmapped": unmapped,
        "unsupported": [{"name": n, "format": f} for n, f in unsupported],
        "note": (
            "Utiliser --tensor-type de llama-quantize (conversion), pas "
            "--override-tensor de llama-cli (placement mémoire)."
        ),
    }
    if json_path:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
    return payload


# ─────────────────────────────────────────────────────────────────────────────
# TensorRT-LLM
# ─────────────────────────────────────────────────────────────────────────────


def export_tensorrt_llm(
    plan: Plan,
    out_path: Optional[str] = None,
    dtype: str = "float16",
) -> Dict:
    """Génère un `quant_config` TensorRT-LLM.

    `trtllm-build` **n'a pas** d'option `--per_layer_precision` : les deux
    scripts .ps1 du repo v1 utilisaient un drapeau inexistant, et
    `--max_output_len` a été remplacé par `--max_seq_len`. Le chemin correct
    est de produire un checkpoint quantifié (``quantize.py`` de
    TensorRT-LLM, ou ``modelopt``) dont le `quant_config` porte les exclusions
    par couche, puis de le construire.

    On émet donc un `quant_config` exploitable plus la ligne `trtllm-build`
    correspondante, sans inventer d'options.
    """
    trt_of = {}
    excluded: List[str] = []
    per_layer: Dict[str, str] = {}
    for e in plan.entries:
        t = fmts.get(e.format).trt
        if t is None:
            excluded.append(e.name)
            continue
        per_layer[e.name] = t
        trt_of[e.format] = t

    # Le mode dominant devient le quant_algo global ; le reste va en exclusions.
    counts: Dict[str, int] = {}
    for t in per_layer.values():
        counts[t] = counts.get(t, 0) + 1
    dominant = max(counts, key=counts.get) if counts else "fp16"
    algo = {
        "int4": "W4A16_AWQ", "int4_awq": "W4A16_AWQ", "int8": "W8A16",
        "nvfp4": "NVFP4", "fp16": None, "bf16": None, "fp32": None,
    }.get(dominant)

    exclude_modules = sorted(
        n for n, t in per_layer.items() if t != dominant
    ) + sorted(excluded)

    payload = {
        "quant_config": {
            "quant_algo": algo,
            "kv_cache_quant_algo": None,
            "group_size": 128,
            "exclude_modules": exclude_modules,
        },
        "build": {
            "dtype": dtype,
            "command": (
                "trtllm-build \\\n"
                "  --checkpoint_dir ./trt_checkpoint \\\n"
                "  --output_dir ./engine \\\n"
                f"  --dtype {dtype} \\\n"
                "  --gemm_plugin auto \\\n"
                "  --max_batch_size 4 \\\n"
                "  --max_input_len 4096 \\\n"
                "  --max_seq_len 5120"
            ),
            "note": (
                "La quantification par couche se déclare dans le quant_config "
                "du checkpoint (quantize.py / modelopt), pas en option de "
                "trtllm-build : --per_layer_precision n'existe pas."
            ),
        },
        "per_layer_precision": per_layer,
        "unsupported_by_trt": excluded,
    }
    if out_path:
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
    return payload


def export_json(plan: Plan, path: str) -> Dict:
    """Écrit le plan complet en JSON (UTF-8, accents conservés)."""
    payload = plan.to_dict()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    return payload
