"""
d2.formats — Formats de quantification : tailles exactes + simulation d'erreur
==============================================================================

Deux rôles :

1. **Comptabilité mémoire exacte.** Les `bpw` (bits per weight) sont dérivés des
   structures de blocs réelles de ggml (`ggml-common.h`), pas de valeurs
   théoriques. Un Q4_K_M ne fait pas 4 bits/poids mais 4.5, et un Q8_0 fait 8.5.
   Se tromper là-dessus fausse toute contrainte VRAM.

2. **Mesure d'erreur de quantification.** `roundtrip(W, fmt)` quantifie puis
   déquantifie réellement W, ce qui donne l'erreur `‖W - Q(W)‖_F`. C'est la
   grandeur qui pilote le plan (cf. `d2.sensitivity`), au lieu d'un proxy
   spectral non validé.

Références
----------
- ggml / llama.cpp, `ggml-common.h` : structures `block_q4_0`, `block_q4_K`, ...
- OCP Microscaling (MX) Formats Specification v1.0 (2023) : MXFP4 = E2M1 +
  échelle E8M0 partagée par 32 éléments.
- NVIDIA Blackwell NVFP4 : E2M1 + échelle E4M3 par bloc de 16 + échelle FP32
  par tenseur.
- Frantar et al., "GPTQ" (ICLR 2023) et Lin et al., "AWQ" (MLSys 2024) pour la
  quantification par groupe asymétrique 4 bits.

Limite assumée
--------------
Les K-quants de llama.cpp choisissent leurs échelles par une recherche
itérative pondérée (`make_qkx2_quants`, `make_qx_quants`). On reproduit ici la
*structure* exacte des blocs (taille de sous-bloc, bits d'échelle, bits de
poids) mais avec un choix d'échelle min/max direct. L'erreur simulée est donc
une **borne supérieure** (typiquement 5–15 % pessimiste sur Q4_K). C'est
conservateur dans le bon sens : le planificateur ne sous-estime jamais le
risque. Voir `tests/test_formats.py::test_kquant_error_is_upper_bound`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

import numpy as np

__all__ = [
    "QuantFormat",
    "FORMATS",
    "bytes_per_weight",
    "format_bytes",
    "roundtrip",
    "relative_error",
    "list_formats",
    "GGUF_TYPE_NAME",
]


# ─────────────────────────────────────────────────────────────────────────────
# Table des formats
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class QuantFormat:
    """Description d'un format de quantification.

    Attributes:
        name:        identifiant D2 (clé de `FORMATS`).
        block:       nombre d'éléments par bloc/super-bloc (1 = par élément).
        block_bytes: octets stockés pour un bloc complet.
        gguf:        nom du type ggml correspondant (None si non exprimable).
        trt:         type TensorRT-LLM correspondant (None si non supporté).
        family:      'float' | 'int' | 'kquant' | 'fp4'.
        kernel:      kernel d'inférence typique sur GPU NVIDIA.
    """

    name: str
    block: int
    block_bytes: float
    gguf: Optional[str]
    trt: Optional[str]
    family: str
    kernel: str

    @property
    def bpw(self) -> float:
        """Bits par poids, échelles et métadonnées de bloc incluses."""
        return self.block_bytes * 8.0 / self.block

    @property
    def bytes_per_weight(self) -> float:
        """Octets par poids, échelles et métadonnées de bloc incluses."""
        return self.block_bytes / self.block


def _f(name, block, block_bytes, gguf, trt, family, kernel):
    return QuantFormat(name, block, block_bytes, gguf, trt, family, kernel)


#: Formats supportés. `block_bytes` vient des structures ggml réelles.
FORMATS: Dict[str, QuantFormat] = {
    # ── Flottants ────────────────────────────────────────────────────────────
    "F32":     _f("F32",     1,   4.0, "f32",  "fp32", "float",  "CUBLASLT"),
    "F16":     _f("F16",     1,   2.0, "f16",  "fp16", "float",  "CUBLASLT"),
    "BF16":    _f("BF16",    1,   2.0, "bf16", "bf16", "float",  "CUBLASLT"),
    # ── Quants "legacy" ggml (bloc 32) ───────────────────────────────────────
    #   Q4_0 : d(f16) + 16 octets de nibbles                    = 18
    #   Q5_0 : d(f16) + qh(4) + 16                              = 22
    #   Q8_0 : d(f16) + 32 int8                                 = 34
    "Q4_0":    _f("Q4_0",   32,  18.0, "q4_0", "int4", "int",    "MMQ"),
    "Q5_0":    _f("Q5_0",   32,  22.0, "q5_0", None,   "int",    "MMQ"),
    "Q8_0":    _f("Q8_0",   32,  34.0, "q8_0", "int8", "int",    "MMQ"),
    # ── K-quants (super-bloc 256) ────────────────────────────────────────────
    #   Q2_K : scales(16) + qs(64) + d(2) + dmin(2)             = 84
    #   Q3_K : hmask(32) + qs(64) + scales(12) + d(2)           = 110
    #   Q4_K : d(2) + dmin(2) + scales(12) + qs(128)            = 144
    #   Q5_K : d(2) + dmin(2) + scales(12) + qh(32) + qs(128)   = 176
    #   Q6_K : ql(128) + qh(64) + scales(16) + d(2)             = 210
    # TensorRT-LLM n'a pas d'équivalent des K-quants : on indique le format
    # supporté le plus proche en largeur (W4A16_AWQ / W8A16). La taille
    # obtenue diffère donc légèrement de celle du plan GGUF — l'export TRT le
    # signale explicitement plutôt que de laisser croire à une équivalence.
    "Q2_K":    _f("Q2_K",  256,  84.0, "q2_K", "int4", "kquant", "MMQ"),
    "Q3_K":    _f("Q3_K",  256, 110.0, "q3_K", "int4", "kquant", "MMQ"),
    "Q4_K":    _f("Q4_K",  256, 144.0, "q4_K", "int4", "kquant", "MMQ"),
    "Q5_K":    _f("Q5_K",  256, 176.0, "q5_K", "int8", "kquant", "MMQ"),
    "Q6_K":    _f("Q6_K",  256, 210.0, "q6_K", "int8", "kquant", "MMQ"),
    # ── FP4 microscaling ─────────────────────────────────────────────────────
    #   NVFP4 : E2M1 (4 b) + échelle E4M3 (8 b) par 16   → 4.5 bpw
    #   MXFP4 : E2M1 (4 b) + échelle E8M0 (8 b) par 32   → 4.25 bpw
    "NVFP4":   _f("NVFP4",  16,   9.0, None,   "nvfp4", "fp4",   "CUTLASS"),
    "MXFP4":   _f("MXFP4",  32,  17.0, "mxfp4", None,   "fp4",   "CUTLASS"),
    # ── Quantification par groupe façon AWQ/GPTQ (TensorRT-LLM) ──────────────
    #   INT4 asymétrique, groupe 128 : 4 b + (scale f16 + zéro f16)/128
    "INT4_AWQ": _f("INT4_AWQ", 128, 68.0, "q4_K", "int4_awq", "int", "MARLIN"),
    #   INT8 symétrique par canal : l'échelle par ligne est négligeable
    "INT8":    _f("INT8",    1,   1.0, "q8_0", "int8", "int",    "CUTLASS"),
}

#: Alias historiques du repo → format canonique.
_ALIASES = {
    "FP16": "F16",
    "FP32": "F32",
    "INT4": "Q4_K",
    "Q4_K_M": "Q4_K",
    "Q4_K_S": "Q4_K",
    "Q5_K_M": "Q5_K",
    "Q6_K_M": "Q6_K",
    "NVFP4_SAFE": "NVFP4",
    "INT8_SAFE": "Q8_0",
    "FP16_REQUIRED": "F16",
    "FP8": "Q8_0",  # pas de FP8 en GGUF ; équivalent mémoire le plus proche
}

#: Nom du type ggml pour `llama-quantize --tensor-type`.
GGUF_TYPE_NAME = {k: v.gguf for k, v in FORMATS.items()}


def canonical(name: str) -> str:
    """Résout un alias historique vers un nom de format canonique.

    Raises:
        KeyError: si le format est inconnu (échec explicite plutôt que
            repli silencieux sur FP16, qui masquait les erreurs en v1).
    """
    if name in FORMATS:
        return name
    if name in _ALIASES:
        return _ALIASES[name]
    raise KeyError(
        f"format inconnu : {name!r}. Connus : {sorted(FORMATS)} "
        f"(alias : {sorted(_ALIASES)})"
    )


def get(name: str) -> QuantFormat:
    """Retourne le `QuantFormat` d'un nom ou d'un alias."""
    return FORMATS[canonical(name)]


def bytes_per_weight(name: str) -> float:
    """Octets par poids pour un format, métadonnées de bloc comprises."""
    return get(name).bytes_per_weight


def format_bytes(n_elements: int, name: str) -> float:
    """Taille en octets de `n_elements` poids stockés dans `name`.

    Arrondit au bloc supérieur : un tenseur de 40 éléments en Q4_K occupe
    deux super-blocs de 256, pas 40 × 0.5625 octet.
    """
    fmt = get(name)
    if fmt.block <= 1:
        return float(n_elements) * fmt.block_bytes
    n_blocks = int(np.ceil(n_elements / fmt.block))
    return float(n_blocks) * fmt.block_bytes


def list_formats(family: Optional[str] = None) -> List[str]:
    """Liste les formats, éventuellement filtrés par famille."""
    return sorted(k for k, v in FORMATS.items() if family is None or v.family == family)


# ─────────────────────────────────────────────────────────────────────────────
# Quantificateurs aller-retour (pour mesurer l'erreur, pas pour produire
# un fichier : on ne réencode jamais les bits, on ne garde que W déquantifié)
# ─────────────────────────────────────────────────────────────────────────────


def _pad_to_blocks(x: np.ndarray, block: int):
    """Aplati `x` et complète par des zéros jusqu'à un multiple de `block`."""
    flat = np.asarray(x, dtype=np.float32).ravel()
    n = flat.size
    pad = (-n) % block
    if pad:
        flat = np.concatenate([flat, np.zeros(pad, dtype=np.float32)])
    return flat.reshape(-1, block), n


def _unpad(blocks: np.ndarray, n: int, shape) -> np.ndarray:
    return blocks.ravel()[:n].reshape(shape)


def _safe_reciprocal(d: np.ndarray) -> np.ndarray:
    """1/d élément par élément, 0 là où d == 0.

    `np.where` évalue ses deux branches avant de sélectionner : diviser par
    `d` directement émet un `RuntimeWarning: divide by zero` même quand le
    résultat est ensuite écarté par le masque. `errstate` supprime ce
    warning sans changer le résultat (les blocs à échelle nulle sont des
    blocs entièrement à zéro, dont la valeur déquantifiée est de toute façon
    nulle quel que soit `inv`).
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(d != 0, 1.0 / d, 0.0)


def _rt_float(W: np.ndarray, dtype) -> np.ndarray:
    """Aller-retour par simple changement de dtype (F16)."""
    return np.asarray(W, dtype=np.float32).astype(dtype).astype(np.float32)


def _rt_bf16(W: np.ndarray) -> np.ndarray:
    """BF16 = arrondir au pair les 16 bits bas de la mantisse FP32."""
    x = np.asarray(W, dtype=np.float32)
    bits = x.view(np.uint32)

    # Arrondi au pair : si bit 16 = 1, ajouter 1 à bit 17 si bit 16 ≠ 1
    # (round-to-nearest-even)
    rounding = (bits >> 16) & 1
    bits = bits + 0x7FFF + rounding

    # Tronquer les 16 bits bas
    bits = bits & 0xFFFF0000

    return bits.view(np.float32).astype(np.float32)


def _rt_symmetric_block(W: np.ndarray, block: int, nbits: int) -> np.ndarray:
    """Quantification symétrique par bloc, à la `quantize_row_q4_0`.

    llama.cpp prend l'élément de plus grande *valeur absolue signée* et pose
    d = max / -(2^(n-1)), ce qui utilise le niveau négatif extrême.
    """
    blocks, n = _pad_to_blocks(W, block)
    half = 1 << (nbits - 1)
    idx = np.argmax(np.abs(blocks), axis=1)
    vmax = blocks[np.arange(blocks.shape[0]), idx]
    d = vmax / (-float(half))
    inv = _safe_reciprocal(d)
    q = np.rint(blocks * inv[:, None]) + half
    q = np.clip(q, 0, 2 * half - 1)
    deq = (q - half) * d[:, None]
    return _unpad(deq, n, np.shape(W))


def _rt_q8_0(W: np.ndarray) -> np.ndarray:
    """Q8_0 : d = amax/127, q = round(x/d), q ∈ [-127, 127]."""
    blocks, n = _pad_to_blocks(W, 32)
    amax = np.max(np.abs(blocks), axis=1)
    d = amax / 127.0
    inv = _safe_reciprocal(d)
    q = np.clip(np.rint(blocks * inv[:, None]), -127, 127)
    return _unpad(q * d[:, None], n, np.shape(W))


def _quantize_scales(scales: np.ndarray, bits: int) -> np.ndarray:
    """Quantifie les échelles de sous-blocs sur `bits` bits (échelle commune).

    Reproduit le second niveau des K-quants : les 8 (ou 16) échelles d'un
    super-bloc sont elles-mêmes quantifiées relativement à un `d` f16.
    """
    levels = (1 << bits) - 1
    smax = np.max(np.abs(scales), axis=1, keepdims=True)
    d = smax / levels
    inv = _safe_reciprocal(d)
    return np.rint(scales * inv) * d


def _rt_kquant_affine(W: np.ndarray, sub: int, nbits: int, scale_bits: int) -> np.ndarray:
    """K-quant affine (min + échelle) : Q2_K, Q4_K, Q5_K."""
    super_block = 256
    blocks, n = _pad_to_blocks(W, super_block)
    nb, _ = blocks.shape
    
    # Traiter par lots de super-blocs pour limiter allocation mémoire
    out = np.zeros_like(blocks)
    chunk_size = max(50, min(200, 1000000 // super_block))
    for i in range(0, nb, chunk_size):
        end = min(i + chunk_size, nb)
        sb = blocks[i:end].reshape(-1, super_block // sub, sub)
        
        vmin = sb.min(axis=2)
        vmax = sb.max(axis=2)
        levels = (1 << nbits) - 1
        scales = (vmax - vmin) / levels
        
        scales_q = _quantize_scales(scales, scale_bits)
        mins_q = _quantize_scales(vmin, scale_bits)

        inv = _safe_reciprocal(scales_q)
        q = np.clip(np.rint((sb - mins_q[..., None]) * inv[..., None]), 0, levels)
        
        deq = q * scales_q[..., None] + mins_q[..., None]
        out[i:end] = deq.reshape(-1, super_block)
        
    return _unpad(out, n, np.shape(W))


def _rt_kquant_symmetric(W: np.ndarray, sub: int, nbits: int, scale_bits: int) -> np.ndarray:
    """K-quant symétrique (échelle seule) : Q3_K, Q6_K."""
    super_block = 256
    blocks, n = _pad_to_blocks(W, super_block)
    nb, _ = blocks.shape
    sb = blocks.reshape(nb, super_block // sub, sub)

    half = 1 << (nbits - 1)
    idx = np.argmax(np.abs(sb), axis=2)
    vmax = np.take_along_axis(sb, idx[..., None], axis=2).squeeze(2)
    scales = vmax / (-float(half))
    scales_q = _quantize_scales(scales, scale_bits)

    inv = _safe_reciprocal(scales_q)
    q = np.clip(np.rint(sb * inv[..., None]), -half, half - 1)
    deq = q * scales_q[..., None]
    return _unpad(deq.reshape(nb, super_block), n, np.shape(W))


# Niveaux E2M1 (FP4) : 1 bit de signe, 2 d'exposant, 1 de mantisse.
_E2M1_LEVELS = np.array(
    [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], dtype=np.float32
)


def _quantize_e2m1(x: np.ndarray) -> np.ndarray:
    """Projette sur la grille E2M1 la plus proche (signe conservé)."""
    sign = np.sign(x)
    a = np.abs(x)
    # bord de décision = milieu entre niveaux consécutifs
    edges = (_E2M1_LEVELS[:-1] + _E2M1_LEVELS[1:]) / 2.0
    idx = np.searchsorted(edges, a)
    return sign * _E2M1_LEVELS[np.clip(idx, 0, len(_E2M1_LEVELS) - 1)]


def _quantize_e4m3(x: np.ndarray) -> np.ndarray:
    """Arrondit une échelle positive sur la grille FP8 E4M3 (max 448)."""
    x = np.clip(x, 0.0, 448.0)
    out = np.zeros_like(x)
    nz = x > 0
    if not np.any(nz):
        return out
    e = np.floor(np.log2(x[nz]))
    e = np.clip(e, -6, 8)  # exposants normaux E4M3
    mant = x[nz] / np.exp2(e)  # ∈ [1, 2)
    mant = np.rint(mant * 8.0) / 8.0  # 3 bits de mantisse
    out[nz] = mant * np.exp2(e)
    return out


def _rt_fp4(W: np.ndarray, block: int, scale_kind: str) -> np.ndarray:
    """Microscaling FP4 : E2M1 + échelle par bloc.

    scale_kind='e4m3' → NVFP4 (bloc 16) ; 'e8m0' → MXFP4 (bloc 32, échelle
    puissance de deux exacte, cf. spec OCP MX v1.0).
    """
    blocks, n = _pad_to_blocks(W, block)
    amax = np.max(np.abs(blocks), axis=1)
    scale = amax / 6.0
    if scale_kind == "e8m0":
        nz = scale > 0
        s = np.zeros_like(scale)
        s[nz] = np.exp2(np.ceil(np.log2(scale[nz])))
        scale = s
    else:
        scale = _quantize_e4m3(scale)
    inv = _safe_reciprocal(scale)
    q = _quantize_e2m1(blocks * inv[:, None])
    return _unpad(q * scale[:, None], n, np.shape(W))


def _rt_int8_per_channel(W: np.ndarray) -> np.ndarray:
    """INT8 symétrique par canal de sortie (ligne), façon SmoothQuant/TRT."""
    x = np.asarray(W, dtype=np.float32)
    if x.ndim == 1:
        x = x[None, :]
    amax = np.max(np.abs(x), axis=1, keepdims=True)
    d = amax / 127.0
    inv = _safe_reciprocal(d)
    q = np.clip(np.rint(x * inv), -127, 127)
    return (q * d).reshape(np.shape(W))


def _rt_int4_group(W: np.ndarray, group: int = 128) -> np.ndarray:
    """INT4 asymétrique par groupe (AWQ/GPTQ, `group_size=128`)."""
    blocks, n = _pad_to_blocks(W, group)
    vmin = blocks.min(axis=1, keepdims=True)
    vmax = blocks.max(axis=1, keepdims=True)
    d = (vmax - vmin) / 15.0
    inv = _safe_reciprocal(d)
    q = np.clip(np.rint((blocks - vmin) * inv), 0, 15)
    return _unpad(q * d + vmin, n, np.shape(W))


#: Aller-retour par format. Signature : (np.ndarray) -> np.ndarray float32.
_ROUNDTRIP: Dict[str, Callable[[np.ndarray], np.ndarray]] = {
    "F32": lambda W: np.asarray(W, dtype=np.float32),
    "F16": lambda W: _rt_float(W, np.float16),
    "BF16": _rt_bf16,
    "Q4_0": lambda W: _rt_symmetric_block(W, 32, 4),
    "Q5_0": lambda W: _rt_symmetric_block(W, 32, 5),
    "Q8_0": _rt_q8_0,
    "Q2_K": lambda W: _rt_kquant_affine(W, sub=16, nbits=2, scale_bits=4),
    "Q3_K": lambda W: _rt_kquant_symmetric(W, sub=16, nbits=3, scale_bits=6),
    "Q4_K": lambda W: _rt_kquant_affine(W, sub=32, nbits=4, scale_bits=6),
    "Q5_K": lambda W: _rt_kquant_affine(W, sub=32, nbits=5, scale_bits=6),
    "Q6_K": lambda W: _rt_kquant_symmetric(W, sub=16, nbits=6, scale_bits=8),
    "NVFP4": lambda W: _rt_fp4(W, 16, "e4m3"),
    "MXFP4": lambda W: _rt_fp4(W, 32, "e8m0"),
    "INT8": _rt_int8_per_channel,
    "INT4_AWQ": lambda W: _rt_int4_group(W, 128),
}


def relative_error(
    W: np.ndarray, fmt: str, weights: Optional[np.ndarray] = None
) -> float:
    """Erreur relative de quantification ‖W − Q(W)‖ / ‖W‖.

    Traite la matrice par blocs de lignes pour borner le pic mémoire (une
    copie de quelques centaines de lignes à la fois, jamais W entier x2/x3).

    Si `weights` (statistiques d'activation par canal d'entrée, imatrix) est
    fourni, il pondère à la fois l'erreur et la norme de référence :

        rel = ‖(W − Q(W))·diag(√s)‖_F / ‖W·diag(√s)‖_F

    Une imatrix uniforme laisse donc le résultat inchangé (le facteur
    constant s'annule) ; seule une importance *non uniforme* entre canaux
    déplace le résultat. `weights` doit être 1-D, de longueur égale au
    nombre de colonnes de `W` (canaux d'entrée).
    """
    W = np.asarray(W, dtype=np.float32)
    n_rows = W.shape[0]
    n_cols = W.shape[1] if W.ndim > 1 else 1
    chunk_size = max(10, min(1000, 500_000_000 // max(1, 4 * n_cols)))

    s = None
    if weights is not None:
        w_arr = np.asarray(weights, dtype=np.float32)
        if w_arr.ndim != 1 or w_arr.size != n_cols:
            raise ValueError(
                f"weights (imatrix) doit être un vecteur 1-D de taille {n_cols} "
                f"(canaux d'entrée de W) ; reçu shape={w_arr.shape}"
            )
        s = np.sqrt(np.maximum(w_arr, 0.0))

    sq_err_norm = 0.0
    sq_w_norm = 0.0

    for i in range(0, n_rows, chunk_size):
        end = min(i + chunk_size, n_rows)
        W_chunk = W[i:end].copy()
        Q_chunk = _ROUNDTRIP[canonical(fmt)](W_chunk)

        E_chunk = W_chunk - Q_chunk

        if s is not None:
            E_chunk *= s[None, :]
            W_chunk *= s[None, :]

        sq_err_norm += np.sum(E_chunk**2)
        sq_w_norm += np.sum(W_chunk**2)

        del W_chunk, Q_chunk, E_chunk

    den = np.sqrt(sq_w_norm)
    return float(np.sqrt(sq_err_norm) / den) if den > 0 else 0.0

# Suppression de roundtrip inutile car relative_error fait le travail
# (on pourrait le garder pour d'autres usages mais l'implémenter 
# de manière sécurisée est complexe).
def roundtrip(W: np.ndarray, fmt: str) -> np.ndarray:
    """Quantifie puis déquantifie `W` dans `fmt`. Retourne un float32."""
    # Implémentation de repli : si on a vraiment besoin du tableau entier, 
    # cela échouera sur de très grands tenseurs.
    return _ROUNDTRIP[canonical(fmt)](np.asarray(W, dtype=np.float32))
