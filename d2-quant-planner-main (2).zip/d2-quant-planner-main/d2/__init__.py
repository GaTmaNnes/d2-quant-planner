"""
D2 — Planificateur de quantification sous contrainte mémoire
=============================================================

Noyau unique du projet. Les scripts historiques à la racine du dépôt
(`d2_production.py`, `d2_rtx_gguf_profiler.py`, `app.py`, `d2_ui.py`, ...) sont
désormais de simples façades au-dessus de ce package : il n'existe plus qu'une
seule définition de chaque grandeur, alors que le v1 en avait jusqu'à quatre,
parfois contradictoires.

Exemple
-------
```python
import d2

layers, info = d2.load_gguf("model-f16.gguf", with_spectral=True)
caps  = d2.get_profile("rtx4090")
plan  = d2.plan_layers(layers, caps, vram_budget_gb=16.0,
                       ctx_len=8192, **d2.kv_geometry(info))
print(d2.summarize(plan, caps))
d2.export_llama_cpp(plan, "model-f16.gguf", "model-d2.gguf",
                    json_path="plan.json")
```

Principes
---------
- Les décisions reposent sur l'**erreur de quantification mesurée**
  (`d2.formats.roundtrip`), pondérée par l'importance de couche et, si une
  imatrix est fournie, par les statistiques d'activation réelles.
- L'exposant spectral α est calculé correctement (Martin & Mahoney, estimateur
  de Hill) et exporté comme **diagnostic**, pas comme critère de décision.
- Toute grandeur estimée est étiquetée comme telle ; rien n'est présenté comme
  mesuré sans l'être.
- Un budget intenable lève `InfeasibleBudget` au lieu de retourner un plan
  hors budget.
"""

from __future__ import annotations

from typing import Dict

from .formats import (
    FORMATS,
    QuantFormat,
    bytes_per_weight,
    format_bytes,
    relative_error,
    roundtrip,
)
from .hardware import (
    GPU_PROFILES,
    GPUCaps,
    decode_latency_s,
    detect_gpu,
    get_profile,
    supported_formats,
)
from .loaders import (
    load_gguf,
    load_huggingface,
    load_safetensors,
    synthetic_model,
)
from .planner import (
    InfeasibleBudget,
    MemoryBudget,
    Plan,
    PlanEntry,
    kv_cache_bytes,
    plan_layers,
    solve,
)
from .report import layer_table, summarize
from .sensitivity import LayerSpec, classify, load_imatrix, sensitivity_matrix
from .spectral import SpectralStats, analyze as spectral_analyze
from .exporters import (
    export_json,
    export_llama_cpp,
    export_tensorrt_llm,
    hf_to_gguf_name,
)
from .bottlenecks import detect_bottlenecks, optimization_hints, overall_throughput
from .validation import (
    check_memory_budget,
    check_quality_degradation,
    suggest_improvements,
    validate_plan,
)
from .layer_optimization import saliency_aware_precision, suggest_group_precision

__version__ = "3.0.0"

__all__ = [
    "__version__",
    # formats
    "FORMATS", "QuantFormat", "bytes_per_weight", "format_bytes",
    "relative_error", "roundtrip",
    # matériel
    "GPUCaps", "GPU_PROFILES", "detect_gpu", "get_profile",
    "supported_formats", "decode_latency_s",
    # chargement
    "load_gguf", "load_safetensors", "load_huggingface", "synthetic_model",
    # planification
    "LayerSpec", "Plan", "PlanEntry", "MemoryBudget", "InfeasibleBudget",
    "plan_layers", "solve", "kv_cache_bytes", "sensitivity_matrix", "classify",
    "load_imatrix", "kv_geometry",
    # spectral
    "SpectralStats", "spectral_analyze",
    # optimisation et analyse
    "detect_bottlenecks", "optimization_hints", "overall_throughput",
    "validate_plan", "check_memory_budget", "check_quality_degradation",
    "suggest_improvements",
    "saliency_aware_precision", "suggest_group_precision",
    # restitution / export
    "summarize", "layer_table", "export_llama_cpp", "export_tensorrt_llm",
    "export_json", "hf_to_gguf_name",
]


def kv_geometry(info: Dict) -> Dict:
    """Extrait de `ModelInfo` les arguments KV attendus par `plan_layers`.

    Retourne un dict vide plutôt que des valeurs inventées lorsque la
    géométrie est inconnue : `plan_layers` ajoutera alors une note explicite
    signalant que le cache KV n'est pas compté.
    """
    out = {}
    for key in ("n_blocks", "n_kv_heads", "head_dim"):
        if info.get(key):
            out[key] = int(info[key])
    return out
