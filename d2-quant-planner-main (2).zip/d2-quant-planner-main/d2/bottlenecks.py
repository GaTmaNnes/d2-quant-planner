"""
d2.bottlenecks — Détection des goulots d'étranglement GPU

Identifie, par bloc transformer, ce qui domine la latence de décodage
(mémoire vs compute) et la part de chaque bloc dans le temps total.

Note de méthode
----------------
En décodage auto-régressif, les blocs s'exécutent **séquentiellement** : la
latence totale d'un token est la **somme** des latences de chaque bloc, pas
la latence d'un seul bloc pris isolément. Un "tokens/s" calculé par bloc
(1/latence_du_bloc) n'a donc pas de sens physique en tant que débit — ce
serait le débit *si le modèle entier ressemblait à ce bloc*, ce qui est
trompeur. On reporte à la place la latence de chaque bloc et sa **part** du
temps total, et le débit global est calculé séparément sur la somme.
"""

from __future__ import annotations

from typing import Dict, List, Optional
import numpy as np

from . import formats as fmts
from . import hardware as hw
from .sensitivity import block_index

__all__ = ["LayerBottleneck", "detect_bottlenecks", "optimization_hints", "overall_throughput"]


class LayerBottleneck:
    """Diagnostic d'un goulot d'étranglement sur un bloc transformer."""

    def __init__(
        self,
        name: str,
        regime: str,
        latency_ms: float,
        n_bytes: float,
        n_flops: float,
        pct_of_total: float,
        issue: str = "",
    ):
        self.name = name
        self.regime = regime  # "memory" ou "compute"
        self.latency_ms = latency_ms
        self.n_bytes = n_bytes
        self.n_flops = n_flops
        self.pct_of_total = pct_of_total
        self.issue = issue

    def __repr__(self) -> str:
        return (
            f"Bottleneck({self.name!r}, {self.regime}, "
            f"{self.latency_ms:.3f}ms, {self.pct_of_total:.1%} du total, {self.issue!r})"
        )


def detect_bottlenecks(
    entries: List,  # PlanEntry
    caps: hw.GPUCaps,
    ctx_len: int = 4096,
) -> List[LayerBottleneck]:
    """Identifie les blocs qui pèsent le plus sur la latence de décodage.

    Args:
        entries: liste de PlanEntry du plan de quantification.
        caps: profil GPU cible.
        ctx_len: longueur de contexte (diagnostic uniquement, non utilisé
                 dans le calcul roofline par poids — voir `d2.planner.kv_cache_bytes`
                 pour l'impact mémoire du contexte).

    Returns:
        Liste de LayerBottleneck triée par latence décroissante (pire d'abord).
    """
    # Regrouper par bloc transformer pour mesurer des unités cohérentes.
    blocks: Dict[Optional[int], List] = {}
    for e in entries:
        block_id = block_index(e.name)
        blocks.setdefault(block_id, []).append(e)

    raw: List[Dict] = []
    for block_id, block_entries in blocks.items():
        total_bytes = sum(e.bytes for e in block_entries)
        n_elements = sum(int(np.prod(e.shape)) for e in block_entries if len(e.shape) >= 2)

        # hw.roofline_regime / hw.decode_latency_s attendent n_elements brut
        # (elles multiplient elles-mêmes par 2 pour obtenir les FLOP) : leur
        # passer 2*n_elements doublerait le temps de calcul estimé.
        regime = hw.roofline_regime(total_bytes, n_elements, caps, batch=1)
        latency_s = hw.decode_latency_s(total_bytes, caps, n_elements, batch=1)

        issue = ""
        if regime == "memory":
            bpw_current = total_bytes / n_elements if n_elements else 0.0
            if bpw_current > 1.0:
                issue = f"mémoire-limité ({bpw_current:.2f} octets/poids)"
        else:
            issue = "compute-limité (quantification peu utile ici)"

        max_error = max(
            (e.rel_error for e in block_entries if np.isfinite(e.rel_error)), default=0.0
        )
        if max_error > 0.05:
            issue += f" + dégradation qualité {max_error:.1%}"

        raw.append(
            dict(
                name=f"block_{block_id}" if block_id is not None else "other",
                regime=regime,
                latency_s=latency_s,
                n_bytes=total_bytes,
                n_flops=2 * n_elements,
                issue=issue,
            )
        )

    total_latency_s = sum(r["latency_s"] for r in raw) or 1.0

    issues = [
        LayerBottleneck(
            name=r["name"],
            regime=r["regime"],
            latency_ms=r["latency_s"] * 1000,
            n_bytes=r["n_bytes"],
            n_flops=r["n_flops"],
            pct_of_total=r["latency_s"] / total_latency_s,
            issue=r["issue"],
        )
        for r in raw
    ]
    issues.sort(key=lambda x: -x.latency_ms)
    return issues


def overall_throughput(bottlenecks: List[LayerBottleneck]) -> float:
    """Débit global (tokens/s) en sommant la latence de tous les blocs.

    C'est la seule grandeur de tokens/s physiquement correcte à partir d'une
    décomposition par bloc : les blocs s'exécutant en séquence, on additionne
    leurs latences avant d'inverser, on n'inverse pas chaque latence à part.
    """
    total_ms = sum(b.latency_ms for b in bottlenecks)
    return 1000.0 / total_ms if total_ms > 0 else float("inf")


def optimization_hints(bottlenecks: List[LayerBottleneck]) -> List[str]:
    """Suggestions d'optimisation basées sur les goulots détectés.

    Returns:
        Liste de recommandations actionnables (texte ASCII, sûr sur toute
        console y compris cp1252/Windows).
    """
    if not bottlenecks:
        return ["Pas de goulot identifie."]

    hints = []
    tput = overall_throughput(bottlenecks)
    n_memory = sum(1 for b in bottlenecks if b.regime == "memory")
    n_compute = len(bottlenecks) - n_memory

    if n_memory >= n_compute:
        hints.append(
            f"[primaire] limite par la memoire ({n_memory}/{len(bottlenecks)} blocs). "
            f"Quantifier davantage les couches non critiques (FFN) fera gagner du debit."
        )
    else:
        hints.append(
            f"[primaire] limite par le compute ({n_compute}/{len(bottlenecks)} blocs). "
            f"Quantifier davantage n'aidera pas ici ; augmenter le batch le pourrait."
        )

    for bn in bottlenecks[:3]:
        if bn.regime == "memory" and bn.pct_of_total > 1.0 / max(len(bottlenecks), 1):
            hints.append(
                f"[goulot] {bn.name}: {bn.pct_of_total:.1%} du temps de decodage "
                f"({bn.n_bytes / 1e9:.3f} Go, {bn.latency_ms:.3f} ms)."
            )
        if "qualité" in bn.issue.lower() or "qualite" in bn.issue.lower():
            hints.append(
                f"[qualite] {bn.name}: erreur elevee detectee. "
                f"Envisager F16/Q8_0 sur ce bloc plutot qu'un format plus compact."
            )

    hints.append(f"[debit] estimation roofline globale : ~{tput:.1f} tokens/s.")
    return hints
