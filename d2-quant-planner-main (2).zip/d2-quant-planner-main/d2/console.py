"""
d2.console — Sortie console robuste sous Windows
=================================================

La console Windows par défaut est en cp1252. Tout `print` contenant un
caractère hors de cette page (les `─`, `→`, `α`, `✅`, `█` et les emoji dont
le repo v1 était rempli) lève `UnicodeEncodeError` et interrompt le script en
plein milieu — y compris après un scan de plusieurs minutes.

`setup()` bascule stdout/stderr en UTF-8 avec repli `replace`, ce qui rend
l'affichage lisible partout et non fatal dans le pire des cas. À appeler au
début de chaque point d'entrée CLI ; la bibliothèque elle-même n'émet que de
l'ASCII et ne dépend pas de cet appel.
"""

from __future__ import annotations

import sys

__all__ = ["setup", "supports_unicode"]

_done = False


def setup(force_utf8: bool = True) -> None:
    """Rend stdout/stderr tolérants aux caractères non-ASCII. Idempotent."""
    global _done
    if _done:
        return
    _done = True
    if not force_utf8:
        return
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            # Flux redirigé ou non reconfigurable : on n'insiste pas.
            pass


def supports_unicode() -> bool:
    """True si stdout peut encoder les caractères de dessin de boîte."""
    enc = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        "─→α█".encode(enc)
        return True
    except (UnicodeEncodeError, LookupError):
        return False
